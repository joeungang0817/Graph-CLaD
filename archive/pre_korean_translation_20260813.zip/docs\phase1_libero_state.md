# Phase 1: LIBERO state access and oracle-graph boundary

> **2026-08-06 roadmap v3 note:** Phase 1A의 live state-access 결과는 유지한다.
> 다음 데이터 단계는 scripted action 수집이 아니라 official demonstration HDF5의
> state/action timing을 확인하고 저장된 MuJoCo state를 exact replay하는 Phase 2D다.
> See `docs/revised_research_roadmap_v3.md`.

> **2026-08-05 literature reassessment:** This document records the completed
> Phase 1a state-access gate. Action-bearing trajectories, episode splits, and
> capability-aware relation labels are now tracked as the reopened Phase 1b
> dataset gate. See `docs/literature_alignment_and_phase_reassessment.md`.

## Goal

Document which LIBERO values can be accessed from the simulator and freeze a
raw-state inspection contract before building the Phase 2 graph dataset.

This phase does not construct graph edges, choose a distance threshold, or
train a GNN. Those decisions belong to Phase 2 and must be fixed after a live
state capture.

## Source-level findings

The official LIBERO environment wrapper exposes the underlying simulator
through `env.sim`, the robot list through `env.robots`, and a flattened MuJoCo
state through `get_sim_state()`. It also exposes `obj_of_interest` from the
task environment.

The LIBERO task base creates `objects_dict`, `fixtures_dict`,
`object_sites_dict`, `object_states_dict`, and `obj_body_id`. For ordinary
objects and fixtures, the state wrapper reads `sim.data.body_xpos` and
`sim.data.body_xquat`; for site objects it reads site position and rotation.
The same state wrapper provides task predicates such as contact, containment,
on-top, open, and close.

The inspection script therefore records both:

1. raw observation keys and shapes;
2. privileged simulator object state and runtime body indices.

## Identity rule

`logical_id` is the graph identity. It is the task/environment object name,
such as `red_cube` or `target_zone`.

`body_id` is only a runtime MuJoCo index. It is useful for debugging the
current simulator but must not be used as a cross-episode object identity.

## State contract to verify live

| Field | Intended content | Status |
|---|---|---|
| `robot0_eef_pos` | end-effector position | inspection script probes it |
| `robot0_eef_quat` | end-effector orientation | inspection script probes it |
| `robot0_gripper_qpos` | gripper joint positions | inspection script probes it |
| `obj_of_interest` | task-relevant logical names | exposed by LIBERO task env |
| `obj_body_id` | logical name to runtime body index | exposed by LIBERO task env |
| `body_xpos/body_xquat` | object pose from MuJoCo | exposed for object/fixture bodies |
| `object_states_dict` | predicate and joint-state interface | exposed by LIBERO task env |
| `sim.get_state()` | full privileged simulator state | exposed by wrapper |

The script does not silently create a fallback state vector. Missing robot
keys are recorded as `null`, because the actual observation contract must be
resolved from the runtime rather than guessed from a downstream policy.

## Coordinate and quaternion safeguards

- Capture the raw pose first; normalize only after the live frame convention
  is confirmed.
- Keep the coordinate frame explicit: world, robot base, or task-local.
- Record raw MuJoCo body quaternion ordering separately from any policy-facing
  quaternion convention.
- Compute normalization statistics from the training split only.
- Do not include future state, success, or terminal-step information in the
  Stage 1 input window.

## Files added in Phase 1

- `scripts/phase1/state_inspection.py`: live LIBERO task inspector.
- `tests/test_phase1_inspection.py`: LIBERO-independent schema tests.
- `configs/phase1_state_inspection.json`: default inspection configuration.
- `data/phase1_libero_state_sample.json`: clearly labelled schema example.
- `data/phase1_libero_state_capture.json`: compact manifest of the live Colab
  capture; the command below remains the source of the full raw JSON.

## Run after LIBERO is installed

```powershell
python -m scripts.phase1.state_inspection `
  --suite libero_spatial `
  --task-id 0 `
  --init-state-id 0 `
  --steps 1 `
  --controller JOINT_POSITION `
  --output data/phase1_libero_state_capture.json
```

The command produced a live capture for `libero_spatial`, task 0, initial
state 0. It contained two snapshots, 23 object/fixture/site entries per
snapshot, a 92-dimensional flattened simulator state, and the raw robot
fields needed for the controlled graph study. The compact manifest records
the measured schema and representative poses; rerunning the command produces
the complete capture.

## Current limitation

LIBERO, robosuite, and MuJoCo are not installed in the local project runtime,
so the live capture was executed in Colab. The current Colab environment
required a runtime-only compatibility patch for robosuite 1.4.0's MuJoCo
mass-matrix wrapper and an explicit `weights_only=False` when loading the
trusted official LIBERO init-state file. These patches are not applied to the
baseline model code and must be recorded in the eventual environment lock.

The generic predicate probes also exposed a compatibility boundary: some
object-specific `get_joint_state`, `is_open`, and `is_close` calls returned
shape or implementation errors. The Phase 2 graph extractor must therefore
use capability-aware predicates and keep unavailable values explicit rather
than filling them with defaults.

The diagnostic default is `JOINT_POSITION`. It avoids requiring an IK solver
for LIBERO's `MountedPanda` and does not make a Stage 2 policy decision.

## References

- Official repository: https://github.com/Lifelong-Robot-Learning/LIBERO
- Environment wrapper: https://github.com/Lifelong-Robot-Learning/LIBERO/blob/master/libero/libero/envs/env_wrapper.py
- Task state interface: https://github.com/Lifelong-Robot-Learning/LIBERO/blob/master/libero/libero/envs/bddl_base_domain.py
- Object state predicates: https://github.com/Lifelong-Robot-Learning/LIBERO/blob/master/libero/libero/envs/object_states/base_object_states.py
