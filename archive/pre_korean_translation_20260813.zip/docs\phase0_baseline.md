# Phase 0: baseline CLaD smoke test

## Goal

Verify that the supplied Stage 1 code can execute a synthetic train/eval path
before LIBERO or graph data is introduced.

## Gate criteria

- baseline source files remain unchanged;
- input dimension contracts are explicit;
- train forward returns the four expected scalar losses;
- losses and outputs are finite;
- backward produces finite gradients;
- eval returns two `[B, H]` foresight embeddings;
- EMA initialization copies online parameters and the next update follows the
  configured momentum rule;
- unverified data-pipeline details are recorded in `docs/unknowns.md`.

## Run

From the repository root:

```powershell
python tests/test_phase0_smoke.py
```

The test uses a compact CPU configuration. The production-dimension assumptions
are documented in `configs/phase0_synthetic.json`; they must be checked against
the real VLM and dataset pipeline before Stage 1 training.

## Dependency expectation

The test requires a Python environment with PyTorch, `einops`, and `timm`.
The current Codex bundled Python was checked during Phase 0 and does not include
PyTorch, so the test cannot be executed in that environment until a project
runtime is provided.
