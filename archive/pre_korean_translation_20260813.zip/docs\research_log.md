# Graph-CLaD research notebook

This file is the cumulative research history for the controlled CLaD to
Graph-CLaD study. It records decisions, evidence, blockers, and next gates so
that implementation changes remain traceable.

## 2026-08-05 - Starting point

### Research context

- Goal: test whether an oracle object-relation graph can improve CLaD latent
  foresight under a controlled comparison.
- Available from the original researchers: `LatentDynamics.py`,
  `MlpResNet.py`, and `Attentions.py`.
- Missing from the supplied code: the full Stage 1 trainer, VLM feature
  pipeline, LIBERO loader/wrapper, Stage 2 diffusion policy, rollout code,
  and official checkpoint/configuration.
- Study rule: do not claim reproduction of the official CLaD headline metric;
  compare baseline CLaD and Graph-CLaD inside the same controlled
  reimplementation environment.

## 2026-08-05 - Phase 0: baseline execution gate

### Work completed

- Preserved the original three model files without modifying their model
  logic.
- Added `baseline_code/__init__.py` so the existing relative imports execute as
  a package.
- Added `tests/test_phase0_smoke.py` with a compact synthetic CPU configuration.
- Added `configs/phase0_synthetic.json`, `docs/phase0_baseline.md`,
  `docs/unknowns.md`, and `requirements-phase0.txt`.
- Connected the project to Google Colab through the project-local MCP config in
  `.codex/config.toml`.

### Confirmed

- Training forward returns `loss_p`, `loss_s`, `loss_p_recon`, and
  `loss_v_recon`.
- Losses and evaluation embeddings are finite.
- Backward creates finite gradients.
- Evaluation returns two `[B, H]` foresight embeddings.
- EMA target initialization and momentum update behave as implemented.
- The supplied code requires `V * Dv = 2 * vl_dim` and, for the current
  addition path, `vl_dim = hidden_dim`.

### Debug record

The first smoke configuration used `visual_dim_per_view=32`, which violated
the model's `s_backbone(input_dim=vl_dim*2)` contract for two views. The test
failed with a matrix multiplication shape error. The synthetic configuration
was corrected to `visual_dim_per_view=64`; the baseline source was not
changed. The final Colab run on an A100 reported 4 tests passed in 1.748 s.

### Phase 0 gate

Passed. The model core can execute a synthetic train/eval/EMA path. This does
not verify the real VLM, dataset, LIBERO state, or trainer dimensions.

## 2026-08-05 - Phase 1: LIBERO state investigation

### Research question

Can LIBERO expose stable logical object identities, object/fixture poses,
robot end-effector and gripper state, and simulator predicates needed for an
oracle object graph?

### Source-level findings

- The LIBERO wrapper exposes the underlying simulator and flattened simulator
  state.
- The task environment maintains object, fixture, site, and object-state
  dictionaries plus a logical-name-to-body-index map.
- Object state wrappers read body position/quaternion and provide joint and
  predicate access; site wrappers provide site pose and compatible predicate
  interfaces.
- The graph identity will be the logical object name. MuJoCo `body_id` is
  runtime metadata only.

### Work completed

- Added `scripts/inspect_libero_state.py` to capture raw observation schemas,
  robot fields, object/fixture/site poses, runtime body IDs, joint/predicate
  fields, and simulator metadata.
- Added `tests/test_phase1_inspection.py` to test the schema helpers without a
  LIBERO installation.
- Added `configs/phase1_state_inspection.json`.
- Added `data/phase1_libero_state_sample.json`, explicitly labelled as a
  schema example rather than a live capture.
- Added `docs/phase1_libero_state.md` with the access contract and safeguards.

### Colab execution and compatibility record

- Uploaded the Phase 1 bundle to the open Colab notebook and ran on an A100.
- Installed the official LIBERO source with the study's diagnostic dependency
  set: `robosuite==1.4.0`, `bddl==1.0.1`, MuJoCo, and supporting packages.
- The modern Colab MuJoCo wrapper was not API-compatible with robosuite 1.4.0's
  `qM`/`mj_fullM` calls. A runtime-only patch was applied inside the Colab
  environment; the repository baseline remained unchanged.
- `IK_POSE` was not used because LIBERO's `MountedPanda` is not supported by
  that controller in this runtime. `JOINT_POSITION` is used only for zero-action
  state inspection.
- LIBERO's legacy init-state file required `torch.load(...,
  weights_only=False)` under the current PyTorch default. This was applied only
  to the trusted official local init file in Colab.

### Live result

- Fixed capture: suite `libero_spatial`, task 0, initial state 0, seed 0.
- Task: `pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate`.
- Two snapshots were captured: reset state and one zero-action step.
- Each snapshot exposed 23 object/fixture/site entries. The simulator reported
  flat state dimension 92, 38 bodies, 31 sites, 270 geoms, 18 joints, and an
  8-dimensional action.
- Raw observations included 128x128 RGB views, object pose/relation fields,
  a 70-dimensional `object-state`, 7D joint position/velocity, 2D gripper
  position/velocity, and 39D proprioception.
- The first live manifest is stored in
  `data/phase1_libero_state_capture.json`. The full capture can be regenerated
  with `scripts/inspect_libero_state.py`.

### Interpretation and limitation

Phase 1 confirms that a graph input can be grounded in stable logical names,
raw poses, robot state, and task-relevant object relations. `body_id` is kept
as runtime metadata only. Some generic object-state predicate probes returned
object-specific shape or `NotImplementedError` results; Phase 2 must use
capability-aware relation extraction and preserve missing values explicitly.

### Phase 1 status

Passed for the controlled state-access gate. The live capture is sufficient to
freeze the first GraphSpec draft; predicate coverage and normalization remain
explicit Phase 2 design decisions.

## Next gate: Phase 2

1. Freeze GraphSpec: node types, coordinate frame, normalization, edge
   features, relation thresholds, and episode-level split manifest.
2. Add two-timestep graph visualization and graph extractor tests.

## 2026-08-05 - Phase 2: GraphSpec and extractor

### Design decisions

- Frozen `phase2.v1` in `configs/phase2_graph_spec.json`.
- Nodes are `robot`, `object`, `fixture`, and `site`.
- Logical names are node identities; `body_id` is audit metadata only.
- Positions are represented in the raw world frame. Quaternion values remain
  in the audit payload but are excluded from v1 model features until ordering
  is verified.
- The common node feature vector is 24-dimensional and includes position,
  validity masks, object-of-interest flag, gripper qpos, and 7D joint position
  and velocity fields.
- Edges are complete directed spatial edges without self-loops over nodes with
  valid positions. Edge features are target-minus-source relative position,
  distance, and a validity flag. No distance threshold is used in v1 so that a
  cutoff is not silently introduced as a research assumption.
- Missing numeric values use zero plus a validity mask. Missing or failed
  predicates remain unknown and preserve their audit error.

### Implementation and tests

- Added `scripts/graph_extractor.py` as a dependency-free deterministic
  extractor and CLI.
- Added `tests/test_phase2_graph_extractor.py`; all four tests pass.
- Added `data/phase2_graph_sample.json` from the dependency-free schema fixture.

### Colab live validation

- The first Phase 2 bundle extraction failed because the Windows-created zip
  stored path separators that Linux `unzip` did not interpret as directories.
  The bundle was rebuilt with the complete `scripts` directory and extracted
  with normalized separators. This was packaging-only and did not affect graph
  logic.
- The corrected extractor ran on the full Phase 1 capture in Colab.
- Two graphs were produced, with 24 nodes and 552 directed edges per graph.
- Node types per graph: 1 robot, 5 objects, 2 fixtures, and 16 sites.
- All node positions were valid and all feature vectors were 24-dimensional.
- Predicate audit per graph: 55 errors, 12 available values, and 2 unsupported
  values. These were preserved as unknown, never coerced to false.
- The compact live result is stored in
  `data/phase2_live_graph_manifest.json`.

### Phase 2 status

GraphSpec and deterministic extraction gate passed. The next research decision
is whether to compare this complete spatial topology against radius-limited
and predicate-augmented ablations before integrating it into latent foresight.

## 2026-08-05 - Literature-based Phase 1/2 reassessment

### Sources reviewed

- G-DOOM, *Learning Latent Graph Dynamics for Visual Manipulation of
  Deformable Objects* (arXiv:2104.12149v2).
- *Planning for Multi-Object Manipulation with GNN Relational Classifiers*
  (arXiv:2209.11943v2).

The papers were reviewed beyond their abstracts, including graph construction,
action-conditioned dynamics, losses, multi-step prediction, experiments, and
ablations.

### Findings that change the interpretation of the current work

- The reset plus one zero-action capture proves state access and deterministic
  extraction, but cannot supervise action-conditioned graph dynamics or
  relation changes.
- The current Phase 2 graph is a static oracle snapshot representation, not yet
  the oracle graph dataset required for an offline relational-dynamics probe.
- Current relation detection alone is not an adequate graph test. The primary
  target must be post-action relation prediction, especially on relations that
  actually change.
- Fully connected directed topology remains a justified baseline. A
  paper-faithful relational-classifier baseline should begin with empty edge
  input; hand-engineered geometry edge features must be a separate variant.
- G-DOOM motivates separate tests for action conditioning, recurrent history,
  learned soft edges, multi-step rollout, pooling, and dynamics objectives.
- The relational-classifier paper does not report a correct-edge versus
  shuffled-edge experiment. That control remains useful but is an original
  Graph-CLaD validation choice, not a direct paper reproduction.
- The v1 `is_object_of_interest` feature and the large number of site nodes may
  create privileged task/layout shortcuts. They will be removed from the core
  v2 input and retained only as explicit ablations.
- Generic predicate probing remains useful for diagnostics but must not become
  training labels. A capability-aware relation labeler with validity masks is
  required.

### Revised phase status

- **Phase 1a: passed.** LIBERO API access, logical identity, raw pose, robot
  state, and missing-value behavior were verified.
- **Phase 1b: reopened.** Nonzero-action trajectories, action/target temporal
  alignment, episode-level split, and relation labels remain to be built.
- **Phase 2a: passed.** `phase2.v1` static GraphSpec and deterministic extractor
  are preserved as the first reproducible baseline.
- **Phase 2b: reopened.** The graph transition dataset, relation-change targets,
  expanded leakage/consistency tests, and two-time visualization remain to be
  completed.

This reclassification does not invalidate previous results; it narrows what
those results demonstrate. No Phase 1/2 code or v1 configuration was silently
overwritten.

### New artifacts

- `docs/literature_alignment_and_phase_reassessment.md`: detailed paper-to-
  phase comparison and modification decisions.
- `docs/revised_research_roadmap_v2.md`: executable Phase 2R, Phase 3, and
  Phase 4 plan with gates and controls.
- `configs/phase2_graph_spec_v2_draft.json`: machine-readable draft for future
  trajectory, relation, topology, split, and evaluation implementation.

### Next gate

Run Phase 2R before training a GNN or integrating graph features into CLaD.
The first deliverable is a nonzero-action, episode-split graph transition
dataset with capability-aware current/future relation labels and verified
time alignment.

## 2026-08-05 - Phase 1b / Phase 2R controlled Colab pilot

### Execution

- Added `scripts/collect_libero_trajectory.py` for bounded deterministic
  nonzero-action LIBERO oracle trajectories.
- Added `scripts/build_phase2r_dataset.py` for action-conditioned graph
  transitions, relation validity, changed-relation masks, and episode splits.
- Added `tests/test_phase2r_dataset.py`; local pure-Python checks and bytecode
  compilation passed. The bundled local Python runtime did not include pytest,
  so the tests were exercised through equivalent direct assertions.
- Uploaded `phase2r_bundle.zip` to the open `Graph-CLaD.ipynb` Colab session.
- A packaging-only path error occurred because Windows `Compress-Archive`
  flattened the bundle entries. The Colab path was corrected and the pilot was
  rerun successfully.

### Live pilot result

- Suite/task: `libero_spatial`, task 0, four initial states, seed 0.
- Controller: `JOINT_POSITION`; action dimension 8; bounded deterministic
  nonzero probe amplitude 0.025.
- Four episodes, 24 action steps each, 96 nonzero actions.
- Primary horizon `tau=6`: 76 eligible transition samples.
- Episode split: 2 train episodes, 1 validation episode, 1 test episode.
- Primary graph: 8 nodes and 56 directed edges per graph; sites excluded;
  `is_object_of_interest` removed from core feature values.
- Changed-relation count: 194 across the pilot sample set.
- Valid relation counts: 4,256 for each geometric/contact relation family;
  changed counts were left/right 1/1, front/behind 0/0, above/below 86/86,
  contact 20. Semantic on/inside/holding/open/close labels remained invalid.
- Coordinate frame is explicitly marked `raw_world_pilot`; robot-base or
  task-local frame must be frozen before scaling up.

### Interpretation and gate status

The Phase 1b temporal contract, nonzero action coverage, logical alignment, and
episode-disjoint split executed successfully. This is enough to proceed to a
small offline data/label quality probe, but not enough to claim manipulation
success or a final relation schema. The large compact transition archive was
created in Colab at `/content/phase2r_compact_results.zip`; the local
reproducibility manifest is `data/phase2r_pilot_summary.json`.

Phase 2R status: **pilot execution passed; scale-up gate remains open** until
the coordinate frame is frozen and capability-aware semantic relation handlers
are implemented. The next execution should inspect relation changes visually,
then collect relation-critical LIBERO tasks or replay demonstrations before
Phase 3 model training.

## 2026-08-05 - Phase 2R pilot validation

### Validation execution

- Added `scripts/validate_phase2r_pilot.py` and its pure validation test.
- Ran the checker in the active Colab session on all 76 `tau=6` samples.
- Rendered and visually inspected a before/after top-down graph audit plot.
- Corrected one validation-code issue: the initial coordinate-frame string
  check did not recognize the full `raw_world_pilot; ...` annotation. The
  checker was patched and rerun.

### Validation result

- Overall structural validation: **pass**.
- Invalid samples: 0.
- Duplicate node graphs: 0.
- Reverse directed-edge violations: 0.
- Inverse relation violations: 0.
- Feature-dimension violations: 0.
- Action-window length violations: 0.
- Temporal alignment violations: 0.
- Episode split remained disjoint.
- All 194 directed relation changes were non-robot changes: 83
  object-to-fixture, 83 fixture-to-object, and 28 object-to-object entries.
- Collapsing inverse directions produced 17 changed undirected relation pairs.
- Changes were 86 above, 86 below, 20 contact, and 1/1 left/right.

The visual audit showed stable logical IDs and consistent x/y axes between the
two snapshots, with no obvious robot-node-driven change. This supports the
dataset alignment and topology implementation, but it does not yet prove that
the raw-world axis definition is the correct research frame.

### Open gates

- Semantic `on`, `inside`, `holding`, `open`, and `close` labels are still
  invalid and cannot be used as training targets yet.
- The coordinate frame is still `raw_world_pilot`; robot-base or task-local
  frame must be frozen before scale-up.
- The local reproducibility summary is stored at
  `data/phase2r_validation_summary.json`. The detailed report and plot remain
  in the active Colab runtime at
  `/content/Graph-CLaD-phase2r/data/phase2r_validation_report.json` and
  `/content/Graph-CLaD-phase2r/data/phase2r_change_audit.png`.

Phase 2R structural validation is **passed with design gates open**. Phase 3
offline model comparison should wait until those two gates are resolved.

## 2026-08-05 - Robot-base and semantic predicate validation

### Robot-base frame

The LIBERO `robot0_base` body was checked across init states 0, 1, 2, and 3
for task 0. Its pose was identical in all four episodes:

- position: `[-0.66, 0.0, 0.912]`
- raw quaternion: `[1.0, 0.0, 0.0, 0.0]`
- maximum position range: `[0.0, 0.0, 0.0]`
- maximum quaternion range: `[0.0, 0.0, 0.0, 0.0]`

The primary frame decision is therefore **robot-base**. The current pilot
graph remains marked `raw_world_pilot`; the next dataset build must subtract
this fixed base pose before storing model-facing node positions. Pairwise edge
relative positions are translation-invariant, but node features and frame
metadata must still be updated explicitly.

### Semantic API audit

LIBERO object wrappers expose `check_contact(other)`, `check_contain(other)`,
and `check_ontop(other)`, but their behavior is capability-dependent:

- `check_contact` returned a boolean for all five tested object/site pairs and
  is a viable contact label handler.
- `check_ontop` returned a boolean for the object-object pair but raised
  `KeyError` for tested site pairs.
- `check_contain` raised object-specific `AttributeError` or site `KeyError`
  for the tested pairs.
- generic `is_open`, `is_close`, and `get_joint_state` calls produced shape,
  `NotImplementedError`, or `NoneType` failures depending on wrapper type.

The semantic decision is to use the contact wrapper, while implementing
`on`, `inside`, `holding`, `open`, and `close` through task-specific or
geometry-based handlers with explicit validity masks. Generic predicate
errors must remain unknown rather than being converted to false.

The reproducibility summary was updated at
`data/phase2r_validation_summary.json`; the reusable audit implementation is
`scripts/validate_phase2r_semantics_frame.py`.

### Current gate status

- structural/time/topology validation: **passed**
- robot-base stability validation: **passed**
- contact relation handler: **candidate passed**
- generic semantic relation handler: **not passed**
- final v2 dataset frame/semantic contract: **still open**

## 2026-08-05 - Phase 2R final robot-base dataset and semantic handlers

### Implementation

- Added `scripts/phase2r_relation_handlers.py` for the model-facing frame
  transform and capability-aware relation labeling.
- The collector now records `robot_base_pose`, robot contact pairs, per-pair
  `on`/`inside` wrapper results, and conservative MuJoCo geometry metadata.
- `build_phase2r_dataset.py` now defaults to `robot_base`, transforms positions
  by subtracting `robot0_base` and inverse-rotating with the MuJoCo `wxyz`
  quaternion, and preserves frame provenance in the dataset.
- `on` uses boolean `check_ontop` results when available and otherwise only a
  support-surface-candidate AABB fallback.
- `inside` uses target-side boolean `check_contain` when available. A generic
  overlapping AABB is not sufficient: the geometry fallback requires explicit
  `containment_capable` metadata.
- `holding` is valid only when a robot-object contact and a closed-gripper
  condition (`abs(gripper_qpos) <= 0.01`) are both available.
- `open` and `close` are retained as node-level predicates and are not copied
  onto every directed edge. Unsupported values remain unknown (`valid=0`).

### Final controlled Colab execution

- Bundle: `phase2r_v2_bundle_r3.zip`.
- Suite/task: `libero_spatial`, task 0; init states 0–3; seed 0.
- Four episodes, 24 steps per episode, tau 6, 76 samples, 96 nonzero
  actions, episode-disjoint train/validation/test split.
- All 100 snapshots contained a robot-base pose and geometry metadata.
- Dataset frame: `robot_base`; raw capture remains available as audit input.
- Relation statistics: `on` valid 1,477, `inside` valid 0,
  `holding` valid 532, `open`/`close` valid 0. The zero counts are deliberate
  for this task and schema, not an implicit false label.
- Changed relations: 194, with no robot-involved changes; the relation-change
  pattern remained 86 above, 86 below, 20 contact, and 1/1 left/right.

### Validation result

- Final validator status: **pass**.
- Invalid samples, duplicate node graphs, reverse-edge violations,
  inverse-relation violations, feature-dimension violations, action-length
  violations, and temporal-alignment violations: all zero.
- All reported gates were true, including semantic label contract and final
  coordinate-frame finalization; the visual audit plot was regenerated.

### Interpretation and next step

Phase 2R pilot final gate is **passed with task-coverage limits**. The dataset
is ready for a controlled Phase 3 offline relational-dynamics probe on this
pilot. Before making broad claims about `inside`, `open`, or `close`, collect
relation-critical tasks with explicit containment capability metadata and keep
the node-state representation for open/close unless the graph schema is
explicitly extended.

## 2026-08-05 - Phase 2R scale-up verification and containment correction

### Scope and protocol

The pilot contract was scaled to 15 task families across four LIBERO suites:
`libero_spatial` tasks 0--9, `libero_90` tasks 0--2, `libero_goal` task 0, and
`libero_object` task 0. Each task used init states 0 and 1, seed 0, a
24-step bounded deterministic nonzero action probe, and tau 6. This produced
30 episodes, 750 snapshots, 570 graph-transition samples, and 720 nonzero
actions. The final graph build used `robot_base` coordinates and
`include_all_sites` so relation targets such as drawer regions remain graph
nodes.

### Issue found and correction

The first r3 upload unpacked the ZIP contents at the root instead of under
`scripts/`. Because an earlier `scripts` namespace was already loaded in the
Colab kernel, the first recollection silently reused the old collector. Its
episodes had no `task_semantics` and no site geometry, so `inside` remained
zero even though the code change existed locally.

The execution was corrected by restoring the `scripts/` path, removing cached
`scripts.*` modules, verifying the loaded collector path, and recollecting the
relation-critical suites. The corrected collector parsed the task-2 BDDL goal
`In(akita_black_bowl_1, wooden_cabinet_1_top_region)` and recorded the target
site's oriented MuJoCo AABB with `containment_capable=true` in every snapshot.

### Final scale-up result

- Validator status: **pass**.
- All gates were true: structural validation, at least two task families,
  robot-base pose stability per task, geometry presence, and semantic coverage.
- Robot-base pose was present and stable in all 750 snapshots; per-task
  position and quaternion ranges were `[0, 0, 0]` and `[0, 0, 0, 0]`.
- Geometry metadata was present in all 750 snapshots.
- Dataset-valid semantic records: `on=37,070`, `inside=988`, and
  `holding=11,704`. The validator counted `inside` coverage in both endpoint
  graphs for `libero_90:2` (912) and `libero_object:0` (1,064).
- Node-level `open`/`close` records were valid for all 15 task families;
  they remain node predicates rather than pairwise edge labels.
- The bounded probe produced 140 validator-counted `on` changes, but no
  `inside` or `holding` changes. This is a coverage/alignment result, not a
  claim of manipulation success or learned future dynamics.

The reproducibility summary is stored at
`data/phase2r_scaleup_summary.json`; the reusable structured bundle is
`phase2r_scaleup_bundle_r3_structured.zip`. The detailed live report is in
the Colab runtime at
`/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2r_scaleup_report.json`.

### Decision and next step

The frame and relation-handler gates are now **passed for controlled scale-up**.
`inside` is no longer blocked at the handler/schema level, provided the target
is an explicit BDDL `In` target. The next research step is Phase 3: compare
MLP/flat-edge and GNN relational-dynamics probes using episode-disjoint splits,
while adding targeted successful manipulation trajectories before claiming
that the model predicts semantic relation transitions.

## 2026-08-05 - Phase 3 offline relational-dynamics probe

### Experiment

The first offline probe was executed on the final Phase 2R scale-up dataset in
Colab. It used the same `robot_base` graph/action contract, six-step action
windows, train-only normalization, episode-disjoint splits, and three seeds per
model. The split contained 532 train samples, 19 validation samples, and 19
test samples. The test episode was `libero_spatial:task9:init1:seed0`.

The following models were compared:

- P0 flattened node-set MLP
- P1 independent node encoder without message passing
- P2 fully connected GNN with empty edge input
- P3 GNN with geometry edge input
- P4 GNN with geometry edge input and learned soft edge attention

Zero-action, shuffled-action, and shuffled-sender/receiver controls were also
evaluated without retraining.

### Results

Changed-relation macro-F1 mean/std across three seeds:

| Model | Mean | Std | Parameters |
|---|---:|---:|---:|
| P0 flat MLP | 0.2640 | 0.0330 | 92,244 |
| P1 node-only | 0.7873 | 0.0811 | 43,988 |
| P2 empty-edge GNN | **0.8576** | 0.0496 | 60,692 |
| P3 geometry-edge GNN | 0.8506 | 0.0305 | 78,036 |
| P4 soft-attention GNN | 0.7896 | 0.0699 | 86,677 |

P2 was the best provisional model. P3 and P4 showed large changed-F1 drops
under shuffled-edge control (P3: 0.8506 to 0.3837; P4: 0.7896 to 0.3777),
which supports that edge assignment is being used. P3 did not beat P2, so
geometry-edge superiority is not established.

### Interpretation and gate status

This is evidence for a relational-dynamics signal in the controlled spatial
split, not yet a broad CLaD improvement claim. The test episode contains
changed-relation support mainly for `above`, `below`, and `on`; `inside` and
`holding` have no test support. The models are also not exactly parameter
matched, so the Phase 3 gate remains **provisional / open**.

The implementation is `scripts/phase3_offline_probe.py`, the run settings are
`configs/phase3_offline_probe.json`, the full summary is
`data/phase3_offline_probe_summary.json`, and the method note is
`docs/phase3_offline_probe.md`.

### Required Phase 3 iteration

Before selecting a graph adapter for Phase 4, create a relation-critical
task-family-held-out split, include `inside` and `holding` in validation/test,
rerun with matched parameter budgets, and add the P5 history model after past
graph sequences are captured.

## 2026-08-05 - Phase 3 task-family-held-out matched revalidation

### Protocol

The required revalidation was executed in Colab with CUDA on the final
570-sample `robot_base`, `include_all_sites` dataset. The split was performed
by task family, not by individual transition: 380 train samples, 76
validation samples, and 114 test samples. Validation families were
`libero_90:1` and `libero_spatial:8`; test families were `libero_90:2`,
`libero_goal:0`, and `libero_object:0`. P0--P4 were each run with seeds 0, 1,
and 2. Hidden widths were selected independently to stay near a 70,000
parameter target.

### Result

| Model | Future macro-F1 | Changed macro-F1 | Inside F1 |
|---|---:|---:|---:|
| P0 flat MLP | 0.6585 ± 0.0124 | 0.1394 ± 0.0299 | 0.2309 ± 0.1075 |
| P1 node-only | 0.6081 ± 0.0010 | 0.1289 ± 0.0169 | 0.1181 ± 0.0249 |
| P2 empty-edge GNN | 0.5819 ± 0.0083 | **0.2223 ± 0.0676** | 0.0623 ± 0.0881 |
| P3 geometry GNN | 0.6229 ± 0.0099 | **0.2222 ± 0.0361** | 0.2018 ± 0.0392 |
| P4 soft-attention GNN | 0.6070 ± 0.0154 | 0.1998 ± 0.0425 | 0.0791 ± 0.1119 |

P2 and P3 improve changed-relation F1 over P0 by approximately 0.083, but P0
remains strongest on overall future macro-F1. This suggests a possible
relation-change benefit rather than a general prediction benefit.

### Gate review and discovered data issue

- **Passed:** all 15 model/seed runs completed; task-family split was
  disjoint; parameter matching was enabled; `inside` had positive test
  support (76 positives per seed).
- **Not passed:** correct-action performance was not better than no-action or
  shuffled-action controls, and shuffled-edge performance was not consistently
  worse than correct-edge performance. Action-conditioned foresight and causal
  edge use are therefore not established.
- **Holding coverage:** the test had 1,900 valid mask positions per seed but
  zero positive holding labels. The graph did not exclude `robot0`; the actual
  issue was that the collector recognized only `robot0*` body names while the
  MuJoCo runtime emitted `gripper0_*` contacts, and the old gripper threshold
  was too strict for an object held between the fingers. The earlier Phase 2R
  semantic count of `holding=11,704` was a valid-record count, not a count of
  positive holding examples.

Phase 3 remains **open**. The follow-up collection fixes the contact mapping
and threshold and demonstrates positive labels, but its six-episode spatial
scale-up has positives only for task 0 and task 1; task 2 has contact but no
positive holding label. Before Phase 4, rebuild the matched task-family-held-
out probe with sufficient holding-positive coverage and purposeful
manipulation trajectories so the no-action control is meaningful.

The exact structured result is stored in
`data/phase3_taskheldout_matched_summary.json`; the Colab report is
`/content/Graph-CLaD-phase2r-scaleup-r3/data/phase3_taskheldout_matched_report.json`.

## 2026-08-06 - Holding-positive collection follow-up

### Motivation and correction

The previous Phase 3 note incorrectly described `robot0` as absent from the
graph. `scripts/graph_extractor.py` already creates the `robot0` node and
`scripts/build_phase2r_dataset.py` preserves it. The real failure was at the
collector/runtime boundary: LIBERO's MuJoCo contacts use `gripper0_*` body
names, which were not mapped to logical `robot0`. In addition, the original
`|gripper_qpos| <= 0.01` closure test rejected grasps where the object keeps a
finger slightly open.

### Changes

- `scripts/collect_libero_trajectory.py` now maps `gripper0_*` contacts to
  `robot0` and adds a reproducible OSC-Pose approach-close-lift probe.
- `scripts/phase2r_relation_handlers.py` calibrates the default closure
  threshold to `0.025` for the Colab LIBERO Panda runtime.
- `scripts/build_phase2r_dataset.py` records and exposes the threshold used for
  relation labeling.
- Collector and dataset tests cover gripper-body contact normalization and the
  holding probe's open/close/lift action signs.

### Colab result

The pilot used one `libero_spatial` task-0 episode, 64 steps, `OSC_POSE`, and
the `holding_probe` mode. It produced 10 positive holding labels and 10
holding transitions after rebuilding with `gripper_closed_threshold=0.025`.

The scale-up used task IDs 0, 1, and 2 with init states 0 and 1, for six
episodes and 354 graph samples after horizon filtering. It produced 5,170
changed relation records, 384 nonzero-action snapshots, and 34 holding
transitions. Holding transitions by episode were 10, 18, 44, and 42 for
`task0/init0`, `task0/init1`, `task1/init0`, and `task1/init1`; task 2 had
robot-contact snapshots (17 and 19) but no positive holding label. The full
structured audit is stored in `data/phase2r_holding_probe_summary.json` and
the live dataset is `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2r_holding_spatial_dataset.json`.

### Decision

The holding-label collection check **passed with partial task coverage**.
This resolves the implementation bug but does not close Phase 3: the matched
task-family-held-out evaluation must be rebuilt with enough positive holding
support, including a held-out family that actually contains positive holding
states. Action-conditioned and shuffled-edge gates remain open.

As a targeted follow-up, task 2 was recollected for two init states with 96
steps and a 32-step close phase. The resulting dataset had 182 graph samples
and zero holding transitions. We therefore keep the calibrated threshold
unchanged and treat task 2 as requiring task-specific EEF approach/grasp
alignment calibration, not a global label-threshold change.

## 2026-08-06 - Full research audit and roadmap v3

### Scope

The supplied CLaD modules, Phase 0-3 scripts and tests, structured result
summaries, research notes, the 26-page controlled research execution plan,
and the CLaD/G-DOOM/relational-classifier literature notes were reviewed
together. The purpose was to decide which previous artifacts remain valid and
which assumptions must change before collecting more holding data.

### Main findings

- Phase 0, Phase 1A, and the static Phase 2A extractor remain valid controlled
  infrastructure.
- Phase 2R scripted trajectories are useful regression fixtures, but they are
  not suitable as the main dynamics dataset. Repeated probe actions do not
  provide a sufficiently identifiable action-conditioned manipulation
  distribution.
- The current holding fallback is a single-frame `contact AND closed_qpos`
  rule. It verifies the contact plumbing but cannot reliably distinguish
  grasping from pushing, transient collisions, or empty gripper closure.
- The current Phase 2R builder stores only `graph_t`, one six-step action
  window, and `graph_target`. Past graph history and 1/3/6 multi-horizon
  targets described by the earlier roadmap were not implemented.
- The tuple `G_t + action[t:t+tau] -> G[t+tau]` is appropriate for an
  action-conditioned forward-dynamics probe, but the target-interval action is
  not available to CLaD Stage 1 at decision time. Feeding it directly to the
  graph adapter would leak future actions.
- The Phase 3 field named `changed_relation` measures future relation-value F1
  only at ground-truth changed positions. It is not a direct change-event F1;
  onset, offset, and XOR-derived event metrics must be added.
- A shuffled-topology claim is ill-defined for a fully connected empty-edge
  graph because all node pairs already exist. No-message is the main control
  there; edge-attribute permutation is appropriate for geometry/learned-edge
  variants.
- The flat P0 MLP does not receive source/target node features in the same way
  as P1-P4 and is ordering-sensitive. A pairwise or DeepSets-context
  non-message model is required as the primary fair baseline.
- Task relevance can leak through node selection even after the explicit
  `is_object_of_interest` feature is zeroed. The new primary node inventory
  must be independent of the BDDL goal; goal metadata is label/audit only.

### Decision

Manual task-2 holding calibration is stopped as a research-data strategy. The
next stage is **Phase 2D**, which converts all official task 0, 1, and 2
demonstrations into a LIBERO demo-derived, event-centered, multi-horizon oracle
relational dynamics dataset.

The primary label path will restore each saved MuJoCo state and extract the
graph from that state. Saved actions will condition transitions; action replay
will be used only on a subset for consistency auditing. The full trajectory is
preserved, while contact, holding, lift, release, on, inside, and geometric
relation events are stored as indices. Positive events, hard negatives, and
background are selected by the training sampler without duplicating physical
data.

The canonical timeline will emit two non-mixed sample views: View A uses the
executed target-interval action to test action-conditioned graph forward
dynamics, while View B uses only past/current graphs and past actions to match
CLaD's causal foresight boundary. Phase 4 requires both the forward-dynamics
gate and the CLaD-aligned bridge gate.

Holding is redefined as a temporal state machine:

```text
free -> contact_candidate -> holding -> release
```

The evidence includes finger-specific contact, closed-gripper state,
K-frame object-EFF relative-pose stability, object-follow/lift evidence, and
hysteresis. Ambiguous frames are invalid rather than negative.

Demo-ID split is fixed before any threshold, normalization, or sampling.
In-task episode-held-out and task-generalization (`task0+1` train,
`task2` test) protocols will both be reported. If task 2 naturally contains no
holding positives, the relation-specific metric is reported as unsupported
rather than manufacturing positives or lowering the threshold after seeing
test data.

### Status and artifacts

- Current phase: **Phase 2D-D0/D1 pending official demo acquisition and state
  replay handshake**.
- Phase 3 historical results: preserved as diagnostic, gate open.
- Phase 4: blocked until Phase 2D dataset QA and revised Phase 3 controls pass.
- New audit: `docs/03-analysis/graph-clad-research-roadmap.analysis.md`.
- Current roadmap: `docs/revised_research_roadmap_v3.md`.
- `docs/revised_research_roadmap_v2.md` is retained as historical context.

### Local verification note

A local full pytest rerun was attempted during the audit. The default Python
launcher was unavailable in the current desktop session and the bundled
Python runtime did not include pytest. No model or dataset code was changed in
this audit; prior Colab execution records remain historical evidence, and the
new Phase 2D implementation will require its own tests before data scale-up.

## 2026-08-06 - Phase 2D-D0/D1 official demo replay handshake

### Execution

The official LIBERO repository downloader was run in the active Colab runtime
with the Hugging Face mirror option for `libero_spatial`. It produced 10 task
HDF5 files, each with 50 demonstrations. The first three task files were
inspected; task 0/demo 0 contains `states (98, 92)`, `actions (98, 7)`,
`robot_states (98, 9)`, and a terminal done at step 97.

The task-0/demo-0 state replay handshake passed: restoring states 0, 1, 10,
and 97 through LIBERO's `env.set_init_state()` reproduced the simulator flat
state with maximum absolute error `0.0`. The initial implementation attempted
to call a non-existent `MjSimState.set_flattened()` method; this was corrected
by using the runtime-supported LIBERO setter. Action replay was then audited
with the matching `OSC_POSE` controller. The stored 7-D action ran, but the
resulting next simulator state differed from the stored next state by max
absolute error `0.098253` (`qpos` max error `0.005404`). This confirms that
state replay is the label source and action replay is an audit only.

### D1/D2 artifacts in Colab

The full 98-frame demo was restored state-by-state and extracted into:

- `/content/Graph-CLaD-phase2r-scaleup-r3/data/libero_spatial_task0_demo0_state_replay_raw.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/libero_spatial_task0_demo0_state_replay_relations_v2.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/libero_spatial_task0_demo0_graph_timeline.json`

The relation timeline uses raw MuJoCo gripper contacts, robot-base positions,
explicit geometry/wrapper records, and a temporal holding machine. The task 0
demo yielded 45 robot-contact frames for the target bowl, one holding interval
from step 43 through 87, and a release at step 88. The resulting graph timeline
has 98 graph snapshots, 24 nodes, 552 directed spatial edges per snapshot,
324 one-step relation-change events, and 284 multi-horizon sample-index rows
for horizons 1/3/6. Actual HDF5 action windows were attached after the first
timeline write; the dataset metadata marks the causal CLaD view separately.

The first contact extraction pass returned no robot contacts because the
runtime uses names such as `gripper0_leftfinger` and
`gripper0_finger_joint*_tip`. The raw MuJoCo audit showed those contacts, so
the mapping was corrected rather than treating the pass as negative evidence.
The local collector now accepts robot/gripper tokens anywhere in a decoded
body name, with a regression test for byte-string and suffixed runtime names.

### Status

At the time of this entry, Phase 2D-D0/D1 was **executed for one official
demonstration and passed the state-replay gate**. The later full-demo scale-up
and its QA are recorded in the following entry.

## 2026-08-06 - Phase 2D full task 0/1/2 demo conversion and split QA

### Execution

The deterministic Phase 2D pipeline was applied to all 150 official
`libero_spatial` demonstrations used in scope: task 0, task 1, and task 2,
with 50 demos per task. The split manifest was created before label extraction
and threshold fitting. Each saved HDF5 simulator state was restored directly;
the restored state, robot-base graph, raw contact evidence, temporal holding
state machine, relation events, and multi-horizon sample index were then
written to a task-specific compressed JSONL dataset. Stored actions were kept
as transition-conditioning windows and were not replayed to create labels.

### Dataset coverage

| task | demos | frames | robot-contact frames | holding frames | indexed samples |
|---|---:|---:|---:|---:|---:|
| 0 | 50 | 5,068 | 2,259 | 1,991 | 14,704 |
| 1 | 50 | 5,882 | 3,217 | 2,993 | 17,146 |
| 2 | 50 | 7,479 | 4,161 | 4,041 | 21,937 |
| total | 150 | 18,429 | 9,637 | 9,025 | 53,787 |

The sample-index horizon counts were, respectively, 18,279 for horizon 1,
17,979 for horizon 3, and 17,529 for horizon 6. Every task had 50 unique
demo records and no duplicate demo key. The maximum state-replay error was
`0.0` for each task.

### Split and integrity QA

The manifest contains 150 demo assignments. The in-task episode-held-out
counts are train 113, validation 19, and test 18. The task-generalization
protocol assigns task 0 and task 1 to train (100 demos) and task 2 to test
(50 demos). The split assignments in all three compressed datasets exactly
match the manifest; split-ID mismatch count is zero. The corrected split QA
returned `PASS`, as did the dataset coverage QA.

### Colab artifacts

- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_demo_split_manifest.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task0_graph_dataset.jsonl.gz`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task1_graph_dataset.jsonl.gz`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task2_graph_dataset.jsonl.gz`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task0_coverage_qa.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task1_coverage_qa.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_task2_coverage_qa.json`
- `/content/Graph-CLaD-phase2r-scaleup-r3/data/phase2d_full_demo_dataset_summary.json`

### Decision

The full-demo extraction and split/coverage gate passed. Phase 2D data
construction is complete for the scoped task 0/1/2 suite. The next gate is a
relation-support and event-label audit, followed by the revised Phase 3
forward-dynamics controls using both the executed-action View A and the
CLaD-aligned View B. Phase 4 remains blocked until those controls pass.

## 2026-08-06 - Phase 2D relation audit preparation and Colab runtime check

### Execution status

The next gate was started, but the Colab connection available to the agent
was a fresh runtime. The notebook history still displayed the prior full-demo
QA output, while the runtime filesystem had no
`/content/Graph-CLaD-phase2r-scaleup-r3` directory and no `phase2d_*`
artifacts. Therefore no relation-support counts were inferred from notebook
history alone, and no new full-dataset audit result is claimed in this entry.

### Reproducible audit tool

Added `scripts/audit_phase2d_relations.py`. It accepts the three compressed
JSONL task files and reports, per task:

- valid, positive, and invalid counts for spatial/contact/on/inside/holding/
  open/close relations;
- event names and holding-state tokens;
- holding evidence fields (`finger_contact`, `closed_gripper`,
  `relative_pose_stable`, `object_followed_eef`);
- relation-change counts and horizon coverage;
- missing action-window metadata, future-action fields, and goal/task metadata
  found inside graph input fields.

The script passed a local compile check and a synthetic holding/event smoke
test. It deliberately reports unsupported relations as missing valid labels,
not as negative labels.

### Pending action

Restore the runtime containing the Phase 2D files, or upload the three task
JSONL files and split manifest to the new runtime. Then run the audit before
starting Phase 3. The runtime reset is an execution-environment issue, not a
research result or a reason to advance to Phase 4.

## 2026-08-06 - relation audit retry

The relation audit was retried after reconnecting to the notebook URL. The
available Colab runtime was again a fresh filesystem: the Phase 2D project,
all `phase2d_*` files, LIBERO HDF5 files, and a mounted Drive directory were
absent. The audit therefore did not run on substitute or historical summary
data. Restoring the original runtime or uploading the saved dataset artifacts
is required before the relation gate can produce a valid result.

## 2026-08-06 - persistent Drive recovery bundle

To make runtime resets non-blocking, the official task-0/1/2 HDF5 inputs,
150-demo split manifest, restored project scripts/configuration, and SHA256
metadata were copied to the persistent Drive root
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d`. The local recovery
policy is documented in `docs/colab_runtime_persistence.md`.

The current runtime does not contain a newly generated graph JSONL release.
The graph outputs are intentionally not reconstructed from notebook history:
the fresh runtime first lost the generated files, then encountered a
robosuite/MuJoCo controller incompatibility, and a failed MuJoCo version
attempt left NumPy imports inconsistent. The preserved HDF5 and manifest are
the authoritative inputs for the next clean runtime. Phase 3 and Phase 4
remain gated.

## 2026-08-06 - clean-runtime continuation and reproducibility correction

The user reconnected the Colab notebook and the persistent Drive bundle was
restored again. A clean single-demo preflight now passes with Python 3.12.13,
NumPy 1.26.4, MuJoCo 3.11.0, `robosuite==1.4.1`, and a runtime-only
compatibility patch in `robosuite/controllers/base_controller.py` that calls
MuJoCo 3's `mj_fullM(model, data, destination)` API.

State replay for the first three saved HDF5 states has maximum absolute error
`0.0`. The robot-base graph smoke test produces 8 selected nodes and 56
directed edges. This validates environment restoration and graph extraction,
but it is not a full-dataset result.

The restored relation handler was inspected before scale-up. Its fallback
`holding` predicate is still frame-local (`robot-object contact AND closed
gripper`). It does not itself enforce the planned K-frame relative-pose and
object-following evidence. The scale-up must therefore add the temporal
holding state machine as a dataset post-processing step and record its
evidence, state transitions, and invalid cases. Until the resulting files and
QA are present under Drive, any older notebook-history claim of a 150-demo
completion is treated as stale and is not promoted as an execution result.

## 2026-08-06 - Phase 2D full-demo rerun, contact fix, and split repair

### Root cause of the temporary `holding=0` result

The official HDF5 states did contain robot-finger/object contacts. The Colab
runtime had loaded an older in-memory/file version of `_contact_pairs` that
recognized `robot0_*` bodies but not LIBERO's runtime names such as
`gripper0_leftfinger` and `gripper0_finger_joint*_tip`. Therefore raw MuJoCo
contacts existed while `robot_contact_pairs` was empty, causing the temporal
holding state machine to produce zero positives. The corrected mapper restores
these bodies to the logical `robot0` node.

A representative official task-0 demo then reproduced the expected evidence:
45 robot-contact frames, 38 holding frames, holding interval 50--87, and
release at step 88. This confirms that the earlier successful result and the
new result are consistent after the runtime code path is corrected.

### Full rerun and QA

The corrected temporal pipeline was rerun on all 150 official demonstrations
(task 0/1/2, 50 demos each) using direct HDF5 state replay. The run completed
in 3062.57 seconds with exact state replay (`max_abs=0.0`) and no task errors:

| task | demos | frames | robot-contact frames | holding frames | holding intervals | samples (tau 1/3/6) |
|---|---:|---:|---:|---:|---:|---|
| 0 | 50 | 5,068 | 2,259 | 1,828 | 69 | 5,018 / 4,918 / 4,768 |
| 1 | 50 | 6,707 | 3,375 | 2,730 | 67 | 6,657 / 6,557 / 6,407 |
| 2 | 50 | 5,882 | 3,217 | 2,653 | 59 | 5,832 / 5,732 / 5,582 |

The first completed output exposed a separate split-join bug: the manifest
uses `demo_key` values (`demo_0`, `demo_1`, ...) while the generator looked up
integer `(task_id, demo_id)` keys. A streaming rewrite repaired only the split
field, preserving the generated labels and graph records. Final artifact:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_full_demo_v2_splitfixed_stream1`

Manifest:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/phase2d_full_demo_splitfixed_stream1_manifest.json`

Final QA passed for all tasks: 150 records per task, zero null split records,
zero split-manifest mismatches, zero replay error, and no recorded errors.
The unrepaired `phase2d_full_demo_v2` output is retained as an intermediate
traceability artifact; it is not the dataset to use for training or Phase 3.

### Gate status

Phase 2D data construction and coverage QA are now complete for the scoped
official demonstrations. The next gate is the relation-support audit and
revised Phase 3 forward-dynamics evaluation. Phase 4 remains blocked until
the action-conditioned, no-action, shuffled-action, and shuffled-edge controls
are run on the repaired fixed splits.

## 2026-08-06 - Phase 2D relation and event audit completed

The interrupted relation/event audit was resumed on the final split-fixed
artifact, not on the intermediate pre-repair output. Task 0 initially caused
the runtime to terminate during the first large traversal; the audit was then
rerun with a streaming, lower-overhead traversal that checks the same contract
without recursively walking every graph field. All three task reports were
written to the persistent Drive dataset directory:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_full_demo_v2_splitfixed_stream1/phase2d_relation_audit_task{0,1,2}.json`

### Audit results

| task | h1 frames | graph edges | samples (tau 1/3/6) | holding valid / positive | holding intervals | state-change events |
|---|---:|---:|---|---:|---:|---:|
| 0 | 5,068 | 823,424 | 5,018 / 4,918 / 4,768 | 102,928 / 5,442 | 69 | 331 |
| 1 | 6,707 | 1,098,776 | 6,657 / 6,557 / 6,407 | 137,347 / 8,096 | 67 | 382 |
| 2 | 5,882 | 960,176 | 5,832 / 5,732 / 5,582 | 120,022 / 7,863 | 59 | 372 |

The holding evidence fields are populated. Across tasks 0/1/2 respectively,
the audit counted `finger_contact` evidence 6,936 / 10,265 / 9,683,
`closed_gripper` 51,604 / 70,231 / 68,586,
`relative_pose_stable` 100,804 / 135,232 / 117,916, and
`object_followed_eef` 5,334 / 7,320 / 6,633. These are evidence-field counts,
not mutually exclusive positive-frame counts.

Every task has complete action windows, zero future-action fields, and zero
null split records. The three horizon counts are present for every task. The
temporal state machine is active: task 0 exposes `free`, `contact_candidate`,
`holding`, and `release` tokens, and all tasks contain holding-state-change
events and holding intervals.

### Warnings and interpretation

All three reports are `pass_with_warnings`, with the same two warnings:

1. `graph_t.nodes.features.is_object_of_interest` is still present in the
   serialized model-input feature dictionaries. Its value was intended to be
   zeroed, but retaining the task-oriented field is an avoidable metadata
   leakage risk. Phase 3 must either remove the key from model input or make
   its exclusion an explicit, tested preprocessing rule.
2. `inside`, `open`, and `close` have no valid labels in the current scoped
   graphs. They must remain `valid=false`/unknown rather than being converted
   to negative labels. The current Phase 3 metrics should therefore be limited
   to the supported spatial, contact, on, and holding relations unless those
   handlers are implemented and the dataset is regenerated.

The supported spatial relations and `contact` have valid labels and positive
examples. `on` has valid labels in the audit, but task 0 did not show positive
`on` examples, so its positive support should be reported separately before
using it as a primary Phase 3 metric. `holding` has valid evidence and
positive examples in every task. The action-conditioned event sample contract
is therefore usable, but the model-input leakage cleanup is a required
pre-Phase-3 schema step.

### Gate decision

Phase 2D relation/event QA is complete, but Phase 3 is not opened yet. The
next action is a small schema repair that removes `is_object_of_interest` from
`graph_t` model-input features while preserving it, if needed, only in audit
metadata. After that repair, rerun a structural QA spot-check and start the
revised Phase 3 controls: correct executed action, no-action, shuffled-action,
and shuffled-edge comparisons. Phase 4 remains blocked until those controls
show genuine action-conditioned changed-relation prediction.

## 2026-08-07 - Phase 2D input-clean v1 and structural QA

### Objective

Close the model-input leakage warning from the Phase 2D relation/event audit
without changing the original split-fixed artifact. The derived artifact keeps
the 24-dimensional node vector for compatibility, but removes the
task-derived `is_object_of_interest` key from both `graph_t` and
`graph_target`; the reserved vector slot at index 4 is asserted to remain zero.

### Derived artifact

- Source: `phase2d_full_demo_v2_splitfixed_stream1`
- Derived output: `phase2d_full_demo_v2_inputclean_stream1`
- Version: `phase2d-full-demo.v2+split-fixed-stream1+input-clean-v1`
- Tasks: 0, 1, and 2; original source artifact preserved.
- Split manifest is copied from the split-fixed source into the derived root.

### QA results

All three task files passed the input-clean structural checks:

| task | records | samples | graph-node occurrences | remaining task-flag keys | nonzero reserved slots |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 150 | 14,704 | 235,264 | 0 | 0 |
| 1 | 150 | 19,621 | 313,936 | 0 | 0 |
| 2 | 150 | 17,146 | 274,336 | 0 | 0 |

The task-1 file was first found to be an incomplete 62-record intermediate
artifact; it was regenerated from the original split-fixed source and then
rechecked. This is recorded as a data-generation interruption, not a label
problem.

### Gate decision

The input schema repair and structural QA are complete. Phase 3 may now begin
with the revised controls: correct executed action, no-action, shuffled-action,
and shuffled-edge comparisons. `inside`, `open`, and `close` remain unknown
(`valid=false`) in the current scoped data and must not be treated as negative
labels. Phase 4 remains gated on evidence that changed-relation prediction is
genuinely action-conditioned.

## 2026-08-07 - Codebase and Colab notebook cleanup

### Objective

Separate the current research execution path from historical bundles, staging
copies, generated Python caches, and temporary Colab test cells.

### Changes

- Added a canonical execution map in `scripts/README.md` and
  `docs/codebase_organization.md`.
- Added `scripts/phase3_dataset_io.py` so official-demo JSONL flattening and
  split-balanced smoke selection are reusable code rather than ad-hoc Colab
  cells.
- Added unit tests in `tests/test_phase3_dataset_io.py` for gzipped JSONL
  flattening and three-way smoke split coverage.
- Added the canonical runbook
  `notebooks/graph_clad_phase0_to3.ipynb`; the local repository previously had
  no notebook file even though the working notebook lived in Drive.
- Moved old phase bundles, duplicate Phase 2R staging copies, temporary
  research assets, and generated `__pycache__` files under `archive/` without
  deleting them.
- Removed the temporary Colab cells and outputs named `FRESH_CELL_OK`,
  `LATEST_BLANK_OK`, and related smoke-entry markers. One final blank input
  cell remains because Colab automatically keeps an editable terminal cell.

### Interpretation

The canonical current path is now Phase 0 → Phase 1A → Phase 2A/2D QA →
Phase 3A → Phase 3B. Phase 2R remains diagnostic only, and Phase 4 remains
blocked until the revised Phase 3 controls pass.

## 2026-08-07 - Colab code recovery and Phase-oriented source layout

### Objective

Preserve every reusable implementation that still existed only in the working
Colab notebook, and make the local repository the source of truth for future
runtime resets and reruns.

### Recovery and reorganization

- Moved canonical implementations into `scripts/phase0`, `phase1`, `phase2a`,
  `phase2r`, `phase2d`, and `phase3`.
- Kept the former flat module names as compatibility aliases, so earlier tests
  and Colab commands remain usable while new work imports the Phase paths.
- Recovered the full official-demo pipeline as reusable modules: exact HDF5
  state replay, gripper-aware contact mapping, temporal holding state machine,
  fixed demo-level split lookup, event-centered multi-horizon generation,
  model-input leakage removal, relation audit, and Drive persistence.
- Added per-demo atomic shards and resume behavior to the Phase 2D generator.
  This is an improvement over the original monolithic Colab cell: a runtime
  interruption no longer requires rebuilding completed demonstrations.
- Recovered the narrow robosuite/MuJoCo compatibility patch as an explicit
  dry-run-first tool. It is runtime infrastructure, not a model change.

### Corrected historical issues

The original full-demo notebook cell was not valid as a standalone file: an
unfinished validation loop and unrelated diagnostics preceded the generator.
The initial generator also looked up split assignments with an integer demo ID
even though the manifest key was the string `demo_N`; this produced null split
fields and required a later streaming repair. The local generator now uses
`(task_id, demo_key)` from the start and refuses to continue when any assignment
is missing.

### Verification

All 53 Python source/test files passed syntax parsing. Thirty local checks
passed (15 `unittest` cases and 15 existing pytest-style functions executed
directly), including temporal holding transitions, task-metadata removal, the
150-demo split counts (113/19/18 in-task and 100/50 task-held-out), legacy split
repair, contact mapping, relation handlers, scale-up QA, and task-held-out
splits. Old direct script entry points were also checked with `--help`. The
Phase 0 torch model smoke and full LIBERO replay were not rerun locally because
the bundled local runtime lacks PyTorch/LIBERO and the HDF5 artifacts remain in
Colab/Drive.

### Decision

The local Phase directories are now the implementation source of truth.
Notebook cells should only install dependencies, mount Drive, call these
modules, and display results. Existing Drive release results are not changed by
this source recovery; the next research gate remains the Phase 3 controlled GNN
experiment.

## 2026-08-07 - Phase 3 A100 smoke run through mounted Drive

### Execution policy

The smoke run was executed in the connected Colab A100 runtime with Google
Drive mounted at `/content/drive`. The Phase 2D input-clean dataset was read
directly from Drive; no dataset download to the local PC was used.

### Runtime correction

Two runtime-only issues were found and corrected before accepting the result:

1. The dynamically loaded probe module was inserted into `sys.modules` before
   execution so its dataclass definitions resolve correctly.
2. The probe's action normalization assumed every flattened action window had
   the same length. Official demonstration windows can be ragged, so the
   normalizer now pads only for statistics and computes per-coordinate stats
   over observed values. The reusable fix is in
   `scripts/phase3/offline_probe.py` and was mirrored into the Colab runtime.

The final summary cell initially treated the result's model list as a mapping
and raised on `.keys()`. The training and result writes had already completed;
the result was verified with a separate read-only summary cell.

### Smoke configuration and result

- Model: `p2_gnn_empty_edge`
- Seed: `0`
- Device: `cuda` on an A100 runtime
- Epochs: `3`
- Samples: 100 train / 100 validation / 100 test
- Shape: 8 nodes, 56 edges, 28 node features, 5 edge features, 21 action
  features, 10 relations
- Best validation macro-F1: `0.3184664524`
- Correct-action test future-relation macro-F1: `0.3112459562`
- Correct-action changed-relation macro-F1: `0.4924914188`
- No-action future-relation macro-F1: `0.2696948104`
- Shuffled-action future-relation macro-F1: `0.3119019677`
- Shuffled-edge future-relation macro-F1: `0.2828205527`

### Persistent outputs

The following files were confirmed in Drive:

- `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3/phase3_smoke_dataset.json`
- `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3/phase3_smoke_config.json`
- `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3/phase3_smoke_result.json`

### Interpretation

The smoke path is operational and the action-control comparison can be
inspected. This is still a small smoke run, not the Phase 4 gate: the
task-held-out controlled experiment, repeated seeds, relation-wise reporting,
and changed-relation action-sensitivity checks remain before advancing.

## 2026-08-07 - Controlled task-family revalidation completed

### Protocol

The next controlled experiment was run on the Phase 2D input-clean demo-derived
dataset directly from mounted Google Drive. Three task-family folds were used:
each fold held one of `libero_spatial:0`, `libero_spatial:1`, or
`libero_spatial:2` out for test, with a disjoint task family for validation and
the remaining family for training. Each family contributed 600 deterministic,
episode-balanced samples, giving 600 train / 600 validation / 600 test samples
per fold.

Five models and three seeds were run per fold with parameter matching enabled,
for 45 completed runs total:

- P0 flat MLP;
- P1 node-only;
- P2 empty-edge GNN;
- P3 geometry-edge GNN;
- P4 soft-attention GNN.

The run used an A100 CUDA runtime, 40 epochs, patience 8, batch size 64,
train-only normalization, and the four evaluation controls: correct action,
no action, shuffled action, and shuffled edge assignment.

### Completion and durable files

All three folds completed successfully. Fold elapsed times were approximately
142.6 s, 177.7 s, and 208.7 s. The persistent Drive bundle is:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3`

It includes the full report, config, compact summary, latest checkpoint, the
patched `offline_probe.py`, the reusable `run_controlled_taskfamily.py`, and
`phase3_runtime_manifest.json` with file hashes and reset instructions.

The reusable local sources are [the controlled runner](../scripts/phase3/run_controlled_taskfamily.py),
[the input-clean control config](../configs/phase3_controlled_taskfamily_inputclean.json),
and [the runtime persistence guide](colab_runtime_persistence.md).

### Gate status

The controlled run is complete, but completion is not equivalent to a Phase 4
pass. The saved report must be summarized by model and relation, especially
the correct-versus-no-action, correct-versus-shuffled-action, and
correct-versus-shuffled-edge deltas. Holding-positive support and a robust
action-conditioned changed-relation signal remain explicit gates.

## 2026-08-07 - Controlled result analysis

The detailed analysis is persisted at
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3/phase3_controlled_taskfamily_analysis.json`.
The values below aggregate the 3 folds and 3 seeds for each model.

### Main metrics

| Model | Future macro-F1 | Changed-relation macro-F1 | Changed F1 std |
| --- | ---: | ---: | ---: |
| P0 flat MLP | 0.6610 | 0.4564 | 0.2374 |
| P1 node-only | 0.6562 | 0.5057 | 0.2176 |
| P2 empty-edge GNN | 0.6510 | 0.4969 | 0.2039 |
| P3 geometry GNN | 0.6525 | 0.4464 | 0.2238 |
| P4 soft-attention GNN | 0.6540 | **0.5392** | **0.1432** |

P0 remains strongest on overall future-relation classification, so the graph
does not provide a general accuracy improvement. P4 is strongest on the
primary changed-relation metric and is more stable than the other models, but
the fold-specific scores vary substantially. For example, P4 changed F1 is
0.463 on `test_task1` and 0.692 on `test_task2`. This means task-family
difficulty is a major factor and a single pooled average is insufficient.

### Control interpretation

For P4, correct-action changed F1 exceeds no-action in 4/9 runs and exceeds
shuffled-action in 7/9 runs. The mean deltas are only +0.0485 and +0.0113,
respectively. This is a weak action signal, not a decisive demonstration of
action-conditioned foresight.

The edge control is clearer: P4 correct-action changed F1 exceeds
shuffled-edge by +0.2108 on average and wins in 7/9 runs. P3 also shows a
positive edge-assignment effect (+0.1460, 7/9), while P2 is weaker (+0.0569,
5/9). This supports that some models use directed edge assignment, but it does
not by itself prove correct causal action use.

P3 geometry features do not improve the correct changed-relation score over
P2. The useful improvement in this run comes from the soft-attention design,
not from adding raw edge geometry alone.

### Relation coverage limitation

The current task-0/1/2 input-clean dataset contains zero positive support for
both `inside` and `holding`. Holding has valid negative-labelled frames but no
positive future relation, and `inside` has no metric support at all. Therefore
the result says nothing about grasp/holding or containment prediction.

### Decision

Phase 3 controlled execution is successful, but the Phase 4 gate remains
closed. P4 is the next candidate model, not a final conclusion. Before
adapter integration, the dataset must add relation-critical positive support
for holding and inside, and the action protocol must produce a larger and more
consistent correct-versus-shuffled-action advantage. The current analysis is a
model-selection and failure-diagnosis result, not evidence that latent
foresight has been solved.

## 2026-08-07 - Scope decision: include holding as a primary relation

The study will include `holding(robot0, object)` as a primary target relation.
Holding distinguishes grasp-and-lift behavior from ordinary contact or pushing,
and exposes the robot-object attachment state that is important for
action-conditioned manipulation foresight.

The current Phase 3 result cannot validate holding because the input-clean
task-0/1/2 demo subset contains no positive holding labels. The next dataset
revision must add holding-positive and hard-negative event windows, preserve
episode-disjoint splits, and rerun the same controlled P4/P0/P2 comparison.
`inside` remains deferred until a task subset with valid containment labels is
added.

## 2026-08-07 - Holding event-window dataset augmentation completed

The official-demo, input-clean Phase 2D artifacts were read from the persistent
Drive source:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_full_demo_v2_inputclean_stream1`

The augmentation was executed in the open Colab notebook on an A100 runtime.
It preserved the existing demo-level split and used only state-replayed graph
labels and holding transition events. `holding(robot0, object)` remained the
primary relation; `inside` remained deferred and unknown labels were never
converted into negatives.

The persistent output is:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_holding_event_v1_inputclean_stream1_direct`

The dataset contains 12,404 selected event windows across task 0/1/2:

- `positive_event`: 5,400
- `hard_negative` (`contact_without_holding`): 4,304
- `background`: 2,700

Every task and every preserved train/validation/test split contains positive
and hard-negative windows. Positive events are accepted when a holding onset,
holding release, or active holding state occurs inside the sampled window;
therefore both endpoint labels may be false for a valid transition window.
Hard negatives require contact at one endpoint and known-false holding at both
endpoints. Final index QA passed with zero errors.

Persistent QA and reproducibility files:

- `phase2d_holding_event_dataset_manifest.json`
- `phase2d_holding_event_dataset_qa_v2.json`
- `phase2d_holding_event_window_index_v1.jsonl.gz`
- `generation_config.json`
- `artifacts/phase2d/code/event_windows.py`
- `artifacts/phase2d/code/build_holding_event_dataset.py`

## 2026-08-07 - Target-aligned holding sampling revision

The first holding event-window experiment exposed a target-selection mismatch.
`positive_event` was defined by a holding transition occurring anywhere inside
the window, while the controlled probe scores the holding label at
`graph_target`. A valid onset/release window can therefore have false holding
labels at both endpoints. The resulting 45-run experiment had near-zero
holding F1 and did not strengthen action conditioning:

- P4 changed-relation macro-F1: `0.3086`
- P4 holding future F1: `0.0202`
- P4 holding changed F1: `0.0000`
- P4 correct-minus-no-action changed delta: `+0.0267`
- P4 correct-minus-shuffled-action changed delta: `+0.0082`

This is treated as a sampling/protocol failure diagnosis, not evidence that
holding prediction is solved.

The next dataset revision will use target-aligned strata:

- `future_holding_positive`: `graph_target` holding is valid and true;
- `holding_changed`: current and future holding labels are valid and differ;
- `hard_negative`: contact is true while current and future holding are both
  valid and false;
- `background`: none of the above;
- unknown holding labels are excluded.

The sampler must preserve demo-level fixed splits and horizon balance, and must
run a preflight QA proving that every task-family train/validation/test split
has nonzero `future_holding_positive` and `holding_changed` support before the
next controlled experiment. Event tags remain audit metadata and are not model
input features.

## 2026-08-07 - Target-aligned holding controlled experiment completed

The target-aligned dataset was generated from the official-demo, input-clean
source and passed generation QA:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_holding_target_v2_inputclean_stream1/phase2d_holding_target_dataset_manifest.json`

It contains 13,978 indexed records. The runner preflight at the fixed
600-sample-per-family cap passed for all task families. The selected category
counts were:

- task 0: background 300, hard negative 255, future holding positive 45,
  holding changed 18;
- task 1: background 300, hard negative 298, future holding positive 2,
  holding changed 1;
- task 2: background 300, hard negative 288, future holding positive 11,
  holding changed 8.

The target-aligned controlled experiment completed 45 runs (five models,
three seeds, three task-family-held-out folds) in a separate output root:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holding_target_v2`

The report relation contract contains `holding` and excludes `inside`.
Changed-relation macro-F1 ranking was:

- P1 node-no-message: `0.3076 +/- 0.1397`;
- P3 geometry GNN: `0.2891 +/- 0.1627`;
- P4 soft-attention GNN: `0.2823 +/- 0.0979`;
- P0 flat MLP: `0.2720 +/- 0.0658`;
- P2 empty-edge GNN: `0.2216 +/- 0.1295`.

Holding-specific results remain weak despite target alignment. P0 had the
highest future holding F1 at `0.0863 +/- 0.1606` and holding-changed F1 at
`0.1262 +/- 0.2357`; P3 was near zero and P1/P2/P4 were zero on both holding
metrics. The holding-changed test support is highly uneven across held-out
task families (18, 1, and 8 samples after the cap), so these metrics are
diagnostic rather than a stable model comparison.

Action conditioning remains weak. P4 correct-minus-no-action changed F1 was
`+0.0193`, while correct-minus-shuffled-action was `+0.0051`. The edge control
for P4 was negative (`-0.0252`). Therefore target alignment repaired the
label-selection mismatch but did not establish action-conditioned holding
foresight or preserve P4 as the best overall model.

Persistent QA and analysis files:

- `phase2d_holding_target_runner_preflight.json`
- `phase3_holding_target_config.json`
- `phase3_controlled_taskfamily_report.json`
- `phase3_holding_target_analysis.json`
- staged `code/run_controlled_taskfamily.py` and `code/offline_probe.py`

Decision: do not interpret the zero P1/P2/P4 holding scores as absence of
holding labels; the report has valid future holding support. The next analysis
should inspect per-task/fold holding positives and the action-window signal,
then decide whether to increase task-1/2 holding-changed support or revise the
probe loss/target sampling before adapter integration.

## 2026-08-07 - Category-aware balanced-cap controlled experiment completed

The fixed 600-sample family cap was revised without generating a new official
demo dataset. Selection now uses unique samples, a category quota of 120 for
each target category, and episode round-robin filling. The preflight passed for
all three held-out task families:

- family 0: future holding positive 135, holding changed 120,
  hard negative 125, background 290;
- family 1: future holding positive 130, holding changed 120,
  hard negative 140, background 299;
- family 2: future holding positive 132, holding changed 120,
  hard negative 132, background 292.

The balanced-v3 controlled experiment completed 45 runs and was saved under:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holding_target_balanced_v3`

The corrected post-hoc analysis was saved as
`phase3_holding_target_balanced_analysis.json`. Changed-relation macro-F1
ranking changed substantially from the episode-only cap:

- P0 flat MLP: `0.4081 +/- 0.0638`;
- P3 geometry GNN: `0.3924 +/- 0.1097`;
- P4 soft-attention GNN: `0.3859 +/- 0.1026`;
- P2 empty-edge GNN: `0.3732 +/- 0.0548`;
- P1 node-no-message: `0.3724 +/- 0.0609`.

Holding support is now usable for model comparison. Future holding F1 and
holding-changed F1 were:

- P0: `0.6210 +/- 0.1102` and `0.7701 +/- 0.1319`;
- P4: `0.4398 +/- 0.1732` and `0.2360 +/- 0.2984`;
- P3: `0.3917 +/- 0.1433` and `0.1546 +/- 0.3070`;
- P2: `0.3804 +/- 0.0844` and `0.0168 +/- 0.0253`;
- P1: `0.2885 +/- 0.1160` and `0.0202 +/- 0.0606`.

Action controls were positive for every model. The correct-minus-no-action and
correct-minus-shuffled-action changed-relation deltas were respectively:

- P0: `+0.1186`, `+0.0308`;
- P1: `+0.0793`, `+0.0108`;
- P2: `+0.0520`, `+0.0115`;
- P3: `+0.0184`, `+0.0043`;
- P4: `+0.0666`, `+0.0114`.

Interpretation: episode-only `_balanced_cap` was a major category-support
confound. Category-aware sampling substantially improves holding evaluation
support and makes holding prediction measurable, but it also changes the
overall ranking: P4 is no longer the best model and P0 is strongest on both
changed-relation macro-F1 and holding metrics. The positive shuffled-action
gap suggests that the action input carries usable signal, but this result does
not yet show that graph message passing or soft attention is necessary for
using it. The category-aware sample policy and model architecture effects must
therefore be reported separately.

The relation contract remains unchanged: holding is primary, inside is
deferred, and unknown labels are excluded. The next step is per-family and
per-fold variance inspection of the balanced report before adapter integration;
no additional data collection is required at this point.

## 2026-08-07 - Colab code migration and balanced-v3 interpretation correction

Colab notebook cells 295-304 were compared with the local source tree. The
reusable target-aligned dataset builder, sampler, controlled runner, and report
analysis were migrated into versioned modules. Duplicate QA cells and the
one-off report-key inspection cell were not promoted. The exact mapping is in
`docs/colab_code_migration_20260807.md`.

New source-of-truth files are:

- `scripts/phase2d/build_holding_target_dataset.py`;
- `scripts/phase2d/audit_holding_target_dataset.py`;
- `scripts/phase3/sampling.py`;
- generalized `scripts/phase3/run_controlled_taskfamily.py`;
- generalized `scripts/phase3/offline_probe.py` with configurable target relations;
- `scripts/phase3/analyze_holding_results.py`.

The balanced-v3 sampling description above requires a correction. Its category
counts are multi-label counts and therefore do not define four mutually
exclusive balanced classes. More importantly, the quota-stage implementation
restarts episode traversal after each accepted sample, so it can consume early
episodes greedily. The existing artifact is now identified as
`category_aware_v1` for exact reproduction; it is not a true episode
round-robin. The corrected unexecuted sampler is
`category_aware_episode_round_robin_v2` and has a separate v4 config. Existing
v3 metrics remain valid for the exact selected sample set, but their sampling
claim is narrowed to category-minimum-support challenge-set evaluation.

A professor-perspective review was added at
`docs/research_risk_review_20260807.md`. Its main conclusions are:

- target-aligned test selection is a challenge-set evaluation, not natural
  prevalence evaluation;
- the current one-task train / one-task validation / one-task test folds are
  better described as one-to-one task transfer than standard leave-one-task-out;
- fold and seed variation must be separated, with episode/event-level
  uncertainty rather than treating nine runs as independent;
- P0's advantage needs node-order, target-only, and non-target masking controls;
- test-time action perturbations establish action use, not causal
  action-conditioning;
- current mean differences are too small relative to task/fold variance to
  conclude that GNNs are generally unsuitable.

The next graph hypothesis is target-centric rather than complete spatial
message passing. The design is recorded in
`docs/phase3_holder_object_action_graph_design.md`: explicit robot-holder to
object edges, action-conditioned temporal edge updates, restricted context
edges, and paired controls against P0, target-object-only MLP, and the existing
geometry GNN. Phase 4 adapter integration remains gated until this revised
protocol is evaluated on separate natural and holding-challenge test sets.

## 2026-08-11 - Phase 3B-R1 research plan frozen

The next Phase 3 model study will use a staged 2 x 2 design rather than choosing
target-centric topology or action-conditioned updates in isolation. The four
graph cells are complete/late-action, complete/action-conditioned,
holder-object-sparse/late-action, and holder-object-sparse/action-conditioned.
This separates the topology effect, action-routing effect, and their
interaction; the combined sparse/action-conditioned cell is the expected
candidate, not a presupposed winner.

Before model training, the protocol will freeze the corrected
`category_aware_episode_round_robin_v2` sampler, outer held-out-task folds,
fixed sample IDs, a natural test, and a target-conditioned holding challenge
test. P0 shortcut checks and a pair-only MLP are mandatory. The existing v4
sampler config retains the old fold definition and is therefore a sampler
isolation artifact, not the final model-comparison protocol.

The primary metrics will distinguish actual holding change-event F1 from the
historical future-value F1 measured only on true-changed rows. Onset/release
F1, holding PR-AUC, and hard-negative false-positive rate will also be
reported. Current samples do not contain a full past graph sequence, so the
first architecture uses current holder-object evidence and the target-interval
action window only; history and restricted support/contact context remain
gated follow-ups.

The full rationale, execution order, controls, success criteria, and Drive
artifact policy are frozen in
`docs/01-plan/features/phase3_target_centric_action_conditioned_gnn.plan.md`.

## 2026-08-11 - Phase 3B-R1 E0 and holder-object smoke result

The evaluation freeze passed in Colab with zero warnings. The persisted
manifest is
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/phase3B_R1_eval_manifest.json`.
The task-0 fold uses fixed sample IDs and contains 1,200 train rows, 474
validation rows, 486 natural-test rows, and 167 holding-challenge rows. The
input-availability QA confirms current relative position, distance,
contact/validity, gripper/closure, action window, and validity masks. Relative
velocity, object-following stability, and past graph history are unavailable in
this release and were excluded.

The corrected 1-fold/1-seed smoke result is persisted at
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/smoke_test_task0_seed0.json`.
It compares P0 flat MLP, B1 current-information robot-object pair MLP, and G1
one-layer sparse holder-object GNN on the same selected sample IDs. G1 uses
sparse holder-object routing and the existing global action representation; it
is not yet the edge-level action-conditioned model.

| model | natural changed F1 | natural holding changed F1 | challenge changed F1 | challenge holding changed F1 |
|---|---:|---:|---:|---:|
| P0 flat MLP | 0.546 | 0.705 | 0.660 | 0.779 |
| B1 robot-object pair MLP | 0.529 | 0.000 | 0.543 | 0.000 |
| G1 sparse holder-object GNN | 0.628 | 0.833 | 0.677 | 0.909 |

The smoke result is directionally positive for sparse holder-object message
routing: G1 beats P0 on both overall changed-relation F1 and holding
change-event F1 in this fold. Its edge-shuffle drop is non-zero (0.176 natural,
0.271 challenge), which supports that relation routing is being used. However,
the action-shuffle gap is weak (0.0004 natural, 0.0158 challenge for overall
changed F1), so this result does not establish action-conditioned reasoning.
G1 is therefore a candidate for expansion, not a final winner. The next model
is G3: keep the sparse holder-object topology but inject the action embedding
into the edge message and gate, then repeat the same fixed sample-ID smoke
comparison before any 3-fold/3-seed run.

## 2026-08-11 - G3 action-conditioned edge smoke result

The G3 extension completed successfully and passed artifact QA. Its separate
Drive result is
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/smoke_test_task0_seed0_g3.json`.
The split counts and fixed sample IDs match the G1 smoke exactly.

G3 improved overall changed-relation F1 over G1 from 0.628 to 0.656 on natural
test and from 0.677 to 0.698 on challenge test. It also produced a clear
edge-shuffle drop (0.222 natural, 0.306 challenge). However, the primary
holding change-event F1 decreased relative to G1, from 0.833 to 0.732 on
natural test and from 0.909 to 0.811 on challenge test. More importantly, the
action-shuffle gap was not positive (-0.008 natural, 0.0001 challenge for
overall changed F1), so the smoke does not show that the edge-conditioned
action path is using the action signal.

This is a useful negative result: sparse topology remains supported, but the
current action-conditioned gate is not ready for a 3-fold/3-seed expansion.
The next task is an action-signal diagnostic (window variance, temporal
alignment, and control implementation) followed by a minimal action-routing
fix or a documented no-action control. G1 remains the current architecture
candidate for holding change-event performance.

## 2026-08-11 - Action-signal diagnostic completed

The action diagnostic for `test_task0` completed and was persisted at
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/action_signal_diagnostic_task0.json`.
The action window is non-degenerate: six steps, seven dimensions, values in
`[-1, 1]`, with value standard deviation `0.498` for natural samples and
`0.435` for target-aligned samples. The zero fractions are `0.168` and `0.250`,
respectively, and the checked sample alignment is `start_step=0`,
`target_step=6`, `tau=6`.

Therefore the weak G1/G3 action-shuffle gaps are not explained by an all-zero
or constant action input. The current evidence points instead to action
routing/control sensitivity: batch-rolled action windows may not be a strong
counterfactual for this data, or the action signal may be redundant with
current gripper/node features. No architecture expansion was started after
this diagnostic.

## 2026-08-11 - Remaining topology/action ablation matrix

The next objective is to separate two factors that are still confounded:
graph topology (complete versus sparse holder-object) and action routing
(late/global concatenation versus edge-conditioned messages). The old P3
complete-geometry result cannot fill the new matrix because it used a
different sampler and split. Complete-graph cells must therefore be rerun on
the frozen Phase 3B-R1 manifest and exact sample IDs.

| ID | Model | Status | Question answered |
|---|---|---|---|
| P0 | Flat MLP | completed | Basic non-graph baseline |
| C-L | Complete graph + late/global action | required | Is complete or sparse topology better under the same action routing? |
| C-E | Complete graph + edge-conditioned action | required | Does changing only action routing improve a complete graph? |
| S-L | Sparse holder-object + late/global action (current G1) | completed | Does sparse holder-object topology help? |
| S-E | Sparse holder-object + edge-conditioned action (current G3) | completed | Does sparse topology interact positively with edge-level action routing? |
| S-0 | Sparse holder-object trained without action | required | Is action input itself necessary? |

The factorial comparisons are:

- `C-L vs S-L`: topology effect under late/global action;
- `C-E vs S-E`: topology effect under edge-conditioned action;
- `C-L vs C-E`: action-routing effect under complete topology;
- `S-L vs S-E`: action-routing effect under sparse topology.

`S-0` is an additional action-necessity control, not one of the four factorial
cells. It must be trained from scratch without an action encoder. Test-time
zeroing of a model trained with action is insufficient because an all-zero
vector can be out of distribution.

The immediate fixed-manifest smoke order is:

1. rerun `C-L` on `test_task0`, seed 0;
2. implement and run `C-E` on the same sample IDs;
3. train and run `S-0` on the same sample IDs;
4. compare all cells using natural and challenge holding change-event F1;
5. add temporal-shift, reverse-window, and gripper-command action controls;
6. expand only the models that pass these gates to 3 folds x 3 seeds.

`S-0` is therefore performed after the C-L/C-E smoke cells for an orderly
interpretation, but before any full multi-fold/multi-seed experiment. It
remains required even if C-L or C-E is weak, because the present G1/G3 results
still do not establish that the action input itself is necessary.

The current decision rules are:

- sparse topology is supported only if `S-L > C-L` and/or `S-E > C-E` on the
  primary holding change-event metric;
- edge-conditioned action is supported only if `C-E > C-L` and/or
  `S-E > S-L`, together with degradation under meaningful action controls;
- action input is necessary only if `S-L > S-0` under matched training and
  evaluation;
- the current G1/S-L remains the holding candidate, while G3/S-E remains
  provisional because its action-shuffle gap is near zero and its holding
  change-event F1 is below G1.

## 2026-08-11 - Holder-object feature/action v2 code review and correction

A code-level review found that the first sparse smoke did not fully match its
documented feature contract. The old sparse edge input contained relative
position, distance, and geometry validity only; current contact was not passed
to the model. The old B1 pair MLP also omitted pair geometry entirely, so its
poor result cannot by itself establish that pair-only reasoning is
insufficient. In addition, the old G1-to-G3 change mixed action routing with a
new gate, residual update, and LayerNorm, weakening a causal interpretation of
that comparison.

A versioned `holder_object_v2` path has now been added while preserving the
legacy default. The v2 node contract is a 17-dimensional compact current state
(type, validity, gripper qpos/aperture, and joint velocity) that excludes
absolute position, joint position, and oracle object-of-interest flags. The v2
edge contract contains relative position, distance, geometry validity, current
raw contact value/validity, and explicit robot-to-object/object-to-robot role
flags. Current holding is deliberately excluded because it is a temporal weak
label derived from contact, closure, and motion history and could create a
label-copy shortcut.
Unlike the legacy sparse preprocessing, v2 also removes isolated fixture/site
nodes instead of filtering only their edges; this prevents unrelated nodes
from affecting normalization and the v2 flat baseline.

The action path now has a structured 6-by-7 encoder. It normalizes each action
channel using train samples only, separates arm and gripper commands, adds
temporal position embeddings and masked attention, and exposes first, last,
mean, sum, delta, gripper range, and coverage summaries. A pair-conditioned
FiLM message uses `pair_h`, `action_h`, and `pair_h * action_h` so action can
change message content rather than only scaling it with one scalar gate.
The v2 current-relation auxiliary head is also separated from the future
action path: it reads only the initial current pair state, while the future
head reads the action-conditioned update. This avoids training the shared
representation to suppress action merely because current labels should not
change with future commands.

The new controlled sparse comparison is:

| ID | Model | Isolated question |
|---|---|---|
| B1-v2 | feature-parity pair MLP | Is a graph needed beyond one pair? |
| S-LF-v2 | matched sparse block + flat late action | v2 sparse reference |
| S-LS-v2 | same block + structured late action | Does action encoding help? |
| S-EF-v2 | same structured encoder + action FiLM message | Does edge conditioning help? |

These comparisons must be run on the frozen E0 sample IDs. Prior G1/G3
results remain valid descriptions of the legacy implementations, but the old
B1-vs-G1 and G1-vs-G3 differences are not treated as clean feature-parity or
single-factor causal estimates. The implementation and execution contract are
documented in `docs/phase3_holder_object_feature_action_v2.md`.

The review also corrected control terminology. The historical `no_action`
control set an already-normalized tensor to zero and therefore represented the
train-mean action, not a physical zero command. The legacy control is retained
for report compatibility, while v2 additionally evaluates a raw physical-zero
command, reversed action windows, gripper-only shuffle, and arm-only shuffle.
None of these test-time controls replaces the required S-0 model trained from
scratch without an action encoder.

## 2026-08-11 - Holding metric, checkpoint, and parameter-count correction

The v2 evaluation path now separates the historical `changed_relation`
measure from actual holding event prediction. The saved holding block reports
future-state F1/PR-AUC, actual change-event F1/PR-AUC, onset F1, release F1,
future holding-value performance on the true-changed subset, and hard-negative
false-positive rate. A predicted change is derived by comparing the observed
current holding state with the thresholded predicted future holding state.
Hard negatives are valid robot-object pairs with contact at the current or
future endpoint and known-false holding at both endpoints.

The holding threshold is selected only from correct-action validation output
on a fixed 0.05--0.95 grid. Each checkpoint stores its validation-fitted
threshold, and the selected threshold is reused without recalibration for the
natural test, holding challenge test, and all action/edge controls. Checkpoint
selection now uses validation actual holding change-event F1 when change
positives exist, falling back to validation future holding F1 and then global
future-relation macro-F1 only when required support is absent.

Parameter accounting was also corrected. P0 directly consumes flattened raw
node/action tensors, so its previously instantiated but unused node and action
encoders were removed. Parameter matching and report counts now include only
trainable parameters, and matched runs save the selected width, actual count,
and absolute difference from the declared target budget. Smoke runs remain
allowed to use an unmatched common width, but final multi-fold/multi-seed
comparisons must enable parameter matching.

## 2026-08-11 - Holder-object feature/action v2 smoke completed

The corrected `holder_object_v2` task-0/seed-0 smoke completed on an A100 after
all 16 feature, leakage, model-shape, metric, threshold, checkpoint, and
parameter-accounting regression tests passed. The exact code was persisted at
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/code_snapshot_v2`.
The full result and compact analysis are `smoke_test_task0_seed0_feature_v2.json`
and `smoke_test_task0_seed0_feature_v2_analysis.json` in the same Drive artifact
root.

G1 sparse holder-object GNN had the best actual holding change-event F1:
0.4257 on natural test and 0.8000 on challenge test. The feature-parity B1-v2
pair MLP reached 0.4022 and 0.7872, so G1's margin was only +0.0236 and +0.0128.
B1-v2 also had the best challenge event AP (0.7153) and lower hard-negative FPR
(0.0381/0.0000 versus G1's 0.1048/0.0984). Sparse message passing is therefore
directionally supported for thresholded event F1, but not decisively established.

The structured late-action and FiLM action-edge models did not beat G1 on the
primary metric. Their action-shuffle and channel-shuffle effects were small or
inconsistent, while edge-shuffle drops were generally clearer. The smoke does
not show reliable action use. Because this is an unmatched one-fold/one-seed
screen, no 3-fold/3-seed expansion is authorized. S-0, trained from scratch
without an action encoder, is now the highest-value next diagnostic; C-L/C-E
remain required afterward for the complete-versus-sparse factorial comparison.
Detailed values and claim boundaries are in
`docs/phase3_holder_action_v2_smoke_result.md`.

## 2026-08-12 - S-0 and complete-topology follow-up completed

The fixed task-0/seed-0 follow-up completed after 22 regression tests passed.
C-L and C-E used identical robot/object nodes, sample IDs, prediction edges,
normalization, and parameter counts as S-LS and S-EF, respectively.
Object-object edges were message-only context, so complete models did not
receive additional supervised targets.

Sparse topology beat complete topology in both routing conditions. S-LS minus
C-L actual holding event F1 was +0.0426 natural and +0.2127 challenge. S-EF
minus C-E was +0.0684 and +0.3014. C-E improved over C-L by only +0.0047 and
+0.0162. Complete-model edge shuffling improved performance, indicating that
the added object-object message context was harmful rather than informative.
C-L/C-E are not candidates for expansion.

Two exact G1 action-free controls were also trained from scratch. The
same-width S-0-G1 reached 0.2835/0.6852 event F1 versus G1's 0.4257/0.8000.
The parameter-matched S-0-G1 used 44,784 parameters versus G1's 44,946 and
reached 0.3204/0.6667. Thus action-pathway removal reduced performance in this
screen under both capacity controls.

This is not yet evidence of sample-specific action use. G1's zero-action drop
was large, but correct-versus-shuffled action, reversed-window, arm-only, and
gripper-only effects remained small or inconsistent. The current interpretation
is that action-pathway presence helps optimization or supplies a coarse
distribution cue, while causal action conditioning remains unproven. The next
gate is a paired three-seed G1/S-0-G1 screen with learned-constant-action and
train-time shuffled-action controls. Detailed results are in
`docs/phase3_topology_action_followup_result.md`; the Drive decision artifact is
`phase3_topology_action_decision_task0_seed0_v3.json`.

## 2026-08-12 - Task-0 three-seed action-semantics gate completed

The paired action-mechanism gate completed 12 runs on the frozen task-0
manifest: G1-correct, parameter-matched S-0-G1, exactly parameter-matched
G1-constant, and G1 trained with batch-shuffled actions, each over seeds
0/1/2. G1-correct mean holding event F1 was 0.3965 natural and 0.7162
challenge. It beat train-time shuffled G1 in all three seeds on both views,
with paired mean gains of +0.0758 and +0.1998. It beat the constant-action
capacity control by +0.0513/+0.0901 on average, but beat S-0-G1 in only two of
three seeds on each view. Thus aligned action training matters, while action
pathway superiority over an action-free model remains variable.

The historical test-time action shuffle was audited before accepting the
result. Its within-batch one-row roll selected a same-episode donor for 98.35%
of natural rows and 95.81% of challenge rows. Mean raw action distance was only
0.6835/0.9284, compared with 4.0506/2.6823 for a corrected global shuffle.
An episode-disjoint, marginal-preserving global permutation was implemented
and verified with 25 passing tests.

G1 was then rerun for all three seeds with checkpoint persistence. Under the
corrected global shuffle, holding event PR-AUC dropped in all three seeds on
both natural and challenge views, by 0.0718 and 0.0831 on average. Event F1
dropped by 0.0729 on natural (two of three seeds) and 0.1206 on challenge (all
three seeds). Edge shuffle also reduced event F1 in every seed on both views.
This provisionally supports sample-specific action use on held-out task 0.
The claim does not yet extend to tasks 1/2; natural release F1 and hard-negative
FPR are not consistently action-sensitive.

Drive artifacts are `phase3_action_semantics_gate_task0_3seed_v1.json`,
`phase3_global_action_shuffle_control_task0_3seed_v1.json`,
`phase3_action_semantics_gate_task0_3seed_v2_analysis.json`,
`checkpoints_global_action_shuffle_v1`, and `code_snapshot_action_gate_v1`
under the `phase3_holder_action_v1` root. Detailed interpretation is in
`docs/phase3_action_semantics_gate_result.md`. The next gate is a reduced,
parameter-matched 3-fold x 3-seed comparison of B1-v2, G1-correct, S-0-G1,
and G1-train-shuffled with the corrected global action and edge controls.

## 2026-08-12 - Reduced cross-fold gate completed

The reduced cross-fold gate completed all 36 runs on the frozen Phase 3B-R1
manifest: three held-out task folds, three seeds, and four conditions
(B1-v2, G1-correct, S-0-G1, and G1-train-shuffled). Natural and holding
challenge views were separated, validation thresholds were frozen, and 36
checkpoints were written to Drive. The result is
`phase3_reduced_crossfold_gate_v1.json` and the detailed interpretation is in
`docs/phase3_reduced_crossfold_gate_result.md`.

The main result is split-dependent. B1-v2 had the best challenge event F1
(0.7670) and the lowest hard-negative FPR on both views. S-0-G1 had the best
natural event F1 (0.3604) and challenge PR-AUC (0.5159). G1 reached 0.3400
natural and 0.7465 challenge event F1, so it did not consistently beat the
target-pair MLP. Paired G1-minus-B1 event F1 was +0.0115 natural in only 2/9
pairs and -0.0206 challenge in only 2/9 pairs.

Action alignment remains useful mainly on the challenge view. G1 beat
train-shuffled G1 by +0.2719 challenge event F1 in all 9 paired runs, while
the natural difference was -0.0070 with 4/9 positive pairs. Correct global
action shuffle reduced G1 PR-AUC in all 9 natural runs and 7/9 challenge
runs. This supports a challenge-oriented action signal, but not a universal
action-conditioned improvement.

The capacity comparison was near-matched, not exact: B1-v2 used 45,668
parameters (+722 versus G1's 44,946) and S-0-G1 used 44,784 (-162). This is
small but must be reported as a limitation. Sparse topology is retained;
Phase 4 remains gated, and no broad claim that GNN is superior to B1-v2 is
made.

## 2026-08-12 - Corrected Phase 3 protocol v2 implemented

A read-only audit confirmed that the reduced cross-fold runner still used an
action-contaminated G1 current auxiliary head, `current_loss_weight=0.25`,
event-enriched validation, holding-event F1 checkpoint selection, and a
validation threshold selected from the enriched rows. The legacy event metric
also used ground-truth current holding without an end-to-end counterpart. The
manifest sampler itself satisfied the observed quotas, but its QA loop checked
the aggregate training category counts repeatedly rather than the task-local
counts, and overlapping natural/challenge sample IDs were not payload-hashed.

The corrected implementation is versioned separately and keeps legacy model
and runner defaults unchanged. It adds a common action-free current head,
natural-validation PR-AUC checkpoint selection, frozen natural-validation
future/current thresholds, explicit conditional/oracle-current and end-to-end
events, onset/release/hard-negative and calibration metrics, per-pair gzip
prediction artifacts, task-local quota and overlap-payload hash QA, matched
episode-disjoint train-time action donors, and hierarchical prediction
bootstrap analysis. A deterministic 90-item weak-label audit builder was also
added; its pass rate remains pending manual review.

All modified and new Python files passed syntax compilation. Nine local
pure-Python regression checks passed. The local bundled runtime does not have
PyTorch or pytest, so tensor/model regression tests and the task-1/seed-0
four-model smoke are reserved for the verified A100 Colab runtime. The new
Drive root is `phase3_holder_action_v1/corrected_protocol_v2`; no legacy
36-run result or checkpoint is overwritten. Detailed contracts and claim
boundaries are in `docs/phase3_corrected_protocol_v2.md`.

## 2026-08-12 - Corrected smoke and three-fold seed-0 gate completed

Colab regression tests passed on the A100 runtime after Drive mount and code,
manifest, and output-path verification. A new natural-validation manifest was
built with passing task-local quota, leakage, stress-subset, and overlapping
payload-hash QA. The task-1/seed-0 smoke completed four models first. Only the
missing task 0 and task 2 seed-0 runs were then executed, producing 12/12
corrected runs without repeating task 1.

G1 beat B1 natural conditional/oracle-current holding-event PR-AUC on tasks 1
and 2 but lost on task 0. Its task-macro gain was +0.0626, with hierarchical
bootstrap interval [-0.0892, +0.1905]. G1 event F1 was 0.3272 versus B1's
0.4083. G1 did provide a robust diagnostic improvement over B1 in release F1
(+0.1626, interval [+0.0701, +0.2967]) and hard-negative FPR (-0.3326,
interval [-0.4201, -0.2429]). End-to-end event PR-AUC was only slightly higher
on the task macro and remained task-dependent.

The mandatory action-alignment gate failed. G1 minus train-shuffled G1
conditional PR-AUC was -0.0567 with interval [-0.1943, +0.0572]; the sign was
not consistent by task, and train-shuffled G1 had the best task-macro
conditional PR-AUC and event F1. These results do not support expanding the
current late/global-action G1 to three seeds or claiming a causal
action-conditioned graph-transition advantage.

The recorded decision is
`stop_gnn_three_seed_expansion_and_pivot_pair_local_temporal_encoder`. Further
GNN depth work is paused. The next gate is the H0--H3 pair-local temporal
history/action factorial using only features computed at or before t and
limited DeepSets or pair-set-attention context. Detailed results are in
`docs/phase3_corrected_threefold_seed0_result.md` and the next plan is
`docs/01-plan/features/phase3_pair_local_temporal_encoder.plan.md`.

A deterministic weak-label audit package was also created with 90/90 requested
items and no shortages: ten onset, release, and hard-negative examples for
each task 0/1/2. Its status is `ready_for_manual_review`; pass rate and error
counts remain unknown until the review CSV is completed. All corrected
artifacts live below
`phase3_holder_action_v1/corrected_protocol_v2`; the legacy 36-run artifacts
remain untouched.

## 2026-08-12 - Trajectory-enriched weak-label audit viewer ready

The initial audit evidence contained only current/future graphs plus the action
window, which was not sufficient to inspect the three-frame stability and
object-following claims independently. The audit builder now reconstructs
every graph frame from t through t+6 for each selected robot-object event.
Only requested evidence frames are retained; the source dataset is unchanged.

A separately versioned Drive audit was rebuilt with 90/90 items. Each of the
nine task/event cells contains ten items, and every item contains seven graph
frames. Overlap deduplication produced 592 unique requested frames; all 592
were recovered with zero missing frames and zero conflicting graph payloads.
Syntax, balance, trajectory, review-row, and command-line viewer checks passed
on Colab.

An interactive reviewer now shows distance, relative xyz motion,
object-following residual, contact/holding state, and arm/gripper action. It
stores `pass`, `label_error`, or `ambiguous` decisions atomically and updates a
summary manifest. It intentionally performs no automatic verdict assignment,
so the current review state remains 0/90 and no pass rate is claimed.

The new root is
`corrected_protocol_v2/weak_label_audit_v2_trajectory`, with code snapshot
`corrected_protocol_v2/code_snapshot_weak_label_audit_v2`. The 90-item screen
is a minimum QA gate; cells with errors or substantial ambiguity expand to at
least 30 items, and a publication-quality audit may require 270 total.

## 2026-08-12 - Pair-local temporal H0--H3 smoke completed

The next architecture gate was implemented and executed on the persistent
Colab Drive after reconnecting the mounted runtime. The four-way factorial was
run on `test_task1`, seed 0 with the corrected protocol: action-free current
head, natural-validation checkpoint selection by conditional event PR-AUC,
natural-validation frozen threshold, calibration metrics, per-sample
predictions, causal-history QA, and near-matched trainable parameter counts.
History features were reconstructed only from frames at or before the current
time, with no future graph or holding-label input. Pair tokens were processed
independently for each robot-object pair; unrestricted object-object message
passing was not introduced.

The Drive result is
`corrected_protocol_v2/pair_local_temporal_smoke_task1_seed0_v1` and the result
SHA256 is
`ae986247bc1d536269e94964d32a46e0c3167c1bd40b3015b623f2ced6148c502`.
Natural conditional/oracle-current event PR-AUC was H0 0.3810, H1 0.4960,
H2 0.5869, and H3 0.5731. H1-H0 was +0.1149; H2-H0 was +0.2058; H3-H1 was
+0.0771; and H3-H2 was -0.0138. H2 had the strongest natural release F1
(0.2143) and hard-negative FPR (0.0900). H1 improved onset and calibration but
did not detect a release. H3 had the best natural end-to-end event PR-AUC
(0.4227), but not the best conditional PR-AUC or release F1.

The defensible conclusion is limited: in this one-task/one-seed smoke, action
conditioning is the strongest single factor for holding-event ranking and
hard-negative/release behavior, while causal history helps mainly when action
is absent. Adding history on top of action is not supported by the primary
conditional metric in this run. This does not prove a CLaD graph-transition
advantage, a cross-task action effect, or graph superiority over B1/G1.
Challenge values remain stress analysis only, and the event metric remains
conditional/oracle-current unless the end-to-end counterpart is used.

The implementation gate passed, but the multi-task expansion gate did not yet
run. The next safe experiment is three folds at one seed with H2/H3 as
candidates and H0/H1 as ablations. Expansion to three seeds remains gated by
multi-task consistency, hard-negative safety, release improvement, and the
pending manual review of the 90 selected weak-label items. Full table and
factorial contrasts are in `docs/phase3_pair_local_temporal_smoke_result.md`.

## 2026-08-13 - Pair-local temporal three-fold seed-0 screen completed

The H0--H3 factorial completed 12/12 corrected runs across held-out tasks
0/1/2 at seed 0. The persistent result is
`corrected_protocol_v2/pair_local_temporal_threefold_seed0_v1/phase3_pair_local_temporal_threefold_seed0_v1.json`
with SHA256
`492d45521e6ccecbc4f0d89923f50d49642962d60c1c53daf093b5aec9b4d188`.
The original per-task display returned `None` because it searched flattened
metric names inside a nested holding evaluation; the result JSON was intact.
The Colab display cell now reads the explicit holding metric paths and prints
all task-level values correctly.

Natural conditional/oracle-current event PR-AUC task-macro means were H0
0.3626, H1 0.4348, H2 0.3941, and H3 0.4824. H3-H1, the action increment in
the presence of causal history, was +0.0476 and positive on all three tasks.
Its release F1 increment was +0.0978 and positive on all tasks; mean
hard-negative FPR decreased by 0.1019, although task 0 worsened by 0.0476.
H3-H0 was +0.1198 PR-AUC and positive on all tasks, but task-0 hard-negative
FPR worsened from 0.1429 to 0.4762. H1 alone reduced mean release F1, H2 action
alone improved PR-AUC on only one task, and the H3-H2 history increment reduced
mean release F1.

The decision is not to run the full three-seed factorial yet. H3 is retained
as the only candidate, but an episode-disjoint matched H3 train-action-shuffled
screen across the three task folds at seed 0 is required before seed expansion.
If aligned H3 does not beat the shuffled control on natural PR-AUC in at least
two tasks, or release/hard-negative behavior is unsafe, expansion stops. If it
passes, only H3, H1, and H3-train-shuffled receive seeds 1 and 2. This remains
an architecture gate, not a graph-transition or final CLaD representation
claim. Full results are in
`docs/phase3_pair_local_temporal_threefold_seed0_result.md`.

## 2026-08-13 - Non-destructive repository and Colab source consolidation

The active local repository and the live Colab stage were inventoried before
any cleanup. The running action-alignment training process, persistent Drive
output, checkpoints, and logs were treated as read-only. Large datasets and
model artifacts were not copied. Hash comparison showed that the reusable
manifest, probe, pair-local model, and helper scripts already match locally.
The live action-alignment config was restored locally with the same semantic
content (the local text has only an additional terminal newline); the local
runner is a documented superset that preserves completed snapshot behavior.

The stable source layout remains `scripts/phase*/` with root compatibility
wrappers. A risky `src/` migration was intentionally avoided. Six thin,
ordered runbooks were added under `notebooks/`, while the integrated legacy
notebook and all its historical cells were preserved with a deprecation notice.
Environment-specific path handling was centralized in
`scripts/research_paths.py`; new experiments can select local or Drive-backed
artifacts through environment variables without embedding workstation paths.

Repository entry points and operational boundaries are now documented in
`README.md`, `RESEARCH_GUIDE.md`, `docs/repository_audit_20260813.md`, and
`docs/archive_candidates_20260813.md`. No file was deleted, moved, or renamed.
Temporary transfer/staging material and bytecode caches were classified only
as later archive candidates.

Low-cost validation passed for Python syntax, all JSON/notebook parsing, new
notebook code-cell syntax and structure, Markdown links, credential-pattern
scanning, and 10 focused corrected-protocol/path/audit tests. Full local test
discovery remains unverified because this workstation does not currently have
PyTorch and `pytest`; real LIBERO replay, GPU training, and checkpoint loading
were deliberately not run during cleanup.
