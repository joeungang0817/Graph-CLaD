# Phase 3 Holding Weak-Label Audit v2

Date: 2026-08-12

Status: trajectory-enriched audit bundle and interactive reviewer are ready;
human decisions remain pending.

## Purpose and claim boundary

This is an initial screening audit of the heuristic holding labels, not a new
training split and not proof that the labels are correct. The review contains
three tasks times onset/release/hard-negative times ten items, for 90 total.
The 10-item cells can expose common or severe failure modes but are too small
for a precise task/event-specific error-rate estimate.

## Trajectory evidence

Audit v1 stored current/future graphs and the six-action window. Audit v2 also
reconstructs every graph frame from t through t+6. This permits inspection of
robot-object distance, relative xyz position, contact/holding changes,
object-following residual, and arm/gripper actions without relying only on the
final heuristic flags.

The rebuild passed all structural checks:

- 90/90 balanced audit items;
- 10 items in each of the nine task/event cells;
- seven trajectory frames in every item;
- 592 unique requested step graphs after overlap deduplication;
- 592/592 available, zero missing, zero conflicting graph payloads;
- 90 review rows, all initially unreviewed.

The original dataset and audit v1 remain unchanged. The 592 count is only the
deduplicated evidence copy needed by the 90 review windows.

## Interactive review

`scripts/phase3/weak_label_audit_viewer.py` provides task/event/status filters,
Previous/Next navigation, a current/future evidence table, three trajectory
plots, decision/error controls, reviewer notes, atomic CSV saving, and an
updated JSON summary. The viewer never assigns a verdict automatically.

Decision meanings:

- `pass`: the weak label is consistent with the independent trajectory view;
- `label_error`: the label is contradicted by trajectory evidence; an error
  type is required;
- `ambiguous`: the exported evidence is insufficient for a defensible binary
  decision; an evidence/error type is required.

Ambiguous items are not counted as passes. Review results must not be reported
until all required cells have been inspected.

## Expansion rule

This 90-item audit is the preregistered minimum screen. Any task/event cell
with a label error or substantial ambiguity should be expanded to at least 30
items. Even 0 errors in 10 leaves a roughly 30% one-sided 95% rule-of-three
upper bound; 0 in 30 reduces that bound to roughly 10%. A publication-quality
claim may therefore require 30 per cell (270 total), especially for release.

## Persistent artifacts

Root:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/corrected_protocol_v2/weak_label_audit_v2_trajectory`

Files include:

- `holding_weak_label_audit_manifest_v1.json`
- `holding_weak_label_audit_config_v2.json`
- `holding_weak_label_audit_runtime_manifest_v2.json`
- `holding_weak_label_audit_evidence_v1.jsonl.gz`
- `holding_weak_label_audit_review_v1.csv`

The code snapshot is stored in sibling directory
`code_snapshot_weak_label_audit_v2`.
