# Phase 3 Pair-Local Temporal Encoder Smoke Result

Date: 2026-08-12  
Protocol: `phase3-pair-local-temporal-smoke-v1`  
Fold/seed: `test_task1`, seed `0`  
Result: `phase3_pair_local_temporal_smoke_task1_seed0_v1.json`

## Scope

This is the corrected architecture/probe smoke, not a generalization result.
All models use the same sample IDs, natural-validation checkpoint selection,
natural-validation threshold frozen for test/stress/controls, action-free
current head, and causal history contract. H0--H3 process an independent
robot-object pair; there is no unrestricted object-object message passing.
History reads only frames at or before the current time. The conditional event
metric uses oracle current holding; the end-to-end metric is reported
separately.

## Natural test (primary view)

| Model | History | Action | Event PR-AUC | Event F1 | End-to-end PR-AUC | Onset F1 | Release F1 | Hard-negative FPR | Params |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| H0 | no | no | 0.3810 | 0.3671 | 0.1939 | 0.4270 | 0.0000 | 0.5000 | 59,688 |
| H1 | yes | no | 0.4960 | 0.5352 | 0.2207 | 0.6726 | 0.0000 | 0.3000 | 60,728 |
| H2 | no | yes | **0.5869** | 0.4184 | 0.2439 | **0.8837** | **0.2143** | **0.0900** | 59,708 |
| H3 | yes | yes | 0.5731 | 0.3357 | **0.4227** | 0.7872 | 0.1075 | 0.1100 | 60,476 |

Thresholds selected on natural validation were 0.95, 0.95, 0.90, and 0.85
for H0--H3 respectively. F1 is secondary because these thresholds are
validation-fitted and the smoke has one held-out task/seed.

## Factorial contrasts

| Contrast | Event PR-AUC | Release F1 | Hard-negative FPR |
|---|---:|---:|---:|
| H1 - H0 (history without action) | +0.1149 | +0.0000 | -0.2000 |
| H2 - H0 (action without history) | **+0.2058** | **+0.2143** | **-0.4100** |
| H3 - H1 (action with history) | +0.0771 | +0.1075 | -0.1900 |
| H3 - H2 (history with action) | -0.0138 | -0.1068 | +0.0200 |
| H3 - H0 (joint) | +0.1921 | +0.1075 | -0.3900 |

## Interpretation

Within this smoke, action conditioning is the strongest single factor for the
conditional event ranking and for release/hard-negative behavior. Causal
history helps when action is absent, especially for PR-AUC and onset, but its
increment on top of action is negative on the primary conditional metric.
H3's higher end-to-end PR-AUC shows that history can help when current state
must also be inferred, but its thresholded release result remains weak.

These observations do not establish a graph-transition advantage, a causal
action effect across tasks, or superiority over B1/G1. Challenge values are a
future-event-selected stress view from natural held-out episodes, not an
independent test. The result artifact also records per-sample predictions,
controls, calibration, causal-history QA, parameter matching, and the exact
Drive output root:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/corrected_protocol_v2/pair_local_temporal_smoke_task1_seed0_v1`

Result SHA256: `ae986247bc1d536269e94964d32a46e0c3167c1bd40b3015b623f2ced6148c502`.

## Next gate

Do not jump directly to 3 folds x 3 seeds. Run a three-fold, one-seed screen
with H2 and H3 as candidates and H0/H1 as ablations, retaining the same
corrected protocol and controls. Expand to three seeds only if the action or
history effect is consistent on at least two tasks, hard-negative behavior is
not materially worse, release improves, and the manual 90-item weak-label
review is no longer pending.
