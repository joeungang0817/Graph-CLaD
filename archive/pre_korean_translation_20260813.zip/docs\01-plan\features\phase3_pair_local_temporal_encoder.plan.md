# Phase 3 Pair-Local Temporal Encoder Plan

Date: 2026-08-12

Status: three-fold/seed-0 H0--H3 screen completed; H3 action-alignment control is next.

## Motivation

The corrected three-fold/seed-0 screen did not establish a stable advantage
for late-action G1 over the pair MLP or its train-shuffled control. It did,
however, improve release detection and hard-negative rejection. The next test
asks whether holding transitions need causal pair-local temporal state more
than complete scene message passing.

## Fixed 2 x 2 factorial

| Model | Past history | Action |
|---|---:|---:|
| H0 | no | no |
| H1 | yes | no |
| H2 | no | yes |
| H3 | yes | yes |

All four models use the same robot-object pair encoder, set-context capacity,
loss, natural-validation checkpoint rule, frozen threshold protocol, samples,
splits, epoch budget, and patience. Capacity differences must be reported and
kept near-matched through width selection or explicit adapters.

## Causal feature contract

Every temporal feature is computed only from frames at or before current time
t. No future frame, future event identity, or future holding heuristic may be
read by the encoder.

- gripper-object relative-position delta;
- relative velocity;
- contact persistence;
- gripper closure velocity;
- object-following stability;
- one validity mask for every feature family.

History windows, timestamp gaps, missing-frame handling, normalization source,
and masks must be written into the manifest/runtime artifact. Features used by
the weak holding label may be inputs only when their computation is strictly
causal at t.

## Architecture boundary

Encode each target robot-object pair independently first. Scene context, when
used, is limited to a permutation-invariant DeepSets summary or pair-set
attention over pair tokens. Do not introduce unrestricted object-object
message passing in this gate. Action is conditioned at the pair temporal
encoder or transition block, not only concatenated at the final global head.

## Evaluation and expansion

Start with the same task-1/seed-0 corrected smoke, then run three folds at one
seed only for architectures that pass technical and leakage QA. Natural-test
conditional event PR-AUC remains primary, but end-to-end event PR-AUC/F1,
onset/release F1, hard-negative FPR, Brier/ECE, action/history ablations, and
per-sample predictions are mandatory.

Expand to three seeds only if history or action gains are consistent over at
least two tasks, hard-negative behavior is not materially worse, and release
performance improves without relying solely on an extreme selected threshold.
Use hierarchical bootstrap with task as the outer unit. The 90-item weak-label
manual review should be completed before interpreting small gains.

The trajectory-enriched audit viewer is now implemented and has 592/592
deduplicated graph-frame coverage for the 90 selected items. Model
implementation may proceed in parallel, but no small H0--H3 gain should be
interpreted as label-valid until the review decisions are completed.

## Smoke result (2026-08-12)

The causal pair-local implementation was run on task 1, seed 0 with the
corrected natural-validation protocol. Natural conditional/oracle-current
event PR-AUC was H0 0.3810, H1 0.4960, H2 0.5869, and H3 0.5731. The factorial
contrasts were H1-H0 +0.1149, H2-H0 +0.2058, H3-H1 +0.0771, and H3-H2 -0.0138.
H2 had the best natural release F1 (0.2143) and hard-negative FPR (0.0900),
while H1 improved calibration and onset detection but had no release hits.
H3 had the highest natural end-to-end event PR-AUC (0.4227), but its
conditional PR-AUC and release F1 were below H2. Thus action is the strongest
single factor in this smoke, history is useful without action, and adding
history on top of action is not yet justified by the primary conditional
metric.

This is one task and one seed only. It passes the implementation/leakage gate,
not the multi-task expansion rule; the next safe experiment is a three-fold,
one-seed screen focused on H2 and H3 (with H0/H1 retained as ablations), after
control outputs and the 90-item manual weak-label review are recorded.

## Three-fold seed-0 result (2026-08-13)

The 12-run screen completed on all task folds. Task-macro natural conditional
event PR-AUC was H0 0.3626, H1 0.4348, H2 0.3941, and H3 0.4824. H3-H1 was
+0.0476 and positive on all three tasks; release F1 also improved on all three
tasks and mean hard-negative FPR decreased by 0.1019. H3-H0 PR-AUC was
+0.1198 and positive on all tasks, but task-0 hard-negative FPR deteriorated
substantially. H3-H2 history gains were positive on only two tasks and reduced
mean release F1.

H3 is retained as the only candidate. Before adding seeds, run a three-fold,
seed-0 H3 train-action-shuffled control with episode-disjoint matched donors.
Only if aligned H3 beats that control on natural PR-AUC in at least two tasks
without unsafe release or hard-negative behavior should seeds 1 and 2 be run
for H3, H1, and H3-train-shuffled. Detailed values are in
`docs/phase3_pair_local_temporal_threefold_seed0_result.md`.
