# Graph-CLaD 수정 연구 로드맵 v3

작성일: 2026-08-06  
최종 갱신: 2026-08-11  
상태: **현재 실행 기준**  
대체 문서: `docs/revised_research_roadmap_v2.md`  
현재 단계: **Phase 3B-R1 - 평가 고정 및 target-centric/action-conditioned GNN 검증 준비**

## 1. 이번 개정의 핵심

앞으로의 주 데이터는 scripted holding-positive frame 모음이 아니다. task 0·1·2의
official human-teleoperation demonstration 전체를 다음 성격의 데이터셋으로 변환한다.

> **LIBERO Demo-derived, Event-centered, Multi-horizon, Oracle Relational
> Dynamics Dataset**

핵심 변경은 여섯 가지다.

1. scripted probe는 extractor 단위·회귀검사에만 사용하고 main training에서 제외한다.
2. action replay보다 저장된 MuJoCo state의 exact replay를 label 생성의 primary path로
   사용한다.
3. holding은 단일 frame 조건이 아니라 temporal evidence state machine으로 정의한다.
4. 전체 trajectory를 보존하고 relation event index로 sampling한다.
5. demo ID split을 threshold, normalization, event sampling보다 먼저 고정한다.
6. Phase 3의 baseline, changed-event metric, action/edge control을 공정하게 다시 정의한다.

Phase 0, Phase 1A, Phase 2A의 기반은 유지한다. Phase 2R scripted dataset과 기존 Phase 3
결과는 diagnostic history로 보존하지만 새 연구 주장에는 사용하지 않는다. Phase 4는 새
Phase 2D와 Phase 3 gate가 통과할 때까지 차단한다.

## 2. 연구 질문과 주장 범위

### 주 연구 질문

동일한 demonstration, split, input information, training budget을 사용할 때 object-relation
graph가 non-message baseline보다 action 이후 relation event와 미래 relation state를 더
잘 예측하며, 그 개선이 통제된 CLaD latent foresight와 policy 성능으로 이어지는가?

### 주장 범위

- simulator-state oracle graph를 사용한 feasibility study다.
- 공식 CLaD 수치 재현이 아니라 제공 코드 3개를 기반으로 한 controlled
  reimplementation 내부 비교다.
- offline graph 개선, CLaD Stage 1 개선, Stage 2 success 개선은 각각 별도 gate와 주장으로
  분리한다.
- official demonstration의 state와 action을 사용하지만 reward, success, BDDL goal,
  object-of-interest는 model input에 넣지 않는다.

## 3. 고정 통제 원칙

- 원 연구자에게 받은 `Attentions.py`, `MlpResNet.py`, `LatentDynamics.py`는 reference로
  보존하고 직접 수정하지 않는다.
- raw demo, replayed timeline, graph timeline, event index, window manifest를 분리한다.
- 같은 demo에서 나온 frame과 window는 절대 다른 split으로 보내지 않는다.
- normalization과 모든 threshold/hysteresis는 train demo만 사용해 결정한다.
- oracle label evidence와 model input feature를 별도 schema로 관리한다.
- GNN과 non-message baseline은 같은 node/action/history 정보와 같은 target을 받는다.
- parameter count는 목표 대비 ±5% 이내로 맞추고 FLOPs, latency, memory도 함께 기록한다.
- event-balanced sampler를 사용하더라도 test 결과는 자연 분포와 event subset을 모두
  보고한다.
- gate를 통과하지 않은 단계의 positive claim은 다음 단계에 전달하지 않는다.

## 4. 현재까지의 단계 상태

| 단계 | 상태 | 이후 역할 |
|---|---|---|
| Phase 0 baseline smoke | 완료 | 제공 코드 실행 경계와 unknowns 유지 |
| Phase 1A state/API audit | 완료 | state-replay 구현의 API 기반 |
| Phase 2A static GraphSpec | 완료 | deterministic extractor regression baseline |
| Phase 2R scripted dynamics prototype | 계측 목적 완료 | contact/handler/frame 회귀검사 전용; main training 제외 |
| Phase 3 historical probe | diagnostic 완료, gate open | 모델/trainer 골격과 실패 원인 및 historical comparator 보존 |
| Phase 2D demo dataset | 완료 | official demo task 0·1·2 source와 holding event index 제공 |
| Phase 3A dataset QA | 1차 완료, E0 개정 진행 | sampler·outer fold·natural/challenge manifest 고정 |
| **Phase 3B offline dynamics** | **R1 계획 확정/현재 단계** | shortcut control과 2 x 2 graph ablation 실행 |
| Phase 4 Graph-CLaD Stage 1 | 차단 | Phase 3B gate 통과 필요 |
| Phase 5-8 Stage 2/평가 | 차단 | Stage 1 gate와 baseline policy 준비 필요 |

전체 점검 근거는 `docs/03-analysis/graph-clad-research-roadmap.analysis.md`에 기록한다.

## 5. Phase 2D - demonstration 기반 dataset 구축

### 5.1 목적

task 0·1·2의 full demonstration을 보존하면서 action-conditioned relation event를 학습할
수 있는 canonical oracle graph timeline과 multi-horizon sample manifest를 만든다.

### 5.2 D0 - 원천 데이터와 provenance 고정

#### 작업

- 대상 suite와 task 0·1·2의 official demonstration HDF5를 확보한다.
- HDF5의 demo key마다 다음을 manifest에 기록한다.
  - source URL 또는 local source description
  - HDF5 file checksum과 demo key
  - task/suite/language/BDDL file과 checksum
  - environment metadata와 controller/action dimension
  - LIBERO, robosuite, MuJoCo, Python 버전 또는 commit
  - state/action 길이와 성공 여부 audit
- raw HDF5는 수정하지 않고 read-only source로 취급한다.
- label을 만들기 전에 split manifest를 생성한다.

#### split protocol

1. **In-task**: task 0·1·2 각각 demo ID 단위 train/validation/test
2. **Task-generalization**: task 0·1 train, task 0·1 held-out demo validation, task 2 test

동일 demo의 모든 인접 frame과 모든 horizon window는 같은 split에 속한다.

#### 완료 gate

- 모든 demo에 stable ID와 checksum이 있다.
- train/validation/test demo ID가 완전히 disjoint하다.
- split manifest가 threshold와 normalization 코드보다 먼저 입력된다.
- task 2 test를 본 뒤 split이나 threshold를 바꿀 수 없도록 config hash를 남긴다.

### 5.3 D1 - exact state replay

#### primary path

각 시점의 저장된 MuJoCo state를 동일 task environment에 직접 설정하고 simulator forward
후 oracle evidence를 다시 추출한다.

- robot base와 EFF pose/orientation
- gripper qpos와 joint state
- object/fixture/site pose
- raw MuJoCo geom contact: geom/body name, finger side, contact pair
- object-support contact
- wrapper 또는 geometry evidence for on/inside/contact
- raw world pose와 robot-base 변환 pose

저장 action은 state를 생성하는 primary 방법이 아니라
`G_t + action_{t:t+tau-1} -> G_{t+tau}`의 입력으로 사용한다.

#### action replay audit

소수의 train/validation episode에서만 action replay를 수행해 저장 state와의 drift를
측정한다. action replay 결과를 label source로 섞지 않는다.

#### timing contract

반드시 다음을 실측해 unit test로 고정한다.

```text
state[t] + action[t] -> state[t+1]
```

dataset마다 저장 state가 action 전인지 후인지 다를 수 있으므로 이름만 보고 가정하지
않는다.

#### 완료 gate

- 선택한 모든 demo의 state replay가 NaN 없이 끝난다.
- replay 후 핵심 qpos/object pose가 저장 state와 설정 tolerance 안에서 일치한다.
- action/state 길이와 `t -> t+1` 정렬이 검증된다.
- 실패 demo는 이유와 함께 quarantine되고 조용히 삭제되지 않는다.

### 5.4 D2 - canonical graph timeline

#### node policy

primary graph는 BDDL goal과 무관한 scene inventory 규칙으로 만든다.

- `robot0`: EFF를 대표하는 stable robot node
- 모든 movable object
- 물리적 fixture/receptacle
- capability/type 규칙으로 포함한 semantic site

BDDL goal을 보고 task-relevant node만 고르는 것은 node-set leakage가 될 수 있으므로
primary에서 금지한다. all-sites와 BDDL-task-relevant graph는 각각 size ablation과
privileged ablation으로만 사용한다.

#### model input에서 제외

- logical name/instance string embedding
- task ID와 language-derived goal shortcut
- `is_object_of_interest`
- BDDL goal predicate
- reward, success, done/terminal
- future state 또는 future event distance

logical ID는 alignment key로만 사용한다.

#### frame과 feature

- primary pose: robot-base frame
- raw world pose: audit only
- position, velocity, gripper/joint state, type, validity mask
- orientation은 runtime convention 확인 후 6D rotation ablation으로 추가
- node feature schema는 static v1의 24차원 vector를 그대로 답습하지 않고 privileged
  slot을 물리적으로 제거한 새 version으로 고정

#### graph storage

episode마다 `G_0...G_T`를 한 번만 저장한다. window마다 graph를 복제하지 않고 frame
index로 참조한다.

#### 완료 gate

- logical ID가 episode 내 모든 frame에서 안정적으로 정렬된다.
- robot-base transform, inverse relation, contact symmetry test가 통과한다.
- node set이 BDDL goal을 바꿔도 primary rule상 바뀌지 않는 leakage test가 통과한다.
- 최소 여러 frame의 graph/contact overlay를 사람이 검토한다.

### 5.5 D3 - relation label과 temporal event

#### 공통 record

모든 relation label은 최소 다음 구조를 갖는다.

```json
{
  "value": true,
  "valid": true,
  "confidence": "high",
  "definition_version": "holding.temporal.v1",
  "evidence": {
    "left_finger_contact": true,
    "right_finger_contact": true,
    "closed_gripper": true,
    "relative_pose_stable": true,
    "object_followed_eef": true,
    "lifted_or_support_released": true
  }
}
```

애매한 상태는 `value=false`가 아니라 `valid=false`로 둘 수 있어야 한다.

#### contact

- logical pair뿐 아니라 raw geom/body contact provenance를 보존한다.
- left finger, right finger, palm/wrist, object-support contact를 구분한다.
- collision 한 frame과 지속 contact segment를 모두 파생한다.

#### holding state machine

```text
free -> contact_candidate -> holding -> release
```

`holding(robot0, object)`의 high-confidence 조건:

1. finger-object contact
2. train-calibrated sufficiently closed gripper
3. object-EFF relative transform가 K frame 동안 안정적
4. object가 EFF displacement를 따라가거나 lift/support-release evidence가 있음

K, translation/rotation threshold, onset/release hysteresis는 train demo에서만 결정한다.
bilateral finger contact는 confidence를 올리지만 모든 물체에 일률적인 hard requirement로
두지 않는다.

#### on/inside

- LIBERO wrapper가 신뢰 가능한 boolean을 주면 우선 사용한다.
- `on` fallback은 support contact, horizontal footprint overlap, vertical gap, K-frame
  persistence를 함께 본다.
- `inside` fallback은 explicit containment capability와 source volume/representative points의
  containment를 사용한다. source center 하나만 AABB 안에 있는 규칙은 primary label로
  사용하지 않는다.
- threshold 근처 flicker는 hysteresis와 invalid boundary로 처리한다.

#### event index

다음 onset/offset을 frame index로 저장한다.

- contact start/end
- holding start/release
- lift start/support release
- on start/end
- inside start/end
- object-object geometric relation change

#### 완료 gate

- relation/task/split별 valid, positive, segment, onset, offset count가 보고된다.
- rare positive 전수 또는 최소한의 stratified manual audit가 끝난다.
- contact-only, motion-only, combined holding detector의 disagreement가 기록된다.
- label flicker와 평균 event duration이 허용 범위인지 검토된다.

### 5.6 D4 - event-centered multi-horizon window manifest

canonical timeline에서 목적이 다른 두 sample view를 만든다. 둘을 한 실험 안에서
혼합하거나 같은 이름으로 보고하지 않는다.

```text
View A - action-conditioned forward dynamics:
G_t + action_{t:t+tau-1} -> G_{t+tau}

View B - CLaD-aligned foresight:
G_{t-h:t} + action_{t-h:t-1} -> G_{t+tau}

tau in {1, 3, 6}
```

- View A는 GNN relational classifier에 가까운 action-conditioned dynamics probe에
  사용한다.
- View B는 CLaD가 실제 추론 시 사용할 수 있는 current/past graph와 past action만
  사용한다. `action_{t:t+tau-1}`를 View B나 Stage 1 adapter에 넣지 않는다.
- history `h`는 CLaD의 `tau` 간격 endpoint와 recurrent 후보 길이를 모두 지원한다.
- positive event, hard negative, background, ambiguous audit tag를 저장한다.
- event frame을 물리적으로 복제하지 않고 sampler weight만 조절한다.
- 한 event의 겹치는 window가 split 경계를 넘지 않게 한다.
- task 0·1·2 모두 같은 pipeline과 relation definition version을 사용한다.

#### sample category

| 종류 | 예시 | sampler 역할 |
|---|---|---|
| Positive event | grasp onset, lift, inside onset | 희귀 변화 oversampling |
| Hard negative | push-only contact, empty close, transient collision | false positive 억제 |
| Background | relation 변화 없음 | 자연 dynamics 분포 유지 |
| Ambiguous | state-machine 경계, evidence 충돌 | loss mask/QA 전용 |

#### 완료 gate

- horizon 1/3/6과 history index가 같은 source timeline을 정확히 참조한다.
- future field가 model input serialization에 들어가지 않는다.
- View B에 target interval의 future action이 들어가지 않는 leakage test가 통과한다.
- sampler를 끈 full-uniform test manifest가 별도로 고정된다.
- scripted probe source sample 수가 main split에서 0이다.

### 5.7 Phase 2D 최종 산출물

권장 파일 계획:

```text
configs/phase2d_demo_dataset.json
data/manifests/libero_demo_sources.json
data/manifests/phase2d_split_v1.json
data/manifests/phase2d_window_index_v1.json
scripts/index_libero_demos.py
scripts/replay_libero_states.py
scripts/build_demo_graph_timeline.py
scripts/derive_relation_events.py
scripts/build_event_window_manifest.py
scripts/validate_phase2d_dataset.py
tests/test_demo_state_alignment.py
tests/test_temporal_holding.py
tests/test_event_windows.py
tests/test_phase2d_leakage.py
docs/phase2d_demo_dataset.md
```

대용량 raw/replayed data는 외부 저장소나 Drive에 둘 수 있지만 manifest, checksum,
config, QA summary는 repository에 남긴다.

## 6. Phase 3A - dataset QA와 label gate

모델 학습 전에 dataset만 검증한다.

### 필수 보고

- demo/task/split별 frame과 window 수
- relation별 valid/positive/negative/onset/offset 수
- event duration과 inter-event interval
- positive/hard-negative/background 비율
- horizon별 changed-event support
- task 2 holding applicability와 positive support
- replay consistency와 quarantined demo
- manual label audit 사례와 오류율
- input leakage 검사와 manifest checksum

### gate

- relation event가 train과 평가 split에 충분히 존재한다.
- support가 없는 relation은 metric에서 자동 제외되고 이유가 기록된다.
- task 2에 holding positive가 없다는 이유만으로 threshold를 낮추지 않는다.
- ambiguous가 negative로 섞이지 않는다.
- QA를 통과하기 전 Phase 3B training을 실행하지 않는다.

## 7. Phase 3B - action-conditioned offline relational dynamics 재검증

이 단계는 Phase 2D의 **View A**를 사용한다. 목적은 현재 graph와 실제로 실행된 action
window가 주어졌을 때 graph structure가 미래 relation dynamics를 더 잘 예측하는지
검증하는 것이다. 이는 relational dynamics의 필요조건이지만 CLaD adapter의 causal
입력 조건을 직접 검증한 것은 아니다.

### 7.1 모델 비교

| ID | 모델 | 역할 |
|---|---|---|
| P0 | legacy flat padded MLP | 과거 결과 연결용 diagnostic |
| P1 | pairwise MLP 또는 DeepSets context + pair query, no message | primary non-graph baseline |
| P2 | complete GNN, empty edge input | message passing 효과 |
| P3 | GNN + geometry edge attributes | 명시적 geometry 효과 |
| P4 | GNN + learned soft edge/attention | learned interaction 효과 |
| P5 | P4 + history/recurrent encoder | G-DOOM식 history 효과 |

모든 모델은 같은 node feature, action temporal encoder, history window, relation target을
받는다. P1과 P2의 차이는 message passing이 중심이 되도록 설계한다.

### 7.2 학습 target

초기 primary objective:

```text
L = lambda_future * masked_future_relation_loss
  + lambda_event * masked_onset_offset_loss
```

단계적 ablation으로 다음을 추가한다.

- current relation auxiliary loss
- future latent graph consistency
- displacement/orientation auxiliary loss
- history/recurrent state
- contrastive dynamics objective

한 번에 모두 켜지 않고 각 추가 term의 이득을 분리한다.

### 7.3 공정한 control

- **No message**: complete empty-edge GNN의 primary structural control
- **No action retrain**: action encoder를 제거하고 같은 budget으로 다시 학습
- **Zero action at test**: distribution-shift stress test로 별도 표기
- **Shuffled action**: 같은 task/horizon에서 다른 demo의 action window를 seeded
  derangement하고 identity permutation이 없는지 검사
- **Edge-attribute permutation**: P3/P4의 geometry/edge attribute와 node pair 대응을 깸
- **Learned-edge corruption**: sparse/learned edge variant에서만 topology control 사용
- **Label permutation**: train label sanity check
- **History ablation**: P5와 같은 current graph만 쓰는 모델 비교

complete graph의 empty-edge P2에는 “correct topology 대 shuffled topology”를 주 control로
사용하지 않는다. 가능한 모든 pair가 이미 존재하기 때문이다.

### 7.4 metric

서로 다른 의미를 한 이름으로 합치지 않는다.

1. `future_relation_macro_f1_uniform`
2. relation별 precision/recall/F1과 PR-AUC
3. `future_value_f1_on_true_changed_subset`
4. `change_event_f1`: current와 predicted future의 XOR 대 true change
5. onset F1과 offset F1
6. event-time tolerance F1 (`±1`, `±2` frame)
7. horizon 1/3/6 degradation
8. calibration(Brier/ECE)과 rare-relation PR-AUC
9. parameter count, FLOPs, training time, inference latency, memory
10. seed 평균/표준편차와 paired confidence interval

test는 full-uniform timeline과 event-centered subset을 모두 보고한다. sampler-weighted
validation 수치만으로 최종 결론을 내리지 않는다.

### 7.5 Phase 3B 완료 gate

다음을 모두 요구한다.

- P2/P3/P4 중 적어도 하나가 primary no-message P1보다 future/change-event metric에서
  여러 seed에 걸쳐 일관되게 우수
- correct action이 no-action retrain과 shuffled-action보다 우수
- edge-aware 모델은 edge-attribute corruption에서 성능이 하락
- horizon 1/3/6과 in-task/task-generalization 결과가 모두 보고됨
- support 없는 relation을 0점으로 넣어 macro score를 왜곡하지 않음
- old scripted dataset 결과와 new demo dataset 결과를 혼합하지 않음

통과하지 못하면 Phase 4로 가지 않고 relation ontology, event window, action encoding,
history 길이, baseline parity를 먼저 재검토한다.

## 8. Phase 3C - CLaD-aligned foresight bridge

### 목적

Phase 2D의 **View B**를 사용해 future action 없이도 past/current graph transition이
CLaD의 future latent/relation 예측에 유용한지 확인한다. View A에서 좋은 모델이 이
조건에서도 좋을 것이라고 가정하지 않는다.

### 입력 경계

```text
available: G_{t-h:t}, action_{t-h:t-1}, current/past CLaD inputs
target only: G_{t+tau}, future latent, relation events
forbidden: action_{t:t+tau-1}, reward, success, terminal, BDDL goal
```

언어 조건이 필요하면 CLaD baseline과 graph/no-message 모델 모두에 동일한 language
embedding을 제공하는 별도 controlled ablation으로만 추가한다.

### 비교와 metric

- P1 primary no-message와 Phase 3B에서 선택된 graph encoder 비교
- current graph only 대 graph history/recurrent 비교
- past action 제거/순서 shuffle control
- future relation/event metric과 CLaD future-latent auxiliary metric
- horizon 1/3/6과 in-task/task-generalization 결과

### 완료 gate

- graph model이 P1보다 여러 seed에서 일관된 future relation/event 이득을 보임
- past action/history control에서 예상되는 하락이 확인됨
- target interval의 future action이 input에 없음을 serialization test로 확인

View A만 통과하고 View B가 통과하지 않으면 “action-conditioned graph forward model은
유효하지만 CLaD foresight adapter의 근거는 부족함”으로 결론 내리고 Phase 4를 보류한다.

## 9. Phase 4 - Graph-CLaD Stage 1 통합

### 선행 조건

- Phase 3B와 Phase 3C gate 통과
- 제공되지 않은 전체 Stage 1 trainer/VLM pipeline을 controlled reimplementation으로
  명시하고 baseline과 graph variant에 동일하게 적용
- action history packing, EMA update, loss weighting, view/VLM contract를 config로 고정

### 권장 통합

CLaD의 asymmetric cross-modal dynamics를 유지하면서 graph transition representation을
semantic transition에 residual로 넣는다.

```text
z_graph = GraphTransitionEncoder(G_{t-h:t}, a_{t-h:t-1})
z_graph_h = Project(z_graph)
z_s_graph = z_s_clad + alpha * z_graph_h
z_dyn = CrossAttn(z_p, z_s_graph)
```

- `alpha=0` 또는 adapter off일 때 baseline output과 수치적으로 동일해야 한다.
- baseline CLaD, matched MLP adapter, no-message adapter, graph adapter를 같은 trainer로
  비교한다.
- graph relation/event auxiliary loss는 on/off ablation이 가능해야 한다.
- future oracle graph는 target일 뿐 model input으로 들어가지 않는다.

### 완료 gate

- adapter-off equality test 통과
- 동일 split/seed/optimizer/update 수/config-diff 검사 통과
- graph adapter가 matched MLP와 no-message control보다 미래 latent와 relation-event
  metric에서 일관되게 우수
- official CLaD 재현이 아니라 controlled comparison임을 결과에 명시

## 10. Phase 5-8 - Stage 2와 최종 비교

### Phase 5 - baseline Stage 2

제공 코드에 없는 diffusion policy를 하나의 통제된 architecture/recipe로 구현하고
reimplemented CLaD foresight로 최소 rollout이 학습되는지 확인한다.

### Phase 6 - Graph Stage 2

Baseline Stage 1과 Graph Stage 1을 각각 고정한다. 동일 architecture, initialization seed,
batch order, optimizer, diffusion schedule, update 수로 Stage 2 policy를 각각 별도 학습한다.

### Phase 7 - 최종 평가

- task별/평균 success rate
- fixed rollout initial-state manifest
- 최소 3 seeds와 paired comparison
- relation-critical subset과 failure case
- parameter/latency/memory
- offline event metric과 policy success의 상관

### Phase 8 - 보고

- official CLaD 수치와 직접 비교하지 않음
- oracle privilege, missing official pipeline, task/support limitation 공개
- 성공하지 못한 gate와 negative result도 연구노트에 보존

## 11. 바로 다음 실행 체크리스트

다음 작업은 Phase 2D-D0/D1이다.

1. Colab/Drive에서 task 0·1·2 official demo HDF5 위치와 파일 구조 확인
2. source checksum과 environment metadata manifest 생성
3. demo ID split manifest를 label 전에 고정
4. demo 1개에서 state/action timing과 exact state replay 검증
5. finger-level raw contact와 EFF/object relative pose를 포함한 timeline sample 생성
6. View A와 View B의 시간축/leakage unit test 작성
7. sample을 사람이 확인한 뒤에만 전체 demo로 확장

holding-positive task 2를 만들기 위한 scripted calibration은 더 이상 다음 작업이 아니다.
task 2 official demo에 holding event가 있으면 동일 pipeline이 검출해야 하고, 없다면 그
사실을 support audit로 보고한다.

## 12. 실행 시 참조 우선순위

1. 현재 로드맵: `docs/revised_research_roadmap_v3.md`
2. 전과정 점검: `docs/03-analysis/graph-clad-research-roadmap.analysis.md`
3. 누적 연구 기록: `docs/research_log.md`
4. 정적 GraphSpec 역사: `docs/phase2_graph_spec.md`
5. 기존 Phase 3 diagnostic: `docs/phase3_offline_probe.md`
6. 이전 로드맵: `docs/revised_research_roadmap_v2.md` - historical only

이미 수행한 실험 수치와 오류 기록은 덮어쓰지 않는다. 해석이 바뀐 경우 새 연구노트
항목과 새 roadmap version에서 명시적으로 정정한다.
## Execution update - 2026-08-06

Phase 2D-D0/D1 has now been executed on one official `libero_spatial`
demonstration in Colab. The official HDF5 source was downloaded, the task-0
demo-0 state/action schema was inspected, exact state replay passed at four
probe indices with maximum error `0.0`, and action replay was retained only as
an audit because its first-step drift was `0.098253` in the flat simulator
state. The replayed frame timeline was converted to robot-base coordinates,
corrected raw gripper-contact mapping was applied, the temporal holding state
machine produced one interval (steps 43-87), and a 98-frame graph timeline
with horizons 1/3/6 and a relation-event index was written in Colab.

At the time of this entry, this was a representative handshake rather than
the full demo release. The subsequent full-demo execution and QA are recorded
in the update below.

## Execution update - 2026-08-06 - Phase 2D full-demo gate passed

The scoped Phase 2D pipeline has now been applied to all 150 official
`libero_spatial` demos for task 0/1/2 (50 per task). The split manifest was
created before label extraction. The resulting task datasets contain 18,429
state-replayed frames and 53,787 multi-horizon sample-index rows. Per-task
state-replay maximum absolute error is `0.0`; action replay was not used for
labels.

The corrected QA confirms:

- in-task episode split: train 113, validation 19, test 18;
- task generalization split: task 0+1 train 100, task 2 test 50;
- all three task files contain 50 unique demo records with no duplicate keys;
- manifest-to-dataset split mismatch count is zero.

Phase 2D full-demo construction is therefore complete for the scoped suite.
The next phase is the relation-support/event-label audit and revised Phase 3
forward-dynamics gate. Phase 4 remains blocked until the View A and View B
controls pass under the fixed splits.

## Execution update - 2026-08-06 - relation audit prepared; runtime artifact pending

The relation-support/event-label gate was started, but the Colab connection
available during this execution was a fresh runtime. The notebook retained
the previous full-demo QA output, whereas the runtime filesystem no longer
contained `/content/Graph-CLaD-phase2r-scaleup-r3` or its `phase2d_*` files.
No relation coverage result is therefore promoted from this attempt.

The reproducible audit implementation is now
`scripts/phase2d/audit_relations.py`. It will be run against the three
task-specific compressed JSONL files after the artifacts are restored. The
audit covers relation validity/positives, event and holding-state coverage,
holding evidence, horizon/action-window contracts, and model-input metadata
leakage. Phase 3 and Phase 4 remain gated until this audit is executed on the
actual full-demo artifacts.

## Execution update - 2026-08-06 - persistent artifact policy

The reset-safe recovery bundle is stored at
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d`. It contains the official
task-0/1/2 HDF5 inputs, the fixed 150-demo split manifest, restored project
code/configuration, and checksum metadata. The authoritative local policy is
`docs/colab_runtime_persistence.md`.

Future generation and audit runs must copy each completed dataset and QA
result to that Drive root before the run is considered complete. The current
fresh runtime has not produced a new graph JSONL release; its dependency
compatibility issue is recorded in the research log. This does not invalidate
the preserved inputs, but it keeps the relation gate and Phase 3/4 transition
closed until a clean rerun is verified.

## Execution update - 2026-08-06 - reconnected clean-runtime gate

After reconnecting Colab, the persistent inputs were restored and the runtime
compatibility issue was resolved for the preflight: robosuite 1.4.1 plus a
MuJoCo-3 mass-matrix shim. Exact state replay passed with maximum error `0.0`,
and the robot-base graph smoke test passed.

Before running all task 0/1/2 demonstrations, one implementation gap was
confirmed: the current fallback holding handler is frame-local. The full
converter must add the temporal state machine (`free -> contact_candidate ->
holding -> release`) and save its evidence fields. The prior notebook-history
summary claiming a complete 150-demo release is not accepted as evidence in a
fresh runtime; only Drive-persisted datasets with checksums and coverage QA
can close Phase 2D.

## Execution update - 2026-08-07 - current gate after holding challenge experiments

The later Drive-persisted releases supersede the temporary blockers described
above. Phase 2D task 0/1/2 official-demo generation, input cleaning, temporal
holding extraction, and target-aligned holding support are complete for the
scoped dataset. The target-aligned release and compact summary are documented
in `data/phase2d_holding_target_summary.json`.

Two 45-run holding challenge experiments were completed. The current
category-aware v3 result places P0 flat MLP first on mean changed-relation
macro F1, but this does not close the Graph-CLaD gate. The v3 category sampler
has a greedy episode traversal in its quota stage, its category counts are
multi-label rather than mutually exclusive, and target-aligned test selection
defines a challenge set rather than natural prevalence evaluation.

The active roadmap is therefore:

1. preserve balanced-v3 as `category_aware_v1` provenance;
2. validate the corrected `category_aware_episode_round_robin_v2` sampler;
3. separate natural test and holding challenge test;
4. revise folds so a held-out task is tested after training on the remaining
   tasks with episode-level validation;
5. implement target-centric holder-object edges and action-conditioned
   temporal edge updates;
6. run paired flat/target-only/geometry/holder-edge controls before Phase 4.

Methodological risks and claim boundaries are in
`docs/research_risk_review_20260807.md`. The next graph design is in
`docs/phase3_holder_object_action_graph_design.md`. Phase 4 remains gated.

## Execution update - 2026-08-11 - Phase 3B-R1 plan

The active Phase 3B revision is now a staged factorial test of two separate
hypotheses: holder-object sparse topology and action-conditioned message
updates. Evaluation and shortcut controls are frozen first; then complete
versus sparse topology and late/global versus edge-conditioned action are
compared as a 2 x 2 design. The combined model is the expected final candidate,
but it advances only if it beats both the pair-only MLP and the relevant
single-change graph cells on fixed natural and holding-challenge evaluations.

The authoritative execution plan is
`docs/01-plan/features/phase3_target_centric_action_conditioned_gnn.plan.md`.
It also corrects the metric terminology: the historical
`holding_changed_f1` is retained as future holding-value F1 on a true-changed
subset, while actual change-event F1, onset/release F1, PR-AUC, and
hard-negative false-positive rate become the primary holding metrics. Phase 4
remains blocked until this plan's full paired gate passes.

## Execution update - 2026-08-11 - E0 and G1 smoke gate

E0 passed with zero warnings and was persisted as
`phase3B_R1_eval_manifest.json` under the `phase3_holder_action_v1` Drive
artifact root. The task-0 fold contains 1,200 train rows, 474 validation rows,
486 natural-test rows, and 167 holding-challenge rows, with the same selected
sample IDs reused by all smoke models.

The first smoke comparison also completed and was persisted as
`smoke_test_task0_seed0.json`. G1 sparse holder-object GNN improved overall
changed-relation F1 over P0 from 0.546 to 0.628 on natural test and from 0.660
to 0.677 on challenge test. Holding change-event F1 improved from 0.705 to
0.833 on natural test and from 0.779 to 0.909 on challenge test. B1 pair MLP
reached 0.000 holding change-event F1 in both test views, so a pair-only
shortcut is not sufficient in this smoke setting.

The action-shuffle gap for G1 remained small, so the smoke supports sparse
topology rather than action use. The next gated experiment is G3, which keeps
the sparse holder-object edges and moves the action embedding into the edge
message/gate. The full 3-fold/3-seed comparison remains deferred until G3 has
passed the same smoke-level QA.

## Execution update - 2026-08-11 - G3 action-edge gate

G3 completed on the same task-0 fold and fixed sample IDs. Overall
changed-relation F1 increased from G1's 0.628/0.677 to 0.656/0.698 on natural
and challenge test, respectively. The edge-shuffle drops were also positive.
But holding change-event F1 fell from 0.833/0.909 for G1 to 0.732/0.811 for
G3, and the action-shuffle gap remained zero or slightly negative. Therefore
G3 does not pass the action-conditioning gate and will not be expanded to the
full 3-fold/3-seed run yet. The next step is to verify action-window variance,
alignment, and shuffle-control behavior before changing the architecture
again.

## Execution update - 2026-08-11 - Action-signal diagnostic

The action diagnostic completed and was saved as
`action_signal_diagnostic_task0.json` in the `phase3_holder_action_v1` Drive
artifact root. The action window has six steps and seven dimensions, with
values in `[-1, 1]` and non-trivial variation in both natural and
target-aligned samples. The checked interval is aligned as `start_step=0`,
`target_step=6`, `tau=6`.

Thus the weak action-shuffle result is not caused by an all-zero or constant
action input. Before another architecture change, the action permutation
control and redundancy with current gripper/node features should be examined.
No full 3-fold/3-seed expansion is authorized by the current evidence.

## Execution update - 2026-08-11 - holder-object feature/action v2 gate

The implementation review found three confounds in the first G1/G3 smoke:
current contact was absent from the sparse edge input, the B1 pair MLP did not
receive pair geometry, and G1-to-G3 changed residual/normalization behavior as
well as action routing. Therefore the saved legacy results are retained, but
they are no longer treated as clean single-factor architecture estimates.

The next smoke must use the versioned `holder_object_v2` contract on the same
frozen E0 sample IDs. It uses a compact 17-dimensional node state, a
contact-aware 9-dimensional directed holder-object edge, and a structured
6-by-7 action encoder. Current holding remains excluded from input. Three
matched sparse blocks isolate flat-versus-structured action encoding and
late-versus-pair-conditioned FiLM routing. The feature-parity B1-v2 must also
be rerun before claiming graph message passing adds value.

The detailed feature contract, model IDs, and Colab command are in
`docs/phase3_holder_object_feature_action_v2.md`. C-L, C-E, S-0, and the full
3-fold/3-seed comparison remain after this corrected task-0/seed-0 smoke gate.

## Execution update - 2026-08-11 - metric/checkpoint implementation gate

The code now implements the previously planned actual holding change-event,
onset, release, hard-negative FPR, and PR-AUC metrics. The historical
true-changed-subset future-value score remains available under its legacy
field for compatibility. A holding threshold is selected from validation
correct-action predictions only and then frozen for both test views and every
counterfactual control. Checkpoint selection now prioritizes validation actual
holding change-event F1 instead of global future-relation macro-F1.

P0 parameter accounting was corrected by removing unused node/action encoders.
The parameter-matching report now records actual trainable counts and target
differences. Full multi-fold/multi-seed comparison still requires matched
capacity; the one-fold/one-seed smoke remains an explicitly unmatched
technical gate.

## Execution update - 2026-08-11 - holder-object feature/action v2 smoke result

The corrected task-0/seed-0 v2 smoke completed on the frozen E0 sample IDs.
Sixteen regression tests passed before training. The full result, detailed
analysis, and exact code snapshot are persisted under the Drive
`phase3_holder_action_v1` artifact root.

G1 sparse holder-object GNN ranked first on actual holding change-event F1 at
0.4257 natural and 0.8000 challenge, but its gains over the feature-parity
B1-v2 pair MLP were only +0.0236 and +0.0128. B1-v2 had the best challenge
event AP and lower hard-negative FPR. The structured-action and FiLM models
did not improve the primary metric, and action/channel-shuffle effects were
not consistently positive. Thus the graph advantage is provisional and the
action-use gate remains failed.

No current model advances directly to the full parameter-matched 3-fold x
3-seed comparison. The next gate is an S-0 model trained without action,
followed by C-L/C-E on the same v2 feature contract to finish the topology
factorial. Full expansion requires a paired gain plus stable action-control
degradation across natural and challenge tests.

## Execution update - 2026-08-12 - S-0/C-L/C-E decision

The task-0/seed-0 S-0 and complete-topology follow-up completed. Complete
message graphs retained the exact robot/object nodes and robot-object
prediction targets of the sparse graphs; object-object edges were message-only
context. Normalization was frozen from sparse training records. This makes
S-LS/C-L and S-EF/C-E parameter-identical topology comparisons.

Sparse minus complete actual holding event F1 was +0.0426/+0.2127 for late
action and +0.0684/+0.3014 for FiLM on natural/challenge tests. C-E added only
+0.0047/+0.0162 over C-L, and complete edge shuffling improved performance.
Complete topology and further complete edge conditioning are therefore closed
for expansion at this gate.

G1 also beat both exact action-free G1 controls. Its gain over the same-width
control was +0.1422/+0.1148 and over the parameter-matched control was
+0.1054/+0.1333. However, correct-versus-shuffled action effects remained
small or inconsistent. The result supports retaining the action pathway but
does not support a claim that aligned sample-specific action semantics are
used.

Before a full fold expansion, run a paired three-seed task-0 gate containing
G1, S-0-G1, an equal-parameter learned-constant-action control, and a
train-time shuffled-action control. Sparse topology is retained; C-L/C-E and
additional FiLM complexity are excluded. Phase 4 remains gated.

## Execution update - 2026-08-12 - action-semantics gate and shuffle correction

The task-0 three-seed action gate completed 12 paired runs. Correct-action G1
beat train-time shuffled G1 in all three seeds on both natural and holding
challenge event F1, and beat an exactly parameter-matched constant-action
branch on average. Its advantage over parameter-matched S-0-G1 was positive on
average but reversed in seed 1, so action-pathway necessity is not fully stable.

The historical test shuffle was then found to be structurally weak: its
within-batch roll used a same-episode action donor for 98.35% of natural rows
and 95.81% of challenge rows. A deterministic global bijection now forces
every donor action to come from a different episode while preserving the exact
split marginal. Under this corrected control, G1 holding event PR-AUC dropped
in all three task-0 seeds on both test views. Event F1 dropped in two of three
natural seeds and all three challenge seeds. G1 checkpoints are now persisted
for reproducible counterfactual evaluation.

The evidence provisionally supports sample-specific action use on task 0, but
does not yet establish task-family generalization. The next authorized Phase
3B-R1 step is a reduced parameter-matched 3-fold x 3-seed comparison of
B1-v2, G1-correct, S-0-G1, and G1-train-shuffled. The global episode-disjoint
action control and edge shuffle are mandatory. Phase 4 remains gated until
that cross-fold comparison passes.

## Execution update - 2026-08-12 - reduced cross-fold gate completed

The 3-fold x 3-seed gate completed 36/36 runs with the frozen manifest,
separate natural/challenge evaluation, validation-frozen thresholds, global
episode-disjoint action shuffle, edge shuffle, and per-run checkpoints.

The result does not support a universal GNN advantage. B1-v2 achieved the
highest challenge event F1 (0.7670) and the lowest hard-negative FPR, while
S-0-G1 achieved the highest natural event F1 (0.3604). G1 was competitive
(0.3400 natural, 0.7465 challenge) but its paired event-F1 advantage over
B1-v2 was not stable: +0.0115 natural with only 2/9 positive pairs and
-0.0206 challenge with only 2/9 positive pairs.

Action alignment was strongly useful against train-shuffled action on the
challenge view (+0.2719 event F1, 9/9 positive pairs), but not on natural
test (-0.0070 mean, 4/9 positive). Correct global action shuffle reduced G1
PR-AUC in all natural runs and 7/9 challenge runs. The challenge view is an
event-enriched stress subset selected from the natural held-out episodes, not
an independent dataset. The safe interpretation is therefore only that action
information helps on this stress view; it is not evidence of challenge
generalization, and the benefit is not uniform across the natural distribution.

The nominal parameter matching was close but not exact because the hidden
width search used integer candidates: B1-v2 was +722 parameters and S-0-G1
was -162 relative to G1. This is recorded as a limitation rather than being
treated as exact capacity matching. Phase 4 remains gated. Complete topology,
additional FiLM complexity, and a broad claim of GNN superiority remain
closed. The next step is calibration/hard-negative analysis and, if needed,
an exact-capacity comparison before making a final architectural claim.

## Execution update - 2026-08-12 - corrected protocol seed-0 gate

The legacy gate was audited and a separately versioned corrected protocol was
run. It removes action contamination from the current auxiliary path, uses
natural validation for PR-AUC checkpoint selection and frozen thresholds,
stores calibration and per-sample predictions, names the oracle-current event
metric explicitly, and adds a predicted-current end-to-end event metric.

Across the corrected three-fold/seed-0 screen, G1 beat B1 conditional event
PR-AUC on tasks 1 and 2 but not task 0. The task-macro gain was +0.0626 and its
hierarchical interval included zero. G1 improved release F1 and hard-negative
FPR over B1, but its thresholded event F1 was lower. Most importantly, aligned
G1 did not degrade consistently against train-shuffled G1; train-shuffled G1
had the best task-macro conditional PR-AUC and event F1.

The current late/global-action G1 therefore fails the preregistered three-seed
expansion criterion. Further GNN depth work pauses, and the roadmap moves to a
target-pair temporal encoder with a causal H0--H3 history/action factorial and
only limited DeepSets or pair-set-attention context. This is a change of
architecture hypothesis, not a claim that graphs are generally ineffective.
Phase 4 remains gated until that screen and the pending 90-item weak-label
manual review are complete.
