# Phase 3 holder-object feature/action v2 smoke result

Date: 2026-08-11  
Scope: `test_task0`, seed 0, one unmatched-width smoke run  
Primary metric: actual holding change-event F1  
Threshold policy: fit on validation correct-action output, then freeze for both test splits and every control

## Reproducibility

- Frozen evaluation manifest: `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/phase3B_R1_eval_manifest.json`
- Full result: `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/smoke_test_task0_seed0_feature_v2.json`
- Detailed analysis: `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/smoke_test_task0_seed0_feature_v2_analysis.json`
- Exact code snapshot: `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/code_snapshot_v2`
- QA: A100 GPU, fixed manifest found, and 16 feature/model/metric regression tests passed.
- Split sizes: train 1,200; validation 474; natural test 486; holding challenge 167.

## Primary result

| Model | Parameters | Validation threshold | Natural event F1 | Challenge event F1 | Natural event AP | Challenge event AP |
|---|---:|---:|---:|---:|---:|---:|
| P0 flat MLP | 20,514 | 0.86 | 0.3662 | 0.7400 | 0.3783 | 0.4984 |
| B1-v2 pair-feature MLP | 35,490 | 0.59 | 0.4022 | 0.7872 | 0.4327 | **0.7153** |
| G1 sparse holder-object GNN | 44,946 | 0.59 | **0.4257** | **0.8000** | **0.4426** | 0.5767 |
| Legacy G3 gated action-edge GNN | 54,787 | 0.94 | 0.3980 | 0.7959 | 0.2539 | 0.5226 |
| S-LF-v2 flat late-action GNN | 54,930 | 0.95 | 0.3544 | 0.6957 | 0.4210 | 0.5949 |
| S-LS-v2 structured late-action GNN | 60,235 | 0.65 | 0.3015 | 0.6452 | 0.3703 | 0.4941 |
| S-EF-v2 structured FiLM action-edge GNN | 74,300 | 0.91 | 0.3321 | 0.7500 | 0.3498 | 0.5960 |

G1 is first on actual holding event F1 in both test views, but the margin over
the feature-parity B1-v2 is small: +0.0236 on natural test and +0.0128 on the
challenge test. B1-v2 is better calibrated for hard cases by ranking, with the
highest challenge event AP, and has the lowest hard-negative false-positive
rate (0.0381 natural and 0.0000 challenge). G1's corresponding rates are
0.1048 and 0.0984. Therefore this smoke weakly supports sparse message passing
for thresholded event F1, but does not yet establish a decisive graph advantage.

## Control interpretation

| Model | Natural action-shuffle delta | Challenge action-shuffle delta | Natural edge-shuffle delta | Challenge edge-shuffle delta |
|---|---:|---:|---:|---:|
| P0 | -0.0124 | +0.0242 | 0.0000 | 0.0000 |
| B1-v2 | +0.0066 | +0.0481 | +0.0620 | +0.3110 |
| G1 | -0.0302 | +0.0121 | +0.0300 | +0.1148 |
| Legacy G3 | -0.0209 | +0.0043 | +0.1390 | +0.3635 |
| S-LF-v2 | -0.0473 | -0.0199 | +0.0969 | +0.2790 |
| S-LS-v2 | -0.0078 | +0.0298 | +0.0426 | +0.2127 |
| S-EF-v2 | -0.0237 | +0.0192 | -0.0173 | +0.1466 |

The action-shuffle deltas are small, inconsistent across natural/challenge
views, and often negative. Gripper-only shuffle deltas are also approximately
zero. Structured action encoding and FiLM routing therefore do not pass the
action-use gate in this smoke. Edge shuffling usually causes a larger drop,
especially on the challenge split, so current pair/edge evidence is useful;
however, the B1-v2 edge-feature control also drops, so this is not unique
evidence for graph message passing.

## Decision

Do not expand these models to 3 folds x 3 seeds yet. This is one fold, one
seed, and parameter matching is disabled. The action-conditioned candidates
have more parameters than G1 but lower primary performance, so the negative
action result is not explained by insufficient capacity.

The S-0 and complete-topology follow-up has now been completed. Its results
supersede this proposed next step and are documented in
`docs/phase3_topology_action_followup_result.md`.
