# Phase 3 Corrected Three-Fold Seed-0 Gate Result

Date: 2026-08-12

Decision: stop the GNN three-seed expansion and pivot to a pair-local temporal
encoder. Phase 4 remains gated.

## Scope and protocol

This is the corrected architecture screen for held-out tasks 0, 1, and 2 at
seed 0. It compares B1-v2, G1 late-action, S-0, and G1 trained with matched
shuffled actions. Task 1 was completed in the initial smoke; the follow-up ran
only tasks 0 and 2, then combined the 12 runs. It did not repeat task 1.

Checkpoint selection and future/current threshold selection use natural
validation only. The thresholds are frozen for natural test and the
event-enriched stress subset. The primary outcome is natural-test
conditional/oracle-current holding-event PR-AUC. Challenge is not treated as
an independent test or as challenge generalization.

## Natural-test result

| Task | Model | Conditional PR-AUC | Event F1 | End-to-end PR-AUC | Release F1 | Hard-negative FPR |
|---:|---|---:|---:|---:|---:|---:|
| 0 | B1-v2 | 0.3566 | 0.3396 | 0.2199 | 0.0000 | 0.5524 |
| 0 | G1 | 0.2405 | 0.3309 | 0.1729 | 0.2537 | 0.2190 |
| 0 | S-0 | 0.4796 | 0.2970 | 0.2782 | 0.0513 | 0.4762 |
| 0 | G1 train-shuffled | 0.4719 | 0.3882 | 0.2034 | 0.2946 | 0.1143 |
| 1 | B1-v2 | 0.3710 | 0.4091 | 0.2595 | 0.0000 | 0.4800 |
| 1 | G1 | 0.5032 | 0.3276 | 0.2190 | 0.1047 | 0.2000 |
| 1 | S-0 | 0.4241 | 0.3897 | 0.1296 | 0.0000 | 0.4700 |
| 1 | G1 train-shuffled | 0.4994 | 0.4211 | 0.2351 | 0.2360 | 0.1500 |
| 2 | B1-v2 | 0.4100 | 0.4762 | 0.2576 | 0.0000 | 0.4615 |
| 2 | G1 | 0.5817 | 0.3229 | 0.3751 | 0.1293 | 0.0769 |
| 2 | S-0 | 0.5075 | 0.3039 | 0.3053 | 0.1197 | 0.2308 |
| 2 | G1 train-shuffled | 0.5244 | 0.4908 | 0.0627 | 0.0000 | 0.4519 |

Task-macro means were:

| Model | Conditional PR-AUC | Event F1 | End-to-end PR-AUC | End-to-end F1 | Release F1 | Hard-negative FPR |
|---|---:|---:|---:|---:|---:|---:|
| B1-v2 | 0.3792 | 0.4083 | 0.2456 | 0.0721 | 0.0000 | 0.4980 |
| G1 | 0.4418 | 0.3272 | 0.2557 | 0.2278 | 0.1626 | 0.1653 |
| S-0 | 0.4704 | 0.3302 | 0.2377 | 0.1515 | 0.0570 | 0.3923 |
| G1 train-shuffled | 0.4985 | 0.4333 | 0.1671 | 0.0994 | 0.1769 | 0.2387 |

The thresholds selected on natural validation differ substantially across
models and tasks, with G1 commonly selecting 0.91--0.95. This is why PR-AUC
is primary and thresholded F1 remains secondary. Brier score and ECE are
stored in the aggregate result and every run artifact.

## Paired hierarchical bootstrap

The analysis resamples task fold, episode, and event cluster. With only one
seed per task, these intervals quantify held-out episode/event uncertainty,
not seed uncertainty or broad task-family generalization.

| Pair and metric | Estimate | 95% interval |
|---|---:|---:|
| G1 - B1 conditional PR-AUC | +0.0626 | [-0.0892, +0.1905] |
| G1 - B1 event F1 | -0.0811 | [-0.2017, +0.0294] |
| G1 - B1 release F1 | +0.1626 | [+0.0701, +0.2967] |
| G1 - B1 hard-negative FPR | -0.3326 | [-0.4201, -0.2429] |
| G1 - shuffled conditional PR-AUC | -0.0567 | [-0.1943, +0.0572] |
| G1 - shuffled event F1 | -0.1062 | [-0.2001, -0.0379] |
| G1 - shuffled release F1 | -0.0143 | [-0.1476, +0.1320] |
| G1 - shuffled hard-negative FPR | -0.0734 | [-0.3624, +0.1162] |

## Gate decision

- G1 beats B1 PR-AUC on at least two tasks: pass (tasks 1 and 2).
- G1 avoids severe hard-negative FPR degradation: pass; it improves all
  three tasks.
- G1 improves release behavior: pass; it improves all three tasks over B1.
- Aligned G1 degrades consistently under train-time action shuffle: fail.

The primary gain is task-dependent and its interval includes zero. G1's
thresholded F1 is worse than B1, and train-shuffled G1 is stronger on the
task-macro conditional metrics. The current architecture therefore does not
justify nine more GNN runs. Further GNN depth/message-passing development is
paused.

The next architecture is target-pair temporal: independently encode each
robot-object pair, add only causal history from frames at or before time t,
and combine limited context through DeepSets or pair-set attention. The H0--H3
history/action factorial will separate missing temporal state from action
conditioning.

## Reproducibility artifacts

Persistent root:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/corrected_protocol_v2`

Combined result directory: `threefold_seed0_combined`

- `phase3_corrected_threefold_seed0_combined_v2.json`
- `phase3_corrected_threefold_seed0_gate_decision_v2.json`
- `bootstrap_g1_vs_b1.json`
- `bootstrap_g1_vs_train_shuffled.json`

The run directories also retain versioned configs, code snapshots,
checkpoints, runtime manifests, and per-sample gzip prediction files. The
legacy 36-run result remains unchanged.
