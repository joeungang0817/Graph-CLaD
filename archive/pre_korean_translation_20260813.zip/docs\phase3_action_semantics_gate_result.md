# Phase 3 action-semantics gate result

Date: 2026-08-12  
Phase: Phase 3B-R1  
Scope: held-out `test_task0`, seeds 0/1/2  
Primary metric: actual holding change-event F1

## Reproducibility

All Drive paths below are under
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1`.

- Frozen sample manifest: `phase3B_R1_eval_manifest.json`
- Four-condition 12-run report: `phase3_action_semantics_gate_task0_3seed_v1.json`
- Corrected global-shuffle 3-run report:
  `phase3_global_action_shuffle_control_task0_3seed_v1.json`
- Combined decision artifact:
  `phase3_action_semantics_gate_task0_3seed_v2_analysis.json`
- G1 checkpoints: `checkpoints_global_action_shuffle_v1`
- Exact code snapshot: `code_snapshot_action_gate_v1`
- Colab QA: 25 tests passed after Python compilation.

The frozen natural/challenge sample IDs, train-only normalization,
validation-selected holding threshold, sparse holder-object topology, loss,
optimizer, and checkpoint rule were shared across conditions. Checkpoints and
partial JSON results were written to Drive after every completed run.

## Compared controls

| ID | Condition | Hidden | Parameters | Isolated question |
|---|---|---:|---:|---|
| G1-correct | G1 with aligned sample action | 48 | 44,946 | Full current candidate |
| S-0-G1 | Exact G1-style block without action | 54 | 44,784 | Is the action pathway needed? |
| G1-constant | G1 action branch receives one fixed template | 48 | 44,946 | Is extra branch capacity enough? |
| G1-train-shuffled | G1 trained with randomly mismatched batch actions | 48 | 44,946 | Is scene-action alignment needed in training? |

`G1-constant` has exactly the same architecture and parameter count as G1.
It preserves a learnable action branch but removes all sample-specific action
information. `G1-train-shuffled` preserves the exact action marginal in every
training batch while cyclically shifting every scene-action pair.

## Three-seed aggregate

| Model | Natural event F1 | Challenge event F1 | Natural event AP | Challenge event AP | Natural hard-neg FPR | Challenge hard-neg FPR |
|---|---:|---:|---:|---:|---:|---:|
| G1-correct | **0.3965** | **0.7162** | 0.3720 | 0.5144 | 0.2476 | 0.1858 |
| S-0-G1 | 0.3192 | 0.6565 | **0.3761** | **0.5805** | **0.1714** | **0.1585** |
| G1-constant | 0.3452 | 0.6261 | 0.3413 | 0.5444 | 0.2603 | 0.1967 |
| G1-train-shuffled | 0.3207 | 0.5164 | 0.2767 | 0.4959 | 0.2762 | 0.1967 |

G1 has the best thresholded event F1 on average. S-0 still has slightly better
PR-AUC and lower hard-negative FPR, so the action pathway is not uniformly
better on every holding metric.

## Paired training-control differences

Values are `G1-correct minus control` holding change-event F1.

| Control | Natural mean | Natural seed differences | Challenge mean | Challenge seed differences |
|---|---:|---|---:|---|
| S-0-G1 | +0.0773 | +0.1054, -0.0027, +0.1291 | +0.0597 | +0.1333, -0.1436, +0.1895 |
| G1-constant | +0.0513 | +0.1120, +0.0629, -0.0209 | +0.0901 | +0.1962, +0.0434, +0.0308 |
| G1-train-shuffled | **+0.0758** | +0.0474, +0.0596, +0.1205 | **+0.1998** | +0.2717, +0.0385, +0.2894 |

Aligned-action training beats shuffled-action training in all three seeds on
both test views. Capacity alone is unlikely to explain the full gain because
G1 also beats its exactly parameter-matched constant-input branch on all three
challenge seeds and two of three natural seeds. The G1-versus-S-0 comparison
is less stable: seed 1 reverses on both views.

## Why the historical test shuffle was replaced

The legacy `shuffled_action` control rolls action by one row inside each
evaluation batch. Fixed-manifest rows are strongly episode-local, so this
mostly assigns a neighboring action from the same demonstration.

| Split | Legacy action L2 | Legacy same-episode donor | Global action L2 | Global same-episode donor |
|---|---:|---:|---:|---:|
| Natural | 0.6835 | 98.35% | 4.0506 | 0% |
| Challenge | 0.9284 | 95.81% | 2.6823 | 0% |

The corrected `global_shuffled_action` is a deterministic bijection over the
whole split. It preserves the exact action distribution and guarantees that
every donor comes from a different episode. The legacy result remains in old
reports for compatibility but is not treated as a strong semantic control.

## Corrected inference-control result

Values are `correct action minus global episode-disjoint shuffle`.

| Metric | Natural mean | Natural seed support | Challenge mean | Challenge seed support |
|---|---:|---:|---:|---:|
| Holding event F1 | +0.0729 | 2/3 positive | +0.1206 | 3/3 positive |
| Holding event PR-AUC | **+0.0718** | **3/3 positive** | **+0.0831** | **3/3 positive** |
| Onset F1 | +0.1590 | 2/3 positive | +0.0724 | 2/3 positive |
| Release F1 | -0.0053 | 1/3 positive | +0.1713 | 3/3 positive |

Additional G1 controls are also consistent with a useful pathway:

- normalized no-action event-F1 drop: +0.0896 natural and +0.1505 challenge,
  positive in all three seeds;
- shuffled-edge event-F1 drop: +0.0754 natural and +0.1678 challenge,
  positive in all three seeds.

The PR-AUC result is the strongest action-semantic evidence because it does
not depend on the validation-selected threshold. Correct action ranks holding
events better than the global shuffle in every seed on both test views.

## Decision and claim boundary

- Retain sparse holder-object topology.
- Keep complete topology and extra FiLM complexity closed for expansion.
- Treat aligned action training as supported on task 0 across three seeds.
- Treat sample-specific inference-time action use as provisionally supported:
  challenge F1 and both PR-AUC views pass consistently, but natural event F1,
  natural release, and hard-negative behavior are not fully stable.
- Do not claim task-family generalization yet; only task 0 has three-seed
  evidence.
- Phase 4 remains gated.

The next experiment is a reduced parameter-matched `3 folds x 3 seeds`
comparison containing B1-v2, G1-correct, S-0-G1, and G1-train-shuffled. It
must retain the global episode-disjoint action control, edge shuffle, natural
and challenge test separation, validation-frozen thresholds, and per-run
checkpoint persistence.
