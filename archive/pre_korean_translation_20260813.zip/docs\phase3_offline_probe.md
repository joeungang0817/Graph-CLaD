# Phase 3 Offline Relational-Dynamics Probe

> **2026-08-07 successor note:** This file remains the historical probe record.
> The current official-demo holding challenge summaries are
> `data/phase3_holding_target_v2_summary.json` and
> `data/phase3_holding_target_balanced_v3_summary.json`. Claim limits and the
> next graph design are documented in `docs/research_risk_review_20260807.md`
> and `docs/phase3_holder_object_action_graph_design.md`.

> **2026-08-06 재판정:** 아래 수치는 scripted/bounded-probe dataset에서 얻은
> historical diagnostic 결과이며 Phase 4 진입 근거로 사용하지 않는다. 현재 코드의
> `changed_relation`은 실제 change-event classifier F1이 아니라, 실제로 변한 위치에서
> 계산한 future relation value F1이다. 또한 complete empty-edge graph에서는 기존
> shuffled sender/receiver control을 correct-edge causality의 최종 증거로 해석할 수 없다.
> 수정된 data, metric, control은 `docs/revised_research_roadmap_v3.md`를 따른다.

> **2026-08-11 metric revision:** The current code preserves the historical
> `changed_relation` field but now reports a separate holding block with actual
> change-event, onset, release, future-state, hard-negative FPR, and PR-AUC.
> Holding threshold and checkpoint selection are fitted on validation
> correct-action outputs only. P0 no longer creates unused node/action encoders,
> so parameter matching uses actual trainable model capacity.

## Purpose

This phase tests whether relational structure improves action-conditioned
future relation prediction before integrating anything into the original CLaD
latent-dynamics path. The input is the validated Phase 2R oracle graph dataset;
the experiment is not an RGB perception experiment.

## Protocol

- Dataset: `phase2r.v2-robot-base`, `include_all_sites`, `tau=6`.
- Input: current node features, current geometry edge features, and the
  six-action window.
- Target: future directed relation labels for `left`, `right`, `front`,
  `behind`, `above`, `below`, `contact`, `on`, `inside`, and `holding`.
- Auxiliary target: current relation labels with weight 0.25.
- Unknown labels are masked, not treated as false.
- Normalization is fitted on train samples only.
- Split is episode-disjoint and inherited from the Phase 2R manifest:
  532 train samples, 19 validation samples, 19 test samples.
- Three seeds were run for every model on a CUDA Colab runtime.

## Models

| ID | Structure |
|---|---|
| P0 | flattened node-set MLP with edge geometry at the edge head |
| P1 | independent node encoder, no message passing |
| P2 | fully connected GNN with empty edge input |
| P3 | GNN with geometry edge input |
| P4 | GNN with geometry edge input and learned soft edge attention |

Controls are evaluated without retraining: zero action, batch-shuffled action,
and shuffled sender/receiver indices.

## Result

The exact summary is stored in
`data/phase3_offline_probe_summary.json`; the full live report is stored in
the Colab runtime at
`/content/Graph-CLaD-phase2r-scaleup-r3/data/phase3_offline_probe_report.json`.

The primary provisional result is changed-relation macro-F1:

| Model | Mean F1 | Std | Parameters |
|---|---:|---:|---:|
| P0 flat MLP | 0.2640 | 0.0330 | 92,244 |
| P1 node-only | 0.7873 | 0.0811 | 43,988 |
| P2 empty-edge GNN | **0.8576** | 0.0496 | 60,692 |
| P3 geometry-edge GNN | 0.8506 | 0.0305 | 78,036 |
| P4 soft-attention GNN | 0.7896 | 0.0699 | 86,677 |

P2 is the best provisional model on this split. P3 and P4 degrade strongly
under shuffled-edge control, which is evidence that edge assignment is used.
However, P3 does not beat P2, so geometry-edge superiority is not established.

## Scope limits

The inherited test split contains only
`libero_spatial:task9:init1:seed0`. Its changed-relation support is mainly
`above`, `below`, and `on`; `inside` and `holding` have no test support. The
result therefore supports a relational-dynamics signal on this controlled
spatial split, not a broad claim about all semantic relations.

The models are also not exactly parameter matched. The next required Phase 3
iteration is a relation-critical, task-family-held-out split with matched
capacity. P5 history modeling is deferred until the capture stores past graph
sequences.

## Task-family-held-out matched revalidation

The follow-up run used the final 570-sample dataset with task-family isolation:
380 train, 76 validation, and 114 test samples. Validation used
`libero_90:1` and `libero_spatial:8`; test used `libero_90:2`,
`libero_goal:0`, and `libero_object:0`. All five models were run with three
seeds and widths selected near a 70,000-parameter target.

Changed-relation macro-F1 mean/std on the held-out test set was:

| Model | Future macro-F1 | Changed macro-F1 | Inside F1 |
|---|---:|---:|---:|
| P0 flat MLP | 0.6585 ± 0.0124 | 0.1394 ± 0.0299 | 0.2309 ± 0.1075 |
| P1 node-only | 0.6081 ± 0.0010 | 0.1289 ± 0.0169 | 0.1181 ± 0.0249 |
| P2 empty-edge GNN | 0.5819 ± 0.0083 | **0.2223 ± 0.0676** | 0.0623 ± 0.0881 |
| P3 geometry GNN | 0.6229 ± 0.0099 | **0.2222 ± 0.0361** | 0.2018 ± 0.0392 |
| P4 soft-attention GNN | 0.6070 ± 0.0154 | 0.1998 ± 0.0425 | 0.0791 ± 0.1119 |

P2/P3 therefore retain a changed-relation advantage over P0, but the Phase 3
gate remains open. Correct-action scores were not consistently better than
no-action or shuffled-action controls, and shuffled-edge scores were not
consistently lower. These controls do not yet establish action-conditioned
foresight or causal use of the graph edge assignment.

The intended holding check exposed a collection/labeling gap. The graph schema
already contains a `robot0` node; the zero `holding=true` labels were caused by
the collector recognizing only `robot0*` body names while the MuJoCo runtime
reports gripper bodies as `gripper0_*`, together with a gripper-closure
threshold that was too strict for an object held between the fingers. The
collector now maps `gripper0_*` contacts to logical `robot0`, uses a calibrated
`|qpos| <= 0.025` threshold, and supports a scripted approach-close-lift
holding probe. A pilot produced 10 positive holding labels and 10 holding
transitions. The six-episode spatial scale-up produced 34 holding transitions,
but positives occurred only for task 0 and task 1; task 2 had contact without a
positive holding label. Holding coverage is therefore improved but not yet
complete for a task-family-held-out evaluation.

An additional task-2-only probe used 96 steps and doubled the close phase from
16 to 32 steps, but still produced zero holding transitions. This indicates a
task-specific approach/grasp alignment problem rather than evidence that the
closure threshold should be lowered further.

The exact results and gates are recorded in
`data/phase3_taskheldout_matched_summary.json` and the follow-up collection
audit is stored in `data/phase2r_holding_probe_summary.json`. Phase 4 adapter
integration is blocked until the matched Phase 3 split is rebuilt with
holding-positive support across the intended held-out families, meaningful
action controls, and a stable shuffled-edge effect.
