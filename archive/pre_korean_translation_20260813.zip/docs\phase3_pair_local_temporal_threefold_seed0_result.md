# Phase 3 Pair-Local Temporal Three-Fold Seed-0 Result

Date: 2026-08-13  
Protocol: `phase3-pair-local-temporal-threefold-seed0-v1`  
Runs: 12/12 (`3 task folds x 1 seed x H0--H3`)  
Result SHA256: `492d45521e6ccecbc4f0d89923f50d49642962d60c1c53daf093b5aec9b4d188`

## Scope

This is a one-seed architecture screen. Task folds, not the twelve trained
models, are the outer evaluation units. Natural test is primary; challenge is
only a future-event-selected stress view. Event PR-AUC/F1 below is conditional
on oracle current holding. The end-to-end metric and per-sample predictions
remain stored in the result artifacts.

H0--H3 use independent robot-object pair encoding and causal history from
frames at or before current time only. All use the common action-free current
head, natural-validation PR-AUC checkpoint selection, and a threshold selected
on natural validation and frozen for test/stress/controls.

## Natural test by held-out task

| Task | Model | Event PR-AUC | Event F1 | Release F1 | Hard-negative FPR | Threshold |
|---|---|---:|---:|---:|---:|---:|
| 0 | H0 state | 0.2373 | 0.2881 | 0.2016 | 0.1429 | 0.94 |
| 0 | H1 history | 0.3998 | 0.3846 | 0.0645 | 0.4286 | 0.93 |
| 0 | H2 action | 0.1826 | 0.2934 | 0.2286 | 0.4381 | 0.95 |
| 0 | H3 history+action | **0.4009** | **0.4074** | **0.2353** | 0.4762 | 0.87 |
| 1 | H0 state | 0.3810 | 0.3671 | 0.0000 | 0.5000 | 0.95 |
| 1 | H1 history | 0.4960 | **0.5352** | 0.0000 | 0.3000 | 0.95 |
| 1 | H2 action | **0.5869** | 0.4184 | **0.2143** | **0.0900** | 0.90 |
| 1 | H3 history+action | 0.5731 | 0.3357 | 0.1075 | 0.1100 | 0.85 |
| 2 | H0 state | 0.4695 | 0.2849 | **0.0777** | 0.3077 | 0.94 |
| 2 | H1 history | 0.4086 | **0.5563** | 0.0000 | 0.2788 | 0.95 |
| 2 | H2 action | 0.4129 | 0.2440 | 0.0759 | 0.1442 | 0.95 |
| 2 | H3 history+action | **0.4734** | 0.3419 | 0.0150 | **0.1154** | 0.94 |

## Task-macro means

| Model | Event PR-AUC | Event F1 | Release F1 | Hard-negative FPR |
|---|---:|---:|---:|---:|
| H0 state | 0.3626 | 0.3134 | 0.0931 | 0.3168 |
| H1 history | 0.4348 | **0.4920** | 0.0215 | 0.3358 |
| H2 action | 0.3941 | 0.3186 | **0.1729** | **0.2241** |
| H3 history+action | **0.4824** | 0.3617 | 0.1193 | 0.2339 |

## Predeclared factorial contrasts

| Contrast | PR-AUC mean | Tasks with positive PR-AUC | Event F1 | Release F1 | Hard-negative FPR |
|---|---:|---:|---:|---:|---:|
| H1-H0: history without action | +0.0722 | 2/3 | +0.1786 | -0.0716 | +0.0190 |
| H2-H0: action without history | +0.0315 | 1/3 | +0.0052 | +0.0798 | -0.0927 |
| H3-H1: action with history | +0.0476 | **3/3** | -0.1304 | **+0.0978** | **-0.1019** |
| H3-H2: history with action | +0.0883 | 2/3 | +0.0430 | -0.0536 | +0.0097 |
| H3-H0: joint contribution | +0.1198 | **3/3** | +0.0483 | +0.0262 | -0.0830 |

For H3-H1, release F1 also rose on all three tasks. Hard-negative FPR improved
on tasks 1 and 2 and worsened by 0.0476 on task 0, producing the favorable
task-macro difference. In contrast, H3 versus H0 had a large task-0
hard-negative deterioration despite its favorable macro mean. Thresholded F1
is secondary and several selected thresholds are high (0.85--0.95).

## Gate decision

H3 remains the only expansion candidate because adding action to the causal
history model improved the primary PR-AUC and release F1 on all three held-out
tasks while improving mean hard-negative FPR. H1, H2, and the isolated
H3-minus-H2 history increment do not independently satisfy all gates.

Do not start the full three-seed factorial yet. First run a three-fold,
seed-0 `H3-train-shuffled` alignment control using the existing
episode-disjoint matched donor sampler. If aligned H3 does not beat this
control on natural PR-AUC in at least two tasks, or release/hard-negative
behavior becomes unsafe, stop expansion. If it passes, add seeds 1 and 2 only
for H3, its H1 no-action comparator, and the shuffled-action control. This
screen does not establish the final CLaD representation claim, and the weak
labels remain heuristic rather than human ground truth.

Persistent result root:
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/corrected_protocol_v2/pair_local_temporal_threefold_seed0_v1`
