# Phase 3B-R1 reduced cross-fold gate result

Date: 2026-08-12  
Scope: frozen Phase 3B-R1 manifest, held-out task folds `test_task0`,
`test_task1`, and `test_task2`, seeds 0/1/2  
Primary metrics: actual holding change-event F1, holding event PR-AUC, and
hard-negative false-positive rate

The holding-challenge rows are an event-enriched stress subset of the natural
held-out episodes rather than an independent test dataset. All challenge
values below must be read as stress analysis, not as a second generalization
result. The legacy holding event also conditions on ground-truth current
holding; the corrected v2 protocol names this oracle-current condition
explicitly and adds an end-to-end predicted-current event metric.

## Reproducibility

All Drive paths below are under
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1`.

- Frozen manifest: `phase3B_R1_eval_manifest.json`
- Result: `phase3_reduced_crossfold_gate_v1.json`
- Checkpoints: `checkpoints_reduced_crossfold_v1` (36 files)
- Code snapshot: `code_snapshot_reduced_crossfold_v1`
- Expected/completed runs: 36/36
- Natural and holding-challenge test views were evaluated separately.
- Validation-fitted holding thresholds were frozen for test and controls.
- The same selected sample IDs were used across paired model/control runs.

## Models

| ID | Condition | Hidden | Parameters | Difference from G1 |
|---|---|---:|---:|---:|
| B1-v2 | target-pair feature MLP | 55 | 45,668 | +722 |
| G1-correct | sparse holder-object GNN with aligned action | 48 | 44,946 | 0 |
| S-0-G1 | sparse holder-object GNN without action | 54 | 44,784 | -162 |
| G1-train-shuffled | G1 trained with batch-shuffled actions | 48 | 44,946 | 0 |

The run is therefore near-parameter-matched rather than exactly matched for
B1-v2 and S-0-G1. The differences are small relative to the model size, but
this must be stated as a limitation of the gate.

## Nine-run aggregate

| Model | Natural event F1 | Challenge event F1 | Natural PR-AUC | Challenge PR-AUC | Natural hard-neg FPR | Challenge hard-neg FPR |
|---|---:|---:|---:|---:|---:|---:|
| B1-v2 | 0.3285 | **0.7670** | **0.4047** | 0.4898 | **0.1075** | **0.1017** |
| G1-correct | 0.3400 | 0.7465 | 0.3872 | 0.4972 | 0.2146 | 0.1884 |
| S-0-G1 | **0.3604** | 0.5927 | 0.3691 | **0.5159** | 0.2836 | 0.2613 |
| G1-train-shuffled | 0.3470 | 0.4746 | 0.2793 | 0.4093 | 0.3277 | 0.2931 |

No model dominates all metrics. B1-v2 is strongest on challenge thresholded
event F1 and hard-negative FPR. S-0-G1 is strongest on natural event F1 and
challenge PR-AUC, but has the highest false-positive rate among the useful
models. G1 is competitive but does not establish a consistent graph advantage
over B1-v2.

## Paired interpretation

Values below are same-fold/same-seed `G1-correct minus control` event F1.

| Comparison | Natural mean (positive pairs) | Challenge mean (positive pairs) |
|---|---:|---:|
| G1 minus B1-v2 | +0.0115 (2/9) | -0.0206 (2/9) |
| G1 minus S-0-G1 | -0.0204 (4/9) | +0.1538 (8/9) |
| G1 minus G1-train-shuffled | -0.0070 (4/9) | +0.2719 (9/9) |

The graph does not consistently beat the target-pair MLP. The action-enabled
G1 is substantially better than action-free and train-shuffled controls on
the challenge view, but this advantage is absent or slightly negative on the
natural view. This indicates a split-dependent benefit rather than a uniform
improvement.

## Action-control interpretation

For the corrected global episode-disjoint action shuffle, G1 event PR-AUC
decreased by 0.1303 on natural test in all 9 runs and by 0.0341 on challenge
test in 7/9 runs. S-0-G1 was exactly action-invariant, as required.

The train-shuffled control is more severe: its challenge event F1 is lower
than aligned G1 by 0.2719 on average in all 9 paired runs. On natural test the
mean difference is -0.0070 and only 4/9 pairs favor aligned G1. Thus the
strongest evidence for action alignment is on the challenge view, not on the
natural view.

## Decision

1. Retain sparse holder-object topology as the preferred graph topology.
2. Do not claim that GNN message passing is uniformly better than the
   target-pair MLP; B1-v2 is the safer natural/challenge baseline for several
   metrics.
3. Retain the action pathway as a challenge-oriented hypothesis. Its benefit
   is supported against train-shuffled action and global action shuffle, but
   not consistently across natural test.
4. Keep Phase 4 gated. The current evidence is not sufficient for a broad
   claim of task-family generalization or universal action-conditioned graph
   superiority.
5. Before a final paper-grade capacity claim, either use an exact parameter
   matching construction or report this near-matched limitation explicitly.

The next research step should focus on calibration and hard-negative control
for B1-v2/G1, followed by an exact-capacity rerun only if the parameter
matching is required for the final claim. Complete-topology C-L/C-E and extra
FiLM complexity remain closed based on the earlier topology follow-up.
