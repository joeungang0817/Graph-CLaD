# Phase 3 topology/action follow-up result

Date: 2026-08-12  
Scope: `test_task0`, seed 0 smoke  
Primary metric: actual holding change-event F1

## Reproducibility

- Frozen manifest: `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/phase3B_R1_eval_manifest.json`
- S-0/C-L/C-E result: `smoke_test_task0_seed0_topology_action_followup_v2.json`
- Parameter-matched v2-block S-0: `smoke_test_task0_seed0_s0_parammatched_v2.json`
- Parameter-matched G1 action-free control: `smoke_test_task0_seed0_s0_g1_parammatched_v2.json`
- Same-width G1 action-free control: `smoke_test_task0_seed0_s0_g1_hidden48_v2.json`
- Final decision artifact: `phase3_topology_action_decision_task0_seed0_v3.json`
- Exact code snapshot: `code_snapshot_v2_followup`
- QA: 22 feature, topology-mask, action-invariance, model, metric, threshold, checkpoint, and parameter-accounting tests passed on the Colab A100 runtime.

All paths above are under
`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1`.

## Controlled topology contract

C-L and C-E use the same robot/object nodes as their sparse counterparts.
Object-object edges are added only for message passing. Loss, validation
threshold fitting, and evaluation remain restricted to the same directed
robot-object prediction edges. Sparse-train normalization is reused for the
complete models. Thus the paired sparse/complete models have identical
parameters, prediction targets, sample IDs, and normalization; only message
topology changes.

## Primary results

| Model | Hidden | Parameters | Natural event F1 | Challenge event F1 | Natural AP | Challenge AP |
|---|---:|---:|---:|---:|---:|---:|
| G1 sparse + late action | 48 | 44,946 | **0.4257** | **0.8000** | **0.4426** | 0.5767 |
| S-0-G1 same width | 48 | 35,778 | 0.2835 | 0.6852 | 0.2719 | **0.6770** |
| S-0-G1 parameter matched | 54 | 44,784 | 0.3204 | 0.6667 | 0.4225 | 0.6632 |
| S-0 v2 block parameter matched | 55 | 59,363 | 0.3022 | 0.6239 | 0.3037 | 0.4538 |
| S-LS sparse structured late | 48 | 60,235 | 0.3015 | 0.6452 | 0.3703 | 0.4941 |
| C-L complete structured late | 48 | 60,235 | 0.2589 | 0.4324 | 0.1320 | 0.4076 |
| S-EF sparse structured FiLM | 48 | 74,300 | 0.3321 | 0.7500 | 0.3498 | 0.5960 |
| C-E complete structured FiLM | 48 | 74,300 | 0.2636 | 0.4486 | 0.1230 | 0.5014 |

## Topology decision

The parameter-identical paired event-F1 differences are:

| Comparison | Natural | Challenge |
|---|---:|---:|
| S-LS minus C-L | +0.0426 | +0.2127 |
| S-EF minus C-E | +0.0684 | +0.3014 |
| C-E minus C-L | +0.0047 | +0.0162 |

Sparse topology wins for both late-action and edge-FiLM routing in both test
views. Edge conditioning adds almost nothing within the complete graph.
Complete-model edge-shuffle deltas are strongly negative, meaning corrupting
the complete edge assignment improves rather than hurts event F1. The added
object-object message context is therefore harmful/noisy in this smoke, not a
useful source of relational evidence. C-L and C-E should not be expanded.

## Action decision

Removing the action pathway from the exact G1-style architecture reduces F1
under both controls:

| Comparison | Natural G1 gain | Challenge G1 gain |
|---|---:|---:|
| G1 minus same-width S-0-G1 | +0.1422 | +0.1148 |
| G1 minus parameter-matched S-0-G1 | +0.1054 | +0.1333 |

This shows that the action pathway's presence helps the task-0/seed-0 training
outcome. It does not show that the model uses the correct sample-specific
action. G1 loses 0.1668/0.3676 under normalized-zero or physical-zero action,
but correct versus shuffled-action deltas are -0.0302/+0.0121 and arm,
gripper, and reversed-window controls are also small or inconsistent.

The appropriate interpretation is therefore:

- action-pathway presence: helpful in this single smoke;
- action-semantic conditioning: not demonstrated;
- possible explanation: extra optimization pathway, action-distribution bias,
  or a coarse nonzero-action cue rather than aligned action-object reasoning.

The next action gate should compare correct-action G1 against an
equal-parameter learned-constant-action model and a model trained with actions
shuffled across samples. Run this as a paired three-seed task-0 screen before
any action-conditioning claim or full 3-fold x 3-seed expansion.

## Superseding action-gate result - 2026-08-12

The requested three-seed gate is complete. G1-correct beat the train-time
shuffled-action control in all three task-0 seeds on both natural and challenge
event F1. The first test-time shuffle was then found to be too weak because
95.8--98.4% of donors came from the same episode. Under a corrected global
episode-disjoint shuffle, holding event PR-AUC dropped in all three seeds on
both test views; event F1 dropped in two of three natural seeds and all three
challenge seeds. Action use is therefore provisionally supported on task 0,
but full task-family generalization remains untested. The authoritative result
is `docs/phase3_action_semantics_gate_result.md`.

## Current decision

Retain sparse holder-object topology. Reject complete topology and additional
FiLM complexity for expansion. Keep G1 as the current thresholded event-F1
candidate and B1-v2 as an important pair-only/AP and hard-negative baseline.
Treat action as an unresolved mechanism, not as a demonstrated causal signal.
All conclusions remain limited to one held-out task fold and one seed.
