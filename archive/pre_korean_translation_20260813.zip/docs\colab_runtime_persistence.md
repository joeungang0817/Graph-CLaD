# Colab runtime persistence policy

## Persistent root

All Phase 2D source inputs and reproducibility metadata are stored outside the
ephemeral Colab runtime at:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d`

The corresponding local project materials are kept in this repository under
`docs/`, `scripts/`, and `configs/`.

## What is preserved

- `libero_spatial_hdf5/`: the three scoped official HDF5 inputs for tasks 0, 1,
  and 2;
- `data/phase2d_demo_split_manifest.json`: the fixed 150-demo split manifest;
- `project/`: the restored Phase 2D project scripts and configuration;
- `artifact_manifest.json`: sizes and SHA256 checksums for the persisted input
  artifacts;
- `runtime/`: the restore instructions and status record.

Generated graph JSONL and relation-audit outputs must be copied to this same
Drive root immediately after each successful run. They must never exist only
under `/content`.

## Restore rule after a runtime reset

1. Mount Google Drive.
2. Read `artifact_manifest.json` and verify the HDF5 checksums.
3. Copy or link `project/`, `data/`, and `libero_spatial_hdf5/` into the new
   runtime workspace.
4. Reinstall/import the pinned runtime dependencies and run a short preflight.
5. Resume generation or auditing from the persistent inputs.
6. After each task completes, copy its compressed dataset and QA JSON to Drive;
   then write a completion marker and checksum.

The notebook itself is a Google Drive notebook, but notebook history is not
treated as a dataset backup. The Drive artifact bundle is the authoritative
source for reruns.

## Recovery code

The Colab-only backup and restore cells are now preserved locally as
`scripts/phase2d/persistence.py`. It writes a SHA256 manifest, verifies it
before restore, and overlays files without deleting unrelated runtime state.
The robosuite/MuJoCo preflight patch is separately isolated in
`scripts/phase1/runtime_compat.py`; dry-run is the default.

## Clean-runtime compatibility record (2026-08-06)

The working Colab preflight uses `robosuite==1.4.1` with MuJoCo 3.11.0. The
old robosuite package is required for LIBERO's import paths, while a small
runtime-only patch adapts its mass-matrix call to MuJoCo 3's API. This patch
must be reapplied after every runtime reset; it is not a modification to the
research model or to the source HDF5 data.

The reset sequence is therefore: mount Drive, restore the persistent bundle,
install the pinned robosuite version, apply the compatibility patch, import
LIBERO, and pass the one-demo state-replay/graph preflight. Full graph files
are considered durable only after they are copied to this Drive root and a
manifest/checksum marker is written.

## Current durable Phase 2D release (2026-08-06)

The corrected full-demo release is stored at:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_full_demo_v2_splitfixed_stream1`

Its manifest is:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/phase2d_full_demo_splitfixed_stream1_manifest.json`

The release covers 150 official demonstrations from task 0/1/2. Final QA
confirmed zero null split records, zero split mismatches, exact state replay,
and no recorded task errors. The earlier `phase2d_full_demo_v2` directory is
an intermediate pre-split-repair artifact and must not be used as the final
training input.

## Durable Phase 3 controlled-run bundle (2026-08-07)

The controlled task-family experiment is persisted under:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3`

Important files are:

- `phase3_controlled_taskfamily_report.json`: all three folds, all 45
  model/seed runs, controls, and relation-wise metrics;
- `phase3_controlled_taskfamily_config.json`: fold assignments and training
  configuration;
- `phase3_controlled_taskfamily_summary.json`: compact completion summary;
- `phase3_controlled_taskfamily_checkpoint.json`: latest fold checkpoint;
- `code/offline_probe.py`: the patched probe used by the run;
- `code/run_controlled_taskfamily.py`: reusable runner for a fresh runtime.

After a runtime reset, mount Drive, copy the two files under `phase3/code`
into the new runtime, and run the durable runner with:

```python
!python /content/phase3_code/run_controlled_taskfamily.py \
  --dataset-root /content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_full_demo_v2_inputclean_stream1 \
  --output-root /content/drive/MyDrive/Graph-CLaD/artifacts/phase3
```

The runner is deterministic in family selection and writes a checkpoint after
each fold. It does not require the old notebook variables (`probe`, `report`,
or the exploratory smoke cells) to exist.

## Holding target artifacts (2026-08-07)

The current official-demo holding challenge artifacts are separate from the
original Phase 3 root:

- target-aligned dataset:
  `/content/drive/MyDrive/Graph-CLaD/artifacts/phase2d/data/phase2d_holding_target_v2_inputclean_stream1`;
- episode-cap controlled result:
  `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holding_target_v2`;
- category-aware v3 controlled result:
  `/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holding_target_balanced_v3`.

The local source of truth is no longer the patched code copied under an old
Drive result directory. Restore the repository and use:

- `scripts/phase2d/build_holding_target_dataset.py`;
- `scripts/phase2d/audit_holding_target_dataset.py`;
- `scripts/phase3/sampling.py`;
- `scripts/phase3/run_controlled_taskfamily.py`;
- `scripts/phase3/offline_probe.py`;
- `scripts/phase3/analyze_holding_results.py`.

`configs/phase3_holding_target_balanced_v3.json` reproduces the existing
balanced-v3 sampler. The corrected sampler has a distinct prepared-but-not-run
config, `configs/phase3_holding_target_balanced_v4_samplingfix.json`; never
overwrite or merge its outputs with the v3 root.
