# Phase 3 Corrected Architecture Gate v2

Date: 2026-08-12

Status: corrected task-1/seed-0 smoke, three-fold/seed-0 gate, prediction
analysis, and weak-label audit sampling complete. The three-seed expansion is
closed by the preregistered gate; manual weak-label review remains pending.

## Why a corrected version is required

The legacy reduced cross-fold result remains valid only under its recorded
evaluation contract. It must not be overwritten or silently reinterpreted.
The audit found four confounds that prevent using that result as the final
architecture gate:

1. the legacy G1 current-relation auxiliary head receives the action-blended
   edge representation, so train-time action shuffling can damage both the
   current and future objectives;
2. checkpoint and threshold selection use event-enriched validation rows,
   despite the intended natural-distribution protocol;
3. the reported event metric uses ground-truth current holding, making it a
   conditional/oracle-current future-change metric;
4. the manifest QA does not verify task-local category quota counts or hash
   the payload shared by natural and challenge sample IDs.

## Corrected contract

The corrected gate uses a separate manifest, config, result root, and protocol
identifier. Legacy defaults in `offline_probe.py` are preserved.

- Every compared model uses the same action-free pair encoder for its current
  auxiliary head. The smoke keeps `current_loss_weight=0.25`; because the head
  is action-free, shuffled action cannot affect the current prediction path.
- Checkpoints are selected by natural-validation conditional holding-event
  PR-AUC. Future and current thresholds are selected once on the same natural
  validation predictions and frozen for natural test, challenge stress, and
  all perturbation controls.
- Natural test conditional holding-event PR-AUC is primary. Thresholded F1,
  onset F1, release F1, hard-negative FPR, Brier score, and ten-bin ECE are
  secondary.
- The conditional/oracle-current event metric is named explicitly. An
  end-to-end event metric using predicted current and predicted future holding
  is stored alongside it.
- Validation, natural test, and challenge-stress outputs include per-pair
  probabilities, targets, predictions, task, episode, sample ID, time steps,
  edge identity, and event-cluster metadata in gzip JSONL files.
- The challenge view remains a future-event-enriched subset of the natural
  held-out episodes and is interpreted only as stress analysis.
- Manifest QA checks sample and episode leakage, duplicate IDs, task-local
  category quotas, natural/challenge subset membership, and SHA-256 equality
  of graph/action/label payloads for overlapping sample IDs.
- Train-shuffled G1 uses task-local, episode-disjoint donors matched on action
  magnitude and coarse current-state descriptors. Donor QA and distances are
  persisted.

## Smoke and expansion gate

The first run is fixed to held-out task 1, seed 0 and compares B1-v2,
G1 late-action, S-0-G1, and G1 trained with matched shuffled action. The code
chooses near-parameter-matched widths while counting the common current head.

No 3 x 3 expansion follows directly. The next allowable step is three folds
with one seed. A model proceeds only if G1 improves natural event PR-AUC over
B1-v2 in at least two tasks, does not severely worsen hard-negative FPR,
improves release behavior, and shows a consistent degradation under action
shuffle. Otherwise, GNN depth work pauses in favor of a pair-local temporal
encoder with limited set context.

## Completed corrected gate result

The task-1/seed-0 smoke completed first, followed by only the missing task 0
and task 2 seed-0 runs. The task-1 runs were reused rather than repeated. All
12 model/fold runs use the same corrected manifest and protocol.

On natural test, G1 minus B1 conditional/oracle-current holding-event PR-AUC
was -0.1161 on task 0, +0.1322 on task 1, and +0.1717 on task 2. The task
macro difference was +0.0626, but the hierarchical bootstrap 95% interval
[-0.0892, +0.1905] includes zero. G1's task-macro thresholded event F1 was
0.3272 versus B1's 0.4083. By contrast, G1 improved release F1 by +0.1626
[+0.0701, +0.2967] and reduced hard-negative FPR by 0.3326
[-0.4201, -0.2429].

The mandatory action-alignment criterion failed. G1 minus train-shuffled G1
task-macro PR-AUC was -0.0567 with interval [-0.1943, +0.0572], and the sign
reversed on task 0. Train-shuffled G1 also had the highest task-macro
conditional PR-AUC (0.4985) and event F1 (0.4333). Thus this corrected gate
does not support a stable aligned-action advantage for the current late/global
action GNN.

The decision is therefore
`stop_gnn_three_seed_expansion_and_pivot_pair_local_temporal_encoder`. This
does not show that graph structure is generally useless: it says the current
late-action G1 has not cleared the architecture/action gate. Its release and
hard-negative behavior is worth retaining as a diagnostic target.

## Statistics and weak-label audit

The prediction analysis treats task as the outer unit, averages seeds within
task, and bootstraps task fold, episode, and event cluster hierarchically.
With only one smoke fold, its confidence interval is diagnostic rather than a
task-generalization interval. When historical artifacts lack an event ID, the
analysis records that sample ID is only a conservative proxy.

A deterministic weak-label audit builder selects 90 items: tasks 0/1/2 times
onset/release/hard-negative times ten. It exports the underlying trajectory
and graph evidence, a review CSV, allowed error types, and a pending summary.
Pass rate and error-type counts cannot be claimed until the manual review is
completed.

The audit manifest and evidence were generated successfully with 10 items in
each of the nine task/category cells and no shortages. Its status remains
`ready_for_manual_review`; no label pass rate is reported yet.

The trajectory-enriched v2 audit subsequently reconstructed all seven graph
frames for every selected window. Its deduplicated frame QA was 592/592
available with no missing or conflicting payloads. An interactive Colab viewer
renders the frame trajectory and action window and atomically records explicit
human decisions. The review remains 0/90 until those decisions are made.

## Versioned artifacts

Local entry points:

- `configs/phase3_holder_action_eval_v2_corrected.json`
- `configs/phase3_corrected_smoke_v2.json`
- `scripts/phase3/run_corrected_architecture_gate.py`
- `scripts/phase3/analyze_corrected_predictions.py`
- `scripts/phase3/build_weak_label_audit.py`
- `scripts/phase3/weak_label_audit_viewer.py`

Persistent Drive root:

`/content/drive/MyDrive/Graph-CLaD/artifacts/phase3_holder_action_v1/corrected_protocol_v2`

Key completed subdirectories:

- `smoke_task1_seed0`
- `threefold_seed0_missing_task0_task2`
- `threefold_seed0_combined`
- `weak_label_audit_v1`
- `weak_label_audit_v2_trajectory`

The legacy `phase3_reduced_crossfold_gate_v1.json`, its 36 checkpoints, and its
code snapshot remain unchanged.
