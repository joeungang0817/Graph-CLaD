# CLaD controlled reimplementation: knowns and unknowns

This repository is a controlled reimplementation study. The supplied three
Python files define the Stage 1 model core, but they do not define the full
training and evaluation pipeline. Unknowns are recorded here rather than
silently filled in.

## Confirmed from the supplied code

- `LatentDynamics.forward` consumes visual history, proprioception history,
  one action tensor, language features, and optional future targets.
- Visual views are flattened before `s_backbone`.
- The semantic and proprioceptive transition blocks each use five layers of
  four-head cross-attention with the configured hidden dimension.
- Proprioceptive transition tokens query semantic transition tokens.
- Evaluation returns `pred_p_emb` and `pred_s_emb` with shape `[B, H]`.
- Training returns `loss_p`, `loss_s`, `loss_p_recon`, and `loss_v_recon`.
- EMA target encoders exist, but the caller must invoke `update_ema()`.

## Phase 0 assumptions

- The reported paper setting uses `H=1024`, semantic feature dimension 1024,
  two views, action horizon 6, EMA momentum 0.995, and reconstruction weight
  0.1.
- The supplied code requires `V * Dv = 2 * vl_dim` because `s_backbone` is
  constructed with `input_dim=vl_dim * 2`.
- The supplied code also requires `vl_dim = hidden_dim` when adding the
  semantic backbone output to `s_query`.
- The smoke test uses a compact `H=64` configuration so forward/backward can
  be checked on CPU. This is a runtime test of the code path, not a validation
  of the production feature dimensions.

## Still unverified

- VLM preprocessing, frozen encoder, language representation, and view order.
- Actual proprioception and action dimensions.
- How action history is packed into `prev_action`.
- Actual history length and temporal sampling.
- Trainer loss weighting, optimizer, scheduler, checkpointing, and EMA call
  order.
- Whether masking the concatenated transition sequence is intended to mask
  only actions; the supplied function protects only the first token.
- Whether the asymmetric target normalization in the supplied code is
  intentional.
- Why visual reconstruction uses only `v_next[:, 0]` when multiple views are
  present.
- All Stage 2 diffusion policy and rollout details.

## Phase 2D demonstration-data unknowns

The revised main-data path intentionally remains blocked until the official
demonstration files are inspected. The following must not be guessed from the
scripted Phase 2R captures:

- exact local/Drive path, checksum, and task mapping of the task 0/1/2 HDF5
  demonstrations;
- whether each HDF5 `states[t]` is aligned before or after `actions[t]`;
- the exact environment metadata and reset/state-restore API required by the
  downloaded LIBERO/robomimic version;
- replay tolerance for qpos, EFF pose, and object pose after simulator forward;
- left-finger, right-finger, palm, and wrist geom/body names in the replay
  runtime;
- natural holding/on/inside event support in each task and split;
- train-only temporal holding parameters: contact persistence, K-frame
  relative-pose stability, follow/lift margin, and release hysteresis;
- whether task 2 has any holding-positive demonstration segment. Absence must
  be reported as unsupported coverage, not repaired using test-dependent
  threshold changes.

The executable decision record for these unknowns is
`docs/revised_research_roadmap_v3.md`.

## 2026-08-07 status of Phase 2D unknowns

The official task 0/1/2 HDF5 mapping, persistent Drive paths, exact state
replay, robot/gripper contact mapping, fixed split, and holding-positive
support have since been resolved for the scoped `libero_spatial` release.
Task 2 also has holding-positive and holding-changed support in the
target-aligned artifact. The unresolved questions have moved from data access
to validity and evaluation design:

- event-level precision of the heuristic holding onset/release labels;
- whether the current hard negatives are genuinely grasp-confusable;
- natural-prevalence performance versus target-conditioned challenge-set
  performance;
- a defensible held-out-task protocol with only three task families;
- whether P0 uses node ordering or other scene shortcuts;
- whether action reliance survives train-time controls;
- whether target-centric holder-object and action-conditioned temporal edges
  outperform target-object-only and flat baselines.

These current unknowns are tracked in
`docs/research_risk_review_20260807.md` and
`docs/phase3_holder_object_action_graph_design.md`.

## Controlled-study rule

Any assumption needed to complete the baseline will be fixed in a config and
applied identically to baseline CLaD and Graph-CLaD. Official CLaD metrics are
reference values only; this repository will report comparisons within the
controlled reimplementation environment.
