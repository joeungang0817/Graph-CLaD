"""Run a controlled Phase 3 offline relational-dynamics probe.

The probe consumes the validated Phase 2R dataset and predicts future
pairwise relations from current node features, current geometry, and an action
window.  It intentionally stops before CLaD integration: this isolates the
question of whether relational structure helps latent foresight at all.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn


EDGE_RELATIONS = (
    "left",
    "right",
    "front",
    "behind",
    "above",
    "below",
    "contact",
    "on",
    "inside",
    "holding",
)
MODEL_IDS = (
    "p0_flat_mlp",
    "p1_node_no_message",
    "p2_gnn_empty_edge",
    "p3_gnn_geometry",
    "p4_gnn_soft_attention",
)


def _set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    import torch

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _finite_float_list(value: Any) -> list[float]:
    if hasattr(value, "tolist"):
        value = value.tolist()
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    try:
        result = [float(item) for item in value]
    except (TypeError, ValueError):
        return []
    return result if all(math.isfinite(item) for item in result) else []


def _edge_key(edge: Mapping[str, Any]) -> tuple[str, str]:
    return str(edge["source"]), str(edge["target"])


def _relation_value(edge: Mapping[str, Any], relation: str) -> tuple[float, float]:
    record = edge.get("relations", {}).get(relation, {})
    if not isinstance(record, Mapping) or not record.get("valid"):
        return 0.0, 0.0
    return float(bool(record.get("value"))), 1.0


def _node_features(node: Mapping[str, Any]) -> list[float]:
    feature_vector = [float(value) for value in node.get("feature_vector", [])]
    node_type = str(node.get("node_type", "unknown"))
    type_one_hot = [float(node_type == candidate) for candidate in ("robot", "object", "fixture", "site")]
    return feature_vector + type_one_hot


def _edge_geometry(edge: Mapping[str, Any]) -> list[float]:
    features = edge.get("features", {})
    relative = _finite_float_list(features.get("relative_position"))
    relative = relative if len(relative) == 3 else [0.0, 0.0, 0.0]
    distance = float(features.get("distance", 0.0) or 0.0)
    distance_valid = float(features.get("distance_valid", 0) or 0)
    return relative + [distance, distance_valid]


def _record_from_sample(sample: Mapping[str, Any]) -> dict[str, Any]:
    graph = sample["graph_t"]
    target_graph = sample["graph_target"]
    nodes = graph.get("nodes", [])
    node_ids = [str(node["node_id"]) for node in nodes]
    node_index = {node_id: index for index, node_id in enumerate(node_ids)}
    current_edges = {_edge_key(edge): edge for edge in graph.get("edges", [])}
    target_edges = {_edge_key(edge): edge for edge in target_graph.get("edges", [])}

    edge_keys = [key for key in current_edges if key in target_edges]
    current_labels: list[list[float]] = []
    future_labels: list[list[float]] = []
    current_valid: list[list[float]] = []
    future_valid: list[list[float]] = []
    changed: list[list[float]] = []
    edge_src: list[int] = []
    edge_tgt: list[int] = []
    edge_geometry: list[list[float]] = []
    for key in edge_keys:
        current_edge = current_edges[key]
        future_edge = target_edges[key]
        edge_src.append(node_index[key[0]])
        edge_tgt.append(node_index[key[1]])
        edge_geometry.append(_edge_geometry(current_edge))
        now_row: list[float] = []
        future_row: list[float] = []
        now_mask_row: list[float] = []
        future_mask_row: list[float] = []
        changed_row: list[float] = []
        for relation in EDGE_RELATIONS:
            now_value, now_is_valid = _relation_value(current_edge, relation)
            future_value, future_is_valid = _relation_value(future_edge, relation)
            now_row.append(now_value)
            future_row.append(future_value)
            now_mask_row.append(now_is_valid)
            future_mask_row.append(future_is_valid)
            changed_row.append(float(now_is_valid and future_is_valid and now_value != future_value))
        current_labels.append(now_row)
        future_labels.append(future_row)
        current_valid.append(now_mask_row)
        future_valid.append(future_mask_row)
        changed.append(changed_row)

    actions = []
    for entry in sample.get("action_window", []):
        action_value = entry.get("action", []) if isinstance(entry, Mapping) else entry
        actions.append(_finite_float_list(action_value))
    action_dim = max((len(action) for action in actions), default=0)
    action_flat = [value for action in actions for value in action]
    return {
        "episode_id": str(sample.get("episode_id")),
        "suite": sample.get("suite"),
        "task_id": sample.get("task_id"),
        "split": str(sample.get("split", "train")),
        "node_features": [_node_features(node) for node in nodes],
        "edge_src": edge_src,
        "edge_tgt": edge_tgt,
        "edge_geometry": edge_geometry,
        "current_labels": current_labels,
        "future_labels": future_labels,
        "current_valid": current_valid,
        "future_valid": future_valid,
        "changed": changed,
        "actions": action_flat,
        "action_steps": len(actions),
        "action_dim": action_dim,
    }


def _sample_task_family(sample: Mapping[str, Any]) -> str:
    suite = sample.get("suite")
    task_id = sample.get("task_id")
    if suite is None or task_id is None:
        raise ValueError(f"sample is missing suite/task_id: {sample.get('episode_id')}")
    return f"{suite}:{task_id}"


def _apply_split_override(sample: Mapping[str, Any], split_config: Mapping[str, Any] | None) -> dict[str, Any]:
    output = dict(sample)
    if not isinstance(split_config, Mapping):
        return output
    validation = {str(value) for value in split_config.get("validation_task_families", [])}
    test = {str(value) for value in split_config.get("test_task_families", [])}
    family = _sample_task_family(sample)
    output["split"] = "test" if family in test else "validation" if family in validation else "train"
    return output


def load_probe_records(
    dataset: Mapping[str, Any],
    split_config: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    samples = dataset.get("samples", [])
    if not isinstance(samples, Sequence) or isinstance(samples, (str, bytes)):
        raise ValueError("dataset.samples must be a sequence")
    records = [
        _record_from_sample(_apply_split_override(sample, split_config))
        for sample in samples
    ]
    if not records:
        raise ValueError("dataset contains no usable samples")
    return records


def _normalization(records: Sequence[Mapping[str, Any]]) -> dict[str, np.ndarray]:
    node_rows = np.asarray(
        [row for record in records for row in record["node_features"]], dtype=np.float32
    )
    edge_rows = np.asarray(
        [row for record in records for row in record["edge_geometry"]], dtype=np.float32
    )
    action_rows = np.asarray([record["actions"] for record in records], dtype=np.float32)

    def stats(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        mean = values.mean(axis=0) if values.size else np.zeros((values.shape[-1],), dtype=np.float32)
        std = values.std(axis=0) if values.size else np.ones((values.shape[-1],), dtype=np.float32)
        std = np.where(std < 1e-6, 1.0, std)
        return mean.astype(np.float32), std.astype(np.float32)

    node_mean, node_std = stats(node_rows)
    edge_mean, edge_std = stats(edge_rows)
    action_mean, action_std = stats(action_rows)
    return {
        "node_mean": node_mean,
        "node_std": node_std,
        "edge_mean": edge_mean,
        "edge_std": edge_std,
        "action_mean": action_mean,
        "action_std": action_std,
    }


@dataclass
class ProbeShape:
    max_nodes: int
    max_edges: int
    node_dim: int
    edge_dim: int
    action_dim: int
    relation_dim: int


class ProbeCollator:
    def __init__(self, shape: ProbeShape, normalization: Mapping[str, np.ndarray]):
        self.shape = shape
        self.normalization = normalization

    def __call__(self, records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
        import torch

        batch_size = len(records)
        shape = self.shape
        node_x = np.zeros((batch_size, shape.max_nodes, shape.node_dim), dtype=np.float32)
        node_mask = np.zeros((batch_size, shape.max_nodes), dtype=np.float32)
        edge_src = np.zeros((batch_size, shape.max_edges), dtype=np.int64)
        edge_tgt = np.zeros((batch_size, shape.max_edges), dtype=np.int64)
        edge_geometry = np.zeros((batch_size, shape.max_edges, shape.edge_dim), dtype=np.float32)
        edge_mask = np.zeros((batch_size, shape.max_edges), dtype=np.float32)
        current_labels = np.zeros((batch_size, shape.max_edges, shape.relation_dim), dtype=np.float32)
        future_labels = np.zeros_like(current_labels)
        current_valid = np.zeros_like(current_labels)
        future_valid = np.zeros_like(current_labels)
        changed = np.zeros_like(current_labels)
        actions = np.zeros((batch_size, shape.action_dim), dtype=np.float32)
        for batch_index, record in enumerate(records):
            node_count = min(shape.max_nodes, len(record["node_features"]))
            edge_count = min(shape.max_edges, len(record["edge_src"]))
            node_values = np.asarray(record["node_features"][:node_count], dtype=np.float32)
            node_x[batch_index, :node_count] = (
                node_values - self.normalization["node_mean"]
            ) / self.normalization["node_std"]
            node_mask[batch_index, :node_count] = 1.0
            edge_src[batch_index, :edge_count] = np.asarray(record["edge_src"][:edge_count], dtype=np.int64)
            edge_tgt[batch_index, :edge_count] = np.asarray(record["edge_tgt"][:edge_count], dtype=np.int64)
            edge_values = np.asarray(record["edge_geometry"][:edge_count], dtype=np.float32)
            edge_geometry[batch_index, :edge_count] = (
                edge_values - self.normalization["edge_mean"]
            ) / self.normalization["edge_std"]
            edge_mask[batch_index, :edge_count] = 1.0
            current_labels[batch_index, :edge_count] = record["current_labels"][:edge_count]
            future_labels[batch_index, :edge_count] = record["future_labels"][:edge_count]
            current_valid[batch_index, :edge_count] = record["current_valid"][:edge_count]
            future_valid[batch_index, :edge_count] = record["future_valid"][:edge_count]
            changed[batch_index, :edge_count] = record["changed"][:edge_count]
            action_values = np.asarray(record["actions"][: shape.action_dim], dtype=np.float32)
            actions[batch_index, : len(action_values)] = (
                action_values - self.normalization["action_mean"][: len(action_values)]
            ) / self.normalization["action_std"][: len(action_values)]
        return {
            "node_x": torch.from_numpy(node_x),
            "node_mask": torch.from_numpy(node_mask),
            "edge_src": torch.from_numpy(edge_src),
            "edge_tgt": torch.from_numpy(edge_tgt),
            "edge_geometry": torch.from_numpy(edge_geometry),
            "edge_mask": torch.from_numpy(edge_mask),
            "current_labels": torch.from_numpy(current_labels),
            "future_labels": torch.from_numpy(future_labels),
            "current_valid": torch.from_numpy(current_valid),
            "future_valid": torch.from_numpy(future_valid),
            "changed": torch.from_numpy(changed),
            "actions": torch.from_numpy(actions),
        }


def _mlp(nn_module, input_dim: int, hidden_dim: int, output_dim: int) -> Any:
    import torch.nn as nn

    return nn.Sequential(
        nn.Linear(input_dim, hidden_dim),
        nn.LayerNorm(hidden_dim),
        nn.GELU(),
        nn.Linear(hidden_dim, hidden_dim),
        nn.GELU(),
        nn.Linear(hidden_dim, output_dim),
    )


class RelationalDynamicsProbe(nn.Module):
    def __init__(self, model_id: str, shape: ProbeShape, hidden_dim: int = 64):
        super().__init__()
        self.model_id = model_id
        self.shape = shape
        self.hidden_dim = hidden_dim
        self.node_encoder = _mlp(nn, shape.node_dim, hidden_dim, hidden_dim)
        self.action_encoder = _mlp(nn, shape.action_dim, hidden_dim, hidden_dim)
        self.relation_dim = shape.relation_dim
        if model_id == "p0_flat_mlp":
            flat_dim = shape.max_nodes * shape.node_dim + shape.max_nodes + shape.action_dim
            self.global_encoder = _mlp(nn, flat_dim, hidden_dim, hidden_dim)
            self.edge_encoder = _mlp(nn, hidden_dim + shape.edge_dim, hidden_dim, hidden_dim)
        elif model_id == "p1_node_no_message":
            self.edge_encoder = _mlp(nn, hidden_dim * 3, hidden_dim, hidden_dim)
        elif model_id == "p2_gnn_empty_edge":
            self.node_update = _mlp(nn, hidden_dim * 2, hidden_dim, hidden_dim)
            self.edge_encoder = _mlp(nn, hidden_dim * 3, hidden_dim, hidden_dim)
        elif model_id in {"p3_gnn_geometry", "p4_gnn_soft_attention"}:
            self.message_encoder = _mlp(nn, hidden_dim * 2 + shape.edge_dim, hidden_dim, hidden_dim)
            self.node_update = _mlp(nn, hidden_dim * 2, hidden_dim, hidden_dim)
            if model_id == "p4_gnn_soft_attention":
                self.edge_attention = nn.Sequential(
                    nn.Linear(hidden_dim * 2 + shape.edge_dim, hidden_dim),
                    nn.GELU(),
                    nn.Linear(hidden_dim, 1),
                )
            self.edge_encoder = _mlp(nn, hidden_dim * 2 + shape.edge_dim + hidden_dim, hidden_dim, hidden_dim)
        else:
            raise ValueError(f"unknown model_id={model_id}")
        self.future_head = nn.Linear(hidden_dim, shape.relation_dim)
        self.current_head = nn.Linear(hidden_dim, shape.relation_dim)

    def _gather(self, values, indices):
        batch = values.shape[0]
        batch_indices = torch.arange(batch, device=values.device).unsqueeze(1)
        return values[batch_indices, indices.clamp(min=0, max=values.shape[1] - 1)]

    def _aggregate_messages(self, node_h, edge_src, edge_tgt, edge_geometry, edge_mask):
        source_h = self._gather(node_h, edge_src)
        target_h = self._gather(node_h, edge_tgt)
        message_input = torch.cat([source_h, target_h, edge_geometry], dim=-1)
        messages = self.message_encoder(message_input)
        if self.model_id == "p4_gnn_soft_attention":
            weights = torch.sigmoid(self.edge_attention(message_input))
            messages = messages * weights
        messages = messages * edge_mask.unsqueeze(-1)
        batch, node_count, hidden = node_h.shape
        offsets = torch.arange(batch, device=node_h.device).view(batch, 1) * node_count
        flat_target = (edge_tgt + offsets).reshape(-1)
        aggregate = torch.zeros(batch * node_count, hidden, device=node_h.device)
        aggregate.index_add_(0, flat_target, messages.reshape(-1, hidden))
        degree = torch.zeros(batch * node_count, 1, device=node_h.device)
        degree.index_add_(0, flat_target, edge_mask.reshape(-1, 1))
        aggregate = aggregate.reshape(batch, node_count, hidden) / degree.clamp_min(1.0).reshape(batch, node_count, 1)
        return aggregate

    def forward(self, node_x, node_mask, edge_src, edge_tgt, edge_geometry, edge_mask, actions, edge_shuffle=False):
        import torch

        if edge_shuffle:
            edge_src = torch.roll(edge_src, shifts=1, dims=1)
            edge_tgt = torch.roll(edge_tgt, shifts=-1, dims=1)
        action_h = self.action_encoder(actions)
        if self.model_id == "p0_flat_mlp":
            flat = torch.cat([node_x.reshape(node_x.shape[0], -1), node_mask, actions], dim=-1)
            graph_h = self.global_encoder(flat).unsqueeze(1).expand(-1, edge_src.shape[1], -1)
            edge_h = self.edge_encoder(torch.cat([graph_h, edge_geometry], dim=-1))
        else:
            node_h = self.node_encoder(node_x)
            node_h = node_h * node_mask.unsqueeze(-1)
            if self.model_id == "p2_gnn_empty_edge":
                for _ in range(2):
                    total = node_h.sum(dim=1, keepdim=True)
                    count = node_mask.sum(dim=1, keepdim=True).unsqueeze(-1)
                    aggregate = (total - node_h) / (count - 1.0).clamp_min(1.0)
                    node_h = self.node_update(torch.cat([node_h, aggregate], dim=-1))
                    node_h = node_h * node_mask.unsqueeze(-1)
                source_h = self._gather(node_h, edge_src)
                target_h = self._gather(node_h, edge_tgt)
                edge_h = self.edge_encoder(torch.cat([source_h, target_h, action_h.unsqueeze(1).expand_as(source_h)], dim=-1))
            elif self.model_id == "p1_node_no_message":
                source_h = self._gather(node_h, edge_src)
                target_h = self._gather(node_h, edge_tgt)
                edge_h = self.edge_encoder(torch.cat([source_h, target_h, action_h.unsqueeze(1).expand_as(source_h)], dim=-1))
            else:
                for _ in range(2):
                    aggregate = self._aggregate_messages(node_h, edge_src, edge_tgt, edge_geometry, edge_mask)
                    node_h = self.node_update(torch.cat([node_h, aggregate], dim=-1))
                    node_h = node_h * node_mask.unsqueeze(-1)
                source_h = self._gather(node_h, edge_src)
                target_h = self._gather(node_h, edge_tgt)
                action_edge = action_h.unsqueeze(1).expand(-1, edge_src.shape[1], -1)
                edge_h = self.edge_encoder(torch.cat([source_h, target_h, edge_geometry, action_edge], dim=-1))
        return self.future_head(edge_h), self.current_head(edge_h)


def _masked_bce(logits, labels, valid, pos_weight):
    import torch
    import torch.nn.functional as F

    loss = F.binary_cross_entropy_with_logits(
        logits,
        labels,
        reduction="none",
        pos_weight=pos_weight.view(1, 1, -1),
    )
    weighted = loss * valid
    return weighted.sum() / valid.sum().clamp_min(1.0)


def _f1_metrics(y_true: np.ndarray, y_pred: np.ndarray, mask: np.ndarray) -> dict[str, Any]:
    per_relation: dict[str, Any] = {}
    scores: list[float] = []
    for index, relation in enumerate(EDGE_RELATIONS):
        selected = mask[..., index].astype(bool)
        truth = y_true[..., index][selected].astype(bool)
        prediction = y_pred[..., index][selected].astype(bool)
        support = int(selected.sum())
        if support == 0:
            per_relation[relation] = {"support": 0, "f1": None, "precision": None, "recall": None}
            continue
        tp = int(np.logical_and(truth, prediction).sum())
        fp = int(np.logical_and(~truth, prediction).sum())
        fn = int(np.logical_and(truth, ~prediction).sum())
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2.0 * precision * recall / max(precision + recall, 1e-12)
        per_relation[relation] = {
            "support": support,
            "positive": int(truth.sum()),
            "f1": f1,
            "precision": precision,
            "recall": recall,
        }
        scores.append(f1)
    return {
        "macro_f1": float(np.mean(scores)) if scores else None,
        "per_relation": per_relation,
    }


def _to_device(batch: Mapping[str, Any], device: str) -> dict[str, Any]:
    return {
        key: value.to(device) if hasattr(value, "to") else value
        for key, value in batch.items()
    }


def _collect_predictions(model, loader, device: str, mode: str) -> tuple[np.ndarray, ...]:
    import torch

    y_true: list[np.ndarray] = []
    y_pred: list[np.ndarray] = []
    valid: list[np.ndarray] = []
    changed: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            batch = _to_device(batch, device)
            actions = batch["actions"]
            if mode == "no_action":
                actions = torch.zeros_like(actions)
            elif mode == "shuffled_action" and actions.shape[0] > 1:
                actions = torch.roll(actions, shifts=1, dims=0)
            future_logits, _ = model(
                batch["node_x"], batch["node_mask"], batch["edge_src"], batch["edge_tgt"],
                batch["edge_geometry"], batch["edge_mask"], actions,
                edge_shuffle=mode == "shuffled_edge",
            )
            y_true.append(batch["future_labels"].cpu().numpy())
            y_pred.append((torch.sigmoid(future_logits) >= 0.5).cpu().numpy())
            valid.append(batch["future_valid"].cpu().numpy())
            changed.append(batch["changed"].cpu().numpy())
    return np.concatenate(y_true), np.concatenate(y_pred), np.concatenate(valid), np.concatenate(changed)


def evaluate_model(model, loader, device: str, mode: str = "correct") -> dict[str, Any]:
    y_true, y_pred, valid, changed = _collect_predictions(model, loader, device, mode)
    overall = _f1_metrics(y_true, y_pred, valid)
    changed_metrics = _f1_metrics(y_true, y_pred, valid * changed)
    return {
        "mode": mode,
        "future_relation": overall,
        "changed_relation": changed_metrics,
    }


def _positive_weight(records: Sequence[Mapping[str, Any]], relation_dim: int):
    import torch

    positive = np.zeros(relation_dim, dtype=np.float64)
    negative = np.zeros(relation_dim, dtype=np.float64)
    for record in records:
        labels = np.asarray(record["future_labels"], dtype=np.float32)
        valid = np.asarray(record["future_valid"], dtype=np.float32)
        positive += (labels * valid).sum(axis=0)
        negative += ((1.0 - labels) * valid).sum(axis=0)
    return torch.tensor(np.clip(negative / np.maximum(positive, 1.0), 1.0, 20.0), dtype=torch.float32)


def train_one(
    model_id: str,
    shape: ProbeShape,
    train_records: Sequence[Mapping[str, Any]],
    val_loader,
    train_loader,
    device: str,
    hidden_dim: int,
    epochs: int,
    patience: int,
    learning_rate: float,
    current_loss_weight: float,
) -> tuple[Any, dict[str, Any]]:
    import torch

    model = RelationalDynamicsProbe(model_id, shape, hidden_dim=hidden_dim).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    pos_weight = _positive_weight(train_records, shape.relation_dim).to(device)
    best_score = -1.0
    best_state = None
    stale = 0
    history: list[dict[str, Any]] = []
    for epoch in range(1, epochs + 1):
        model.train()
        train_losses: list[float] = []
        for batch in train_loader:
            batch = _to_device(batch, device)
            optimizer.zero_grad(set_to_none=True)
            future_logits, current_logits = model(
                batch["node_x"], batch["node_mask"], batch["edge_src"], batch["edge_tgt"],
                batch["edge_geometry"], batch["edge_mask"], batch["actions"],
            )
            future_loss = _masked_bce(
                future_logits, batch["future_labels"], batch["future_valid"], pos_weight
            )
            current_loss = _masked_bce(
                current_logits, batch["current_labels"], batch["current_valid"], pos_weight
            )
            loss = future_loss + current_loss_weight * current_loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_losses.append(float(loss.detach().cpu()))
        val_metrics = evaluate_model(model, val_loader, device, mode="correct")
        score = val_metrics["future_relation"]["macro_f1"] or 0.0
        history.append({"epoch": epoch, "train_loss": float(np.mean(train_losses)), "val_macro_f1": score})
        if score > best_score + 1e-6:
            best_score = score
            best_state = copy.deepcopy(model.state_dict())
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {
        "hidden_dim": hidden_dim,
        "best_val_macro_f1": best_score,
        "epochs_ran": len(history),
        "history": history,
        "parameter_count": int(sum(parameter.numel() for parameter in model.parameters())),
    }


def _loader(records, shape, normalization, batch_size, shuffle):
    import torch
    from torch.utils.data import DataLoader

    collator = ProbeCollator(shape, normalization)
    return DataLoader(records, batch_size=batch_size, shuffle=shuffle, collate_fn=collator)


def _select_hidden_dims(
    model_ids: Sequence[str],
    shape: ProbeShape,
    config: Mapping[str, Any],
) -> dict[str, int]:
    """Choose per-model widths closest to one declared parameter budget."""

    requested = int(config.get("hidden_dim", 64))
    if not bool(config.get("parameter_match", False)):
        return {model_id: requested for model_id in model_ids}
    target = int(config.get("target_parameter_count", 70000))
    candidates = [int(value) for value in config.get(
        "candidate_hidden_dims", [40, 48, 56, 64, 72, 80, 88, 96]
    )]
    selected: dict[str, int] = {}
    for model_id in model_ids:
        choices: list[tuple[int, int]] = []
        for hidden_dim in candidates:
            model = RelationalDynamicsProbe(model_id, shape, hidden_dim=hidden_dim)
            parameter_count = int(sum(parameter.numel() for parameter in model.parameters()))
            choices.append((abs(parameter_count - target), hidden_dim))
            del model
        selected[model_id] = min(choices)[1]
    return selected


def run_probe(dataset: Mapping[str, Any], config: Mapping[str, Any]) -> dict[str, Any]:
    import torch

    records = load_probe_records(dataset, split_config=config.get("split"))
    train_records = [record for record in records if record["split"] == "train"]
    val_records = [record for record in records if record["split"] == "validation"]
    test_records = [record for record in records if record["split"] == "test"]
    if not train_records or not val_records or not test_records:
        raise ValueError("dataset must contain train, validation, and test episode splits")
    shape = ProbeShape(
        max_nodes=max(len(record["node_features"]) for record in records),
        max_edges=max(len(record["edge_src"]) for record in records),
        node_dim=len(records[0]["node_features"][0]),
        edge_dim=len(records[0]["edge_geometry"][0]),
        action_dim=max(len(record["actions"]) for record in records),
        relation_dim=len(EDGE_RELATIONS),
    )
    normalization = _normalization(train_records)
    requested_device = str(config.get("device", "auto"))
    if requested_device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    else:
        device = requested_device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"
    batch_size = int(config.get("batch_size", 64))
    train_loader = _loader(train_records, shape, normalization, batch_size, shuffle=True)
    val_loader = _loader(val_records, shape, normalization, batch_size, shuffle=False)
    test_loader = _loader(test_records, shape, normalization, batch_size, shuffle=False)
    model_ids = list(config.get("models", MODEL_IDS))
    seeds = [int(seed) for seed in config.get("seeds", [0, 1, 2])]
    hidden_dims = _select_hidden_dims(model_ids, shape, config)
    results: list[dict[str, Any]] = []
    for model_id in model_ids:
        for seed in seeds:
            _set_seed(seed)
            model, training = train_one(
                model_id=model_id,
                shape=shape,
                train_records=train_records,
                val_loader=val_loader,
                train_loader=train_loader,
                device=device,
                hidden_dim=hidden_dims[model_id],
                epochs=int(config.get("epochs", 40)),
                patience=int(config.get("patience", 8)),
                learning_rate=float(config.get("learning_rate", 1e-3)),
                current_loss_weight=float(config.get("current_loss_weight", 0.25)),
            )
            modes = ["correct", "no_action", "shuffled_action", "shuffled_edge"]
            evaluations = {mode: evaluate_model(model, test_loader, device, mode=mode) for mode in modes}
            results.append({
                "model_id": model_id,
                "seed": seed,
                "hidden_dim": hidden_dims[model_id],
                "device": device,
                "training": training,
                "evaluations": evaluations,
            })
            print(json.dumps({
                "model_id": model_id,
                "seed": seed,
                "best_val_macro_f1": training["best_val_macro_f1"],
                "test_macro_f1": evaluations["correct"]["future_relation"]["macro_f1"],
                "changed_f1": evaluations["correct"]["changed_relation"]["macro_f1"],
            }, ensure_ascii=False))
    return {
        "probe_version": "phase3-offline.v1",
        "dataset_version": dataset.get("dataset_version"),
        "config": dict(config),
        "device": device,
        "relations": list(EDGE_RELATIONS),
        "shape": shape.__dict__,
        "split_counts": {
            "train_samples": len(train_records),
            "validation_samples": len(val_records),
            "test_samples": len(test_records),
            "train_episode_ids": sorted({record["episode_id"] for record in train_records}),
            "validation_episode_ids": sorted({record["episode_id"] for record in val_records}),
            "test_episode_ids": sorted({record["episode_id"] for record in test_records}),
        },
        "normalization_fit": "train_samples_only",
        "parameter_matching": {
            "enabled": bool(config.get("parameter_match", False)),
            "target_parameter_count": config.get("target_parameter_count"),
            "hidden_dims": hidden_dims,
        },
        "models": results,
        "controls": {
            "no_action": "zero action window at test time",
            "shuffled_action": "batch-rolled action windows at test time",
            "shuffled_edge": "sender and receiver indices independently rolled while labels stay fixed",
        },
        "limitations": [
            "This is an oracle graph offline probe, not RGB graph perception.",
            "P5 recurrent/history model is deferred because the current Phase 2R sample stores graph_t and graph_target, not a full past graph sequence.",
            "The existing scale-up test split contains the final two episode IDs; report task coverage with the metrics.",
        ],
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    dataset = json.loads(args.dataset.read_text(encoding="utf-8"))
    config = json.loads(args.config.read_text(encoding="utf-8"))
    report = run_probe(dataset, config)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "probe_version": report["probe_version"],
        "device": report["device"],
        "models": len(report["models"]),
        "split_counts": report["split_counts"],
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
