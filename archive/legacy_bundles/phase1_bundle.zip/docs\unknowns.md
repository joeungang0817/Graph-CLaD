# CLaD controlled reimplementation: knowns and unknowns

This repository is a controlled reimplementation study. The supplied three
Python files define the Stage 1 model core, but they do not define the full
training and evaluation pipeline. Unknowns are recorded here rather than
silently filled in.

## Confirmed from the supplied code

- `LatentDynamics.forward` consumes visual history, proprioception history,
  one action tensor, language features, and optional future targets.
- Visual views are flattened before `s_backbone`.
- The semantic and proprioceptive transition blocks each use five layers of
  four-head cross-attention with the configured hidden dimension.
- Proprioceptive transition tokens query semantic transition tokens.
- Evaluation returns `pred_p_emb` and `pred_s_emb` with shape `[B, H]`.
- Training returns `loss_p`, `loss_s`, `loss_p_recon`, and `loss_v_recon`.
- EMA target encoders exist, but the caller must invoke `update_ema()`.

## Phase 0 assumptions

- The reported paper setting uses `H=1024`, semantic feature dimension 1024,
  two views, action horizon 6, EMA momentum 0.995, and reconstruction weight
  0.1.
- The supplied code requires `V * Dv = 2 * vl_dim` because `s_backbone` is
  constructed with `input_dim=vl_dim * 2`.
- The supplied code also requires `vl_dim = hidden_dim` when adding the
  semantic backbone output to `s_query`.
- The smoke test uses a compact `H=64` configuration so forward/backward can
  be checked on CPU. This is a runtime test of the code path, not a validation
  of the production feature dimensions.

## Still unverified

- VLM preprocessing, frozen encoder, language representation, and view order.
- Actual proprioception and action dimensions.
- How action history is packed into `prev_action`.
- Actual history length and temporal sampling.
- Trainer loss weighting, optimizer, scheduler, checkpointing, and EMA call
  order.
- Whether masking the concatenated transition sequence is intended to mask
  only actions; the supplied function protects only the first token.
- Whether the asymmetric target normalization in the supplied code is
  intentional.
- Why visual reconstruction uses only `v_next[:, 0]` when multiple views are
  present.
- All Stage 2 diffusion policy and rollout details.

## Controlled-study rule

Any assumption needed to complete the baseline will be fixed in a config and
applied identically to baseline CLaD and Graph-CLaD. Official CLaD metrics are
reference values only; this repository will report comparisons within the
controlled reimplementation environment.
