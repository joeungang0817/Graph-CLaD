# Graph-CLaD research notebook

This file is the cumulative research history for the controlled CLaD to
Graph-CLaD study. It records decisions, evidence, blockers, and next gates so
that implementation changes remain traceable.

## 2026-08-05 - Starting point

### Research context

- Goal: test whether an oracle object-relation graph can improve CLaD latent
  foresight under a controlled comparison.
- Available from the original researchers: `LatentDynamics.py`,
  `MlpResNet.py`, and `Attentions.py`.
- Missing from the supplied code: the full Stage 1 trainer, VLM feature
  pipeline, LIBERO loader/wrapper, Stage 2 diffusion policy, rollout code,
  and official checkpoint/configuration.
- Study rule: do not claim reproduction of the official CLaD headline metric;
  compare baseline CLaD and Graph-CLaD inside the same controlled
  reimplementation environment.

## 2026-08-05 - Phase 0: baseline execution gate

### Work completed

- Preserved the original three model files without modifying their model
  logic.
- Added `baseline_code/__init__.py` so the existing relative imports execute as
  a package.
- Added `tests/test_phase0_smoke.py` with a compact synthetic CPU configuration.
- Added `configs/phase0_synthetic.json`, `docs/phase0_baseline.md`,
  `docs/unknowns.md`, and `requirements-phase0.txt`.
- Connected the project to Google Colab through the project-local MCP config in
  `.codex/config.toml`.

### Confirmed

- Training forward returns `loss_p`, `loss_s`, `loss_p_recon`, and
  `loss_v_recon`.
- Losses and evaluation embeddings are finite.
- Backward creates finite gradients.
- Evaluation returns two `[B, H]` foresight embeddings.
- EMA target initialization and momentum update behave as implemented.
- The supplied code requires `V * Dv = 2 * vl_dim` and, for the current
  addition path, `vl_dim = hidden_dim`.

### Debug record

The first smoke configuration used `visual_dim_per_view=32`, which violated
the model's `s_backbone(input_dim=vl_dim*2)` contract for two views. The test
failed with a matrix multiplication shape error. The synthetic configuration
was corrected to `visual_dim_per_view=64`; the baseline source was not
changed. The final Colab run on an A100 reported 4 tests passed in 1.748 s.

### Phase 0 gate

Passed. The model core can execute a synthetic train/eval/EMA path. This does
not verify the real VLM, dataset, LIBERO state, or trainer dimensions.

## 2026-08-05 - Phase 1: LIBERO state investigation

### Research question

Can LIBERO expose stable logical object identities, object/fixture poses,
robot end-effector and gripper state, and simulator predicates needed for an
oracle object graph?

### Source-level findings

- The LIBERO wrapper exposes the underlying simulator and flattened simulator
  state.
- The task environment maintains object, fixture, site, and object-state
  dictionaries plus a logical-name-to-body-index map.
- Object state wrappers read body position/quaternion and provide joint and
  predicate access; site wrappers provide site pose and compatible predicate
  interfaces.
- The graph identity will be the logical object name. MuJoCo `body_id` is
  runtime metadata only.

### Work completed

- Added `scripts/inspect_libero_state.py` to capture raw observation schemas,
  robot fields, object/fixture/site poses, runtime body IDs, joint/predicate
  fields, and simulator metadata.
- Added `tests/test_phase1_inspection.py` to test the schema helpers without a
  LIBERO installation.
- Added `configs/phase1_state_inspection.json`.
- Added `data/phase1_libero_state_sample.json`, explicitly labelled as a
  schema example rather than a live capture.
- Added `docs/phase1_libero_state.md` with the access contract and safeguards.

### Colab execution and compatibility record

- Uploaded the Phase 1 bundle to the open Colab notebook and ran on an A100.
- Installed the official LIBERO source with the study's diagnostic dependency
  set: `robosuite==1.4.0`, `bddl==1.0.1`, MuJoCo, and supporting packages.
- The modern Colab MuJoCo wrapper was not API-compatible with robosuite 1.4.0's
  `qM`/`mj_fullM` calls. A runtime-only patch was applied inside the Colab
  environment; the repository baseline remained unchanged.
- `IK_POSE` was not used because LIBERO's `MountedPanda` is not supported by
  that controller in this runtime. `JOINT_POSITION` is used only for zero-action
  state inspection.
- LIBERO's legacy init-state file required `torch.load(...,
  weights_only=False)` under the current PyTorch default. This was applied only
  to the trusted official local init file in Colab.

### Live result

- Fixed capture: suite `libero_spatial`, task 0, initial state 0, seed 0.
- Task: `pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate`.
- Two snapshots were captured: reset state and one zero-action step.
- Each snapshot exposed 23 object/fixture/site entries. The simulator reported
  flat state dimension 92, 38 bodies, 31 sites, 270 geoms, 18 joints, and an
  8-dimensional action.
- Raw observations included 128x128 RGB views, object pose/relation fields,
  a 70-dimensional `object-state`, 7D joint position/velocity, 2D gripper
  position/velocity, and 39D proprioception.
- The first live manifest is stored in
  `data/phase1_libero_state_capture.json`. The full capture can be regenerated
  with `scripts/inspect_libero_state.py`.

### Interpretation and limitation

Phase 1 confirms that a graph input can be grounded in stable logical names,
raw poses, robot state, and task-relevant object relations. `body_id` is kept
as runtime metadata only. Some generic object-state predicate probes returned
object-specific shape or `NotImplementedError` results; Phase 2 must use
capability-aware relation extraction and preserve missing values explicitly.

### Phase 1 status

Passed for the controlled state-access gate. The live capture is sufficient to
freeze the first GraphSpec draft; predicate coverage and normalization remain
explicit Phase 2 design decisions.

## Next gate: Phase 2

1. Freeze GraphSpec: node types, coordinate frame, normalization, edge
   features, relation thresholds, and episode-level split manifest.
2. Add two-timestep graph visualization and graph extractor tests.
