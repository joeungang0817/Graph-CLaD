"""Build action-conditioned oracle graph transitions for Phase 2R."""

from __future__ import annotations

import argparse
import copy
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Mapping, Sequence

try:
    from .graph_extractor import _make_edges, extract_graph_snapshot
except ImportError:  # pragma: no cover - CLI execution from scripts/
    from graph_extractor import _make_edges, extract_graph_snapshot


RELATIONS = (
    "left",
    "right",
    "front",
    "behind",
    "above",
    "below",
    "contact",
    "on",
    "inside",
    "holding",
    "open",
    "close",
)
GEOMETRIC_RELATIONS = {"left", "right", "front", "behind", "above", "below"}
MARGIN = 0.02


def _position(node: Mapping[str, Any]) -> list[float] | None:
    features = node.get("features", {})
    if features.get("position_valid") != 1:
        return None
    value = features.get("position")
    if not isinstance(value, Sequence) or len(value) != 3:
        return None
    return [float(item) for item in value]


def _relation_record(value: bool | None, definition: str) -> dict[str, Any]:
    if value is None:
        return {"value": None, "valid": 0, "definition_version": definition}
    return {"value": bool(value), "valid": 1, "definition_version": definition}


def _contact_set(snapshot: Mapping[str, Any]) -> set[tuple[str, str]] | None:
    if "contact_pairs" not in snapshot:
        return None
    pairs = set()
    for pair in snapshot.get("contact_pairs", []):
        if isinstance(pair, Sequence) and len(pair) == 2:
            pairs.add(tuple(sorted((str(pair[0]), str(pair[1])))))
    return pairs


def relation_labels(
    source: Mapping[str, Any],
    target: Mapping[str, Any],
    contact_pairs: set[tuple[str, str]] | None,
    margin: float = MARGIN,
) -> dict[str, dict[str, Any]]:
    source_pos = _position(source)
    target_pos = _position(target)
    labels: dict[str, dict[str, Any]] = {}
    if source_pos is None or target_pos is None:
        for relation in RELATIONS:
            labels[relation] = _relation_record(None, "phase2r.v1")
        return labels
    dx = target_pos[0] - source_pos[0]
    dy = target_pos[1] - source_pos[1]
    dz = target_pos[2] - source_pos[2]
    labels.update(
        {
            "left": _relation_record(dx < -margin, "world_axis_x_margin_0.02"),
            "right": _relation_record(dx > margin, "world_axis_x_margin_0.02"),
            "front": _relation_record(dy > margin, "world_axis_y_margin_0.02"),
            "behind": _relation_record(dy < -margin, "world_axis_y_margin_0.02"),
            "above": _relation_record(dz > margin, "world_axis_z_margin_0.02"),
            "below": _relation_record(dz < -margin, "world_axis_z_margin_0.02"),
        }
    )
    if contact_pairs is None:
        labels["contact"] = _relation_record(None, "mujoco_contact_unavailable")
    else:
        pair = tuple(sorted((str(source["node_id"]), str(target["node_id"]))))
        labels["contact"] = _relation_record(pair in contact_pairs, "mujoco_contact")
    for relation in RELATIONS:
        labels.setdefault(relation, _relation_record(None, "capability_labeler_pending"))
    return labels


def _select_nodes(graph: Mapping[str, Any], include_all_sites: bool) -> list[dict[str, Any]]:
    nodes = []
    for original in graph["nodes"]:
        node = copy.deepcopy(original)
        if not include_all_sites and node["node_type"] == "site":
            continue
        # v2 removes the task-derived shortcut from the core feature vector.
        node["features"]["is_object_of_interest"] = 0
        if len(node["feature_vector"]) > 4:
            node["feature_vector"][4] = 0.0
        nodes.append(node)
    return nodes


def graph_with_relations(snapshot: Mapping[str, Any], include_all_sites: bool = False) -> dict[str, Any]:
    base = extract_graph_snapshot(snapshot)
    nodes = _select_nodes(base, include_all_sites=include_all_sites)
    node_by_id = {node["node_id"]: node for node in nodes}
    edges = _make_edges(nodes)
    contacts = _contact_set(snapshot)
    for edge in edges:
        edge["relations"] = relation_labels(
            node_by_id[edge["source"]],
            node_by_id[edge["target"]],
            contacts,
        )
        edge["semantic_relation"] = edge["relations"]
    return {
        "step": int(snapshot.get("step", 0)),
        "nodes": nodes,
        "edges": edges,
        "node_feature_dim": base["node_feature_dim"],
        "node_selection": "task_relevant_entities_without_sites" if not include_all_sites else "all_sites",
    }


def _split_episode_ids(episode_ids: list[str]) -> dict[str, str]:
    ordered = sorted(episode_ids)
    if len(ordered) < 3:
        return {episode_id: "train" for episode_id in ordered}
    assignments = {}
    for index, episode_id in enumerate(ordered):
        if index == len(ordered) - 1:
            split = "test"
        elif index == len(ordered) - 2:
            split = "validation"
        else:
            split = "train"
        assignments[episode_id] = split
    return assignments


def _edge_map(graph: Mapping[str, Any]) -> dict[tuple[str, str], Mapping[str, Any]]:
    return {(edge["source"], edge["target"]): edge for edge in graph["edges"]}


def build_dataset(payload: Mapping[str, Any], tau: int = 6, include_all_sites: bool = False) -> dict[str, Any]:
    episodes = payload.get("episodes", [])
    if not isinstance(episodes, Sequence) or isinstance(episodes, (str, bytes)):
        raise ValueError("trajectory payload must contain an episodes sequence")
    episode_ids = [str(episode["episode_id"]) for episode in episodes]
    split_by_episode = _split_episode_ids(episode_ids)
    samples = []
    episode_audits = []
    for episode in episodes:
        episode_id = str(episode["episode_id"])
        snapshots = episode.get("snapshots", [])
        actions = episode.get("actions", [])
        if len(snapshots) <= tau or len(actions) < tau:
            episode_audits.append({"episode_id": episode_id, "eligible_samples": 0, "reason": "too_short"})
            continue
        graphs = [graph_with_relations(snapshot, include_all_sites=include_all_sites) for snapshot in snapshots]
        eligible = 0
        change_count = 0
        for start in range(0, len(snapshots) - tau):
            current = graphs[start]
            future = graphs[start + tau]
            current_edges = _edge_map(current)
            future_edges = _edge_map(future)
            common_keys = sorted(set(current_edges) & set(future_edges))
            relation_changes = {}
            relation_valid = {}
            for key in common_keys:
                now = current_edges[key]["relations"]
                later = future_edges[key]["relations"]
                for relation in RELATIONS:
                    now_record = now[relation]
                    later_record = later[relation]
                    label_key = f"{key[0]}->{key[1]}::{relation}"
                    valid = int(now_record["valid"] and later_record["valid"])
                    relation_valid[label_key] = valid
                    relation_changes[label_key] = int(
                        valid and now_record["value"] != later_record["value"]
                    )
            sample = {
                "episode_id": episode_id,
                "split": split_by_episode[episode_id],
                "task_id": episode.get("task_id"),
                "task_name": episode.get("task_name"),
                "start_step": start,
                "target_step": start + tau,
                "tau": tau,
                "action_window": [entry["action"] for entry in actions[start : start + tau]],
                "graph_t": current,
                "graph_target": future,
                "relation_valid": relation_valid,
                "relation_changes": relation_changes,
            }
            samples.append(sample)
            eligible += 1
            change_count += sum(relation_changes.values())
        episode_audits.append({"episode_id": episode_id, "eligible_samples": eligible, "change_count": change_count})

    stats = defaultdict(Counter)
    for sample in samples:
        for label_key, valid in sample["relation_valid"].items():
            _, relation = label_key.split("::", 1)
            stats[relation]["valid"] += int(valid)
            if valid:
                stats[relation]["changed"] += int(sample["relation_changes"][label_key])
    return {
        "dataset_version": "phase2r.v1-pilot",
        "source_capture_status": payload.get("capture_status"),
        "privileged_oracle": True,
        "tau": tau,
        "margin": MARGIN,
        "coordinate_frame": "raw_world_pilot; freeze robot_base_or_task_local before scale-up",
        "relation_definitions": {
            relation: ("geometric_axis_margin" if relation in GEOMETRIC_RELATIONS else "pending_capability_labeler")
            for relation in RELATIONS
        },
        "split": {
            "unit": "episode",
            "assignments": split_by_episode,
            "normalization_fit_on": "train_only",
            "threshold_fit_on": "train_only",
        },
        "episodes": episode_audits,
        "samples": samples,
        "stats": {relation: dict(counter) for relation, counter in stats.items()},
        "audit": {
            "episode_count": len(episode_ids),
            "sample_count": len(samples),
            "changed_relation_count": sum(
                sum(sample["relation_changes"].values()) for sample in samples
            ),
            "nonzero_action_count": sum(
                any(abs(float(value)) > 0.0 for value in action)
                for episode in episodes
                for action_entry in episode.get("actions", [])
                for action in [action_entry.get("action", [])]
            ),
        },
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tau", type=int, default=6)
    parser.add_argument("--include-all-sites", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    dataset = build_dataset(payload, tau=args.tau, include_all_sites=args.include_all_sites)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(dataset, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dataset["audit"], ensure_ascii=False))
    print(json.dumps({"stats": dataset["stats"], "split": dataset["split"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
