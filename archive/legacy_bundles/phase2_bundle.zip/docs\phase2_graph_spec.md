# Phase 2: GraphSpec and deterministic graph extractor

## Purpose

Phase 2 converts the Phase 1 raw LIBERO state contract into a deterministic
graph representation. It does not train a GNN or claim that simulator state is
available to an RGB policy. The first graph is an oracle graph for the
controlled CLaD versus Graph-CLaD comparison.

## Graph boundary

Each snapshot becomes one directed graph. The node set contains:

- `robot0`: represented by the end-effector position and robot state;
- `object`: movable task objects;
- `fixture`: fixed scene elements;
- `site`: task-local sites when they have a valid position.

The logical environment name is the node identity. `body_id` remains visible
only as runtime audit metadata and is excluded from node identity and model
features.

## Phase 2 v1 node features

The common numeric vector has 24 values:

```text
position(3), position_valid(1), is_object_of_interest(1),
gripper_qpos(2), gripper_qpos_valid(1),
joint_pos(7), joint_pos_valid(1),
joint_vel(7), joint_vel_valid(1)
```

Node type is a separate four-way one-hot encoding. Missing numeric values are
represented as zero together with a validity mask. This prevents missing robot
fields from being confused with real zero-valued measurements.

Raw quaternion values are retained in the audit payload but excluded from the
v1 model feature vector. Phase 1 showed that ordering must be verified before
normalization or use as a learned feature.

## Phase 2 v1 edge policy

The graph is a complete directed spatial graph without self-loops over nodes
whose positions are valid. Each directed edge contains:

```text
relative_position = target_position - source_position  (3)
distance                                              (1)
distance_valid                                        (1)
```

No distance threshold is used in v1. A threshold would be an arbitrary
hyperparameter at this stage and could hide long-range dependencies. A later
controlled ablation may compare complete, radius-limited, and predicate-only
topologies.

## Predicate and error policy

Phase 1 found that `get_joint_state`, `is_open`, and `is_close` are not
uniformly implemented across object, fixture, and site wrappers. Therefore:

- supported boolean values are stored with `valid=1`;
- missing values are stored as `value=null, valid=0`;
- caught exceptions are stored as `value=null, valid=0` with the error text;
- unknown is never silently converted to `false`;
- semantic predicate edges are audit-only in `phase2.v1`.

This keeps the current graph geometric and makes predicate coverage a visible
future ablation rather than a hidden source of label noise.

## Temporal and leakage policy

Graphs preserve the source snapshot `step` order and align nodes by logical
identity. Future state, success, reward, and terminal information are not
included in node or edge features. Normalization statistics must be fitted on
training episodes only.

## Execution

```powershell
python scripts/graph_extractor.py `
  --input data/phase1_libero_state_capture.json `
  --spec configs/phase2_graph_spec.json `
  --output data/phase2_graph_sequence.json
```

The local Phase 1 file is a compact manifest, so the command above requires
the full raw capture generated in Colab. The extractor is also tested against
a dependency-free snapshot fixture locally.

## Live validation result

The extractor was run in Colab on the full Phase 1 capture. It produced two
graphs with 24 nodes each: one robot, five objects, two fixtures, and sixteen
sites. The complete directed topology contained 552 edges per graph, all
node positions were valid, and every node used the same 24-dimensional
feature vector.

The predicate audit reported 55 errors, 12 available values, and 2 unsupported
values per graph. This is expected from the Phase 1 object-specific API
boundary; those errors remain unknown rather than becoming false labels. The
compact live result is stored in `data/phase2_live_graph_manifest.json`.

## Files

- `configs/phase2_graph_spec.json`: frozen v1 contract.
- `scripts/graph_extractor.py`: dependency-free extractor and CLI.
- `tests/test_phase2_graph_extractor.py`: topology, masks, identity, predicate,
  and temporal tests.
